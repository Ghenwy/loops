# Tools & Runtime Safety

## Purpose

Tools & Runtime Safety contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F05.L01 | `tool_registry_quality` | C | 76 |
| F05.L02 | `tool_poisoning_defense` | S | 100 |
| F05.L03 | `python_tool_building_agent` | S | 100 |
| F05.L04 | `safe_sandbox_execution` | S | 100 |
| F05.L05 | `rollback_recovery` | S | 100 |
| F05.L06 | `security_hardening` | S | 100 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
