# Evidence — F05.L06 security_hardening

## Required evidence

- `threat_model`: required for premium closure.
- `secret_scan`: required for premium closure.
- `permission_review`: required for premium closure.
- `dependency_audit`: required for premium closure.
- `input_validation_report`: required for premium closure.
- `severity_matrix`: required for premium closure.
- `mitigation_log`: required for premium closure.
- `residual_risk_register`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `threat_model` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `secret_scan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `permission_review` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `dependency_audit` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `input_validation_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `severity_matrix` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `mitigation_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-security_hardening-premium
loop_id: F05.L06
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  threat_model: present
  secret_scan: present
  permission_review: present
  dependency_audit: present
  input_validation_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F05.L06
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.
