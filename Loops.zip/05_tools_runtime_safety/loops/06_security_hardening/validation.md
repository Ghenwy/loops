# Validation — F05.L06 security_hardening

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F05.L06`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: threat model written.
- PV-02: secrets scan clean.
- PV-03: permissions least-privilege.
- PV-04: dependencies reviewed.
- PV-05: input validation present.
- PV-06: dangerous commands blocked.
- PV-07: critical findings fixed.
- PV-08: major findings justified.
- PV-09: mitigations verified.
- PV-10: residual risk declared.
- PV-11: rollback possible.
- PV-12: security evidence exported.

## Domain checks

- DC-01: `threat model written` must be represented in contract, examples and evidence.
- DC-02: `secrets scan clean` must be represented in contract, examples and evidence.
- DC-03: `permissions least-privilege` must be represented in contract, examples and evidence.
- DC-04: `dependencies reviewed` must be represented in contract, examples and evidence.
- DC-05: `input validation present` must be represented in contract, examples and evidence.
- DC-06: `dangerous commands blocked` must be represented in contract, examples and evidence.
- DC-07: `critical findings fixed` must be represented in contract, examples and evidence.
- DC-08: `major findings justified` must be represented in contract, examples and evidence.
- DC-09: `mitigations verified` must be represented in contract, examples and evidence.
- DC-10: `residual risk declared` must be represented in contract, examples and evidence.
- DC-11: `rollback possible` must be represented in contract, examples and evidence.
- DC-12: `security evidence exported` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `threat_model` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Secret appears in fixture or example output; expected failed until removed and rotation note added if needed.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`secret_scan`, `permission_review`, `dependency_check`, `input_validation`, `dangerous_command`, `threat_model`, `severity_matrix`, `mitigation_evidence`, `dependency_audit`, `input_validation_report`, `mitigation_log`, `residual_risk_register`, `critical_findings`, `major_findings`, `secrets_found`, `mitigations_verified`, `reducing`, `exposed`, `secrets`, `dangerous`

## Domain term coverage

This premium validation explicitly checks: `secret_scan`, `permission_review`, `dependency_check`, `input_validation`, `dangerous_command`, `threat_model`, `severity_matrix`, `mitigation_evidence`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.
