# Security Hardening — Premium Loop

## Identity

- Loop ID: `F05.L06`
- Family: `F05 — Tools & Runtime Safety`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Reducing exposed secrets, dangerous inputs, excessive permissions and vulnerable dependencies.

## Why this loop matters

Lets the library touch real systems without blindfolds.

## Premium artifacts

- `threat_model`
- `secret_scan`
- `permission_review`
- `dependency_audit`
- `input_validation_report`
- `severity_matrix`
- `mitigation_log`

## OODA execution

### Observe

- Capture `threat_model` and `secret_scan`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `threat model written` and `secrets scan clean`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `critical_findings` and `major_findings`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- threat model written.
- secrets scan clean.
- permissions least-privilege.
- dependencies reviewed.
- input validation present.
- dangerous commands blocked.
- critical findings fixed.
- major findings justified.
- mitigations verified.
- residual risk declared.
- rollback possible.
- security evidence exported.

## Evidence contract

- `threat_model`
- `secret_scan`
- `permission_review`
- `dependency_audit`
- `input_validation_report`
- `severity_matrix`
- `mitigation_log`
- `residual_risk_register`

## Edge case

Secret appears in fixture or example output; expected failed until removed and rotation note added if needed.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target S

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `S` with score >= 96.

### Required artifacts
- `security_severity_matrix`
- `secret_scan_gate`
- `permission_audit`
- `dependency_risk_check`
- `input_validation_matrix`
- `dangerous_command_filter`

### Quality gates
- SH-01: critical security findings block completion
- SH-02: secret_scan_gate returns zero exposed secrets
- SH-03: permission_audit enforces least privilege
- SH-04: dependency_risk_check records unresolved CVE or risk state
- SH-05: input_validation_matrix covers untrusted inputs
- SH-06: dangerous_command_filter blocks destructive commands

### Merge boundary
Keep separate from safe_sandbox_execution: hardening reduces attack surface; sandbox constrains runtime side effects.
