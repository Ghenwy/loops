# Examples — F05.L06 Security Hardening

## Happy path

```yaml
task: "Run security_hardening with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - threat_model
  - secret_scan
  - permission_review
expected_checks:
  - threat model written
  - secrets scan clean
```

## Blocked path

```yaml
task: "Run security_hardening with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run security_hardening with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Secret appears in fixture or example output; expected failed until removed and rotation note added if needed."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails threat model written."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

