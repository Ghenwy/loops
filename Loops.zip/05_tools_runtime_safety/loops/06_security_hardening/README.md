# Security Hardening

## ID

F05.L06

## Score

Tier `S` / score `100`.

## Purpose

Reducing exposed secrets, dangerous inputs, excessive permissions and vulnerable dependencies.

## Use when

- release or execution has security risk
- tools/commands/dependencies involved

## Avoid when

- no security-relevant surface exists

## Domain markers

`secret_scan`, `permission_review`, `dependency_check`, `input_validation`, `dangerous_command`, `threat_model`

## Required gates

- threat model written
- secrets scan clean
- permissions least-privilege
- dependencies reviewed

## Evidence

- `threat_model`
- `secret_scan`
- `permission_review`
- `dependency_audit`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
