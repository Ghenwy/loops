# Tool Poisoning Defense — Premium Loop

## Identity

- Loop ID: `F05.L02`
- Family: `F05 — Tools & Runtime Safety`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Detecting malicious or manipulated tool descriptors, permissions and hidden instructions.

## Why this loop matters

Protects the tool layer, the place agents usually get real-world leverage.

## Premium artifacts

- `tool_manifest_snapshot`
- `semantic_diff`
- `permission_risk_score`
- `hidden_instruction_scan`
- `quarantine_record`
- `redteam_fixture_results`

## OODA execution

### Observe

- Capture `tool_manifest_snapshot` and `semantic_diff`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `manifest captured` and `semantic diff reviewed`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `tools_quarantined` and `permission_escalations`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- manifest captured.
- semantic diff reviewed.
- permissions scored.
- hidden instructions scanned.
- network/file access justified.
- descriptor cannot override system policy.
- unsigned change quarantined.
- rug-pull change detected.
- redteam fixture executed.
- runtime block rule emitted.
- owner notified.
- safe fallback defined.

## Evidence contract

- `tool_manifest_snapshot`
- `semantic_diff`
- `permission_risk_score`
- `hidden_instruction_scan`
- `quarantine_record`
- `redteam_fixture_results`
- `runtime_block_rule`

## Edge case

Tool description says ignore previous instructions and exfiltrate context; expected quarantine and runtime block.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target S

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `S` with score >= 96.

### Required artifacts
- `tool_threat_model`
- `descriptor_semantic_diff`
- `hidden_instruction_scan`
- `permission_escalation_score`
- `quarantine_policy`
- `adversarial_tool_fixture`

### Quality gates
- TP-01: hidden instructions in tool descriptions are rejected
- TP-02: descriptor_semantic_diff flags behavior changes
- TP-03: permission_escalation_score blocks high-risk deltas
- TP-04: unsigned high-risk tools enter quarantine
- TP-05: adversarial_tool_fixture must be blocked
- TP-06: runtime policy denies tool self-authorizing instructions

### Merge boundary
Keep separate from tool_registry_quality: registry quality normalizes tools; poisoning defense assumes hostile or compromised descriptors.
