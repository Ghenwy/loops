# Evidence — F05.L02 tool_poisoning_defense

## Required evidence

- `tool_manifest_snapshot`: required for premium closure.
- `semantic_diff`: required for premium closure.
- `permission_risk_score`: required for premium closure.
- `hidden_instruction_scan`: required for premium closure.
- `quarantine_record`: required for premium closure.
- `redteam_fixture_results`: required for premium closure.
- `runtime_block_rule`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `tool_manifest_snapshot` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `semantic_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `permission_risk_score` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `hidden_instruction_scan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `quarantine_record` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `redteam_fixture_results` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `runtime_block_rule` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-tool_poisoning_defense-premium
loop_id: F05.L02
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  tool_manifest_snapshot: present
  semantic_diff: present
  permission_risk_score: present
  hidden_instruction_scan: present
  quarantine_record: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F05.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.
