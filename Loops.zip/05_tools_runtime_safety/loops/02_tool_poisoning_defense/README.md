# Tool Poisoning Defense

## ID

F05.L02

## Score

Tier `S` / score `100`.

## Purpose

Detecting malicious or manipulated tool descriptors, permissions and hidden instructions.

## Use when

- tool comes from third party
- tool descriptor changed
- agent can execute real actions

## Avoid when

- tool is read-only and already verified but still record trust basis

## Domain markers

`tool_descriptor`, `hidden_instruction`, `semantic_diff`, `permission_escalation`, `quarantine_policy`, `signature_status`

## Required gates

- manifest captured
- semantic diff reviewed
- permissions scored
- hidden instructions scanned

## Evidence

- `tool_manifest_snapshot`
- `semantic_diff`
- `permission_risk_score`
- `hidden_instruction_scan`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
