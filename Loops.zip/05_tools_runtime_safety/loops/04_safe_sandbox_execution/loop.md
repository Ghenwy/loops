# Safe Sandbox Execution — Premium Loop

## Identity

- Loop ID: `F05.L04`
- Family: `F05 — Tools & Runtime Safety`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Controlled execution for commands, file writes and risky agent actions.

## Why this loop matters

Unlocks real agent execution without letting tools roam through the filesystem like a raccoon in a kitchen.

## Premium artifacts

- `sandbox_policy`
- `filesystem_allowlist`
- `network_policy`
- `command_denylist`
- `secret_scan`
- `diff_review`
- `restore_validation`

## OODA execution

### Observe

- Capture `sandbox_policy` and `filesystem_allowlist`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `risk classified` and `filesystem policy enforced`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `blocked_commands` and `policy_violations`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- risk classified.
- filesystem policy enforced.
- network policy enforced.
- command denylist applied.
- secret scan clean.
- dry-run attempted when possible.
- logs captured.
- diff reviewed.
- restore path validated.
- out-of-sandbox write blocked.
- human gate required for high impact.
- post-run state verified.

## Evidence contract

- `sandbox_policy`
- `command_log`
- `filesystem_diff`
- `network_log`
- `secret_scan`
- `restore_validation`
- `policy_violations`
- `approval_record`

## Edge case

Command attempts to write outside allowed workspace; expected failed or blocked with no real workspace mutation.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target S

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `S` with score >= 96.

### Required artifacts
- `filesystem_policy_matrix`
- `network_policy_matrix`
- `command_denylist`
- `secret_guard_protocol`
- `sandbox_restore_probe`
- `diff_review_gate`

### Quality gates
- SB-01: filesystem writes are confined to sandbox or staged diff
- SB-02: network access is explicitly allow/deny listed
- SB-03: command_denylist blocks destructive commands
- SB-04: secret_guard scans inputs, env and outputs
- SB-05: restore_probe proves rollback before promotion
- SB-06: diff_review approves only declared paths

### Merge boundary
Keep separate from rollback_recovery: sandbox prevents unsafe execution; rollback repairs after degradation.
