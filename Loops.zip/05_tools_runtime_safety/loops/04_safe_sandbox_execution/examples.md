# Examples — F05.L04 Safe Sandbox Execution

## Happy path

```yaml
task: "Run safe_sandbox_execution with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - sandbox_policy
  - command_log
  - filesystem_diff
expected_checks:
  - risk classified
  - filesystem policy enforced
```

## Blocked path

```yaml
task: "Run safe_sandbox_execution with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run safe_sandbox_execution with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Command attempts to write outside allowed workspace; expected failed or blocked with no real workspace mutation."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails risk classified."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

