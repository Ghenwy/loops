# Safe Sandbox Execution

## ID

F05.L04

## Score

Tier `S` / score `100`.

## Purpose

Controlled execution for commands, file writes and risky agent actions.

## Use when

- agent executes commands or writes files
- risk is non-trivial
- dry-run is possible

## Avoid when

- read-only analysis with no side effects

## Domain markers

`sandbox_policy`, `filesystem_scope`, `network_scope`, `command_denylist`, `secret_guard`, `dry_run_result`

## Required gates

- risk classified
- filesystem policy enforced
- network policy enforced
- command denylist applied

## Evidence

- `sandbox_policy`
- `command_log`
- `filesystem_diff`
- `network_log`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
