# Validation — F05.L04 safe_sandbox_execution

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F05.L04`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: risk classified.
- PV-02: filesystem policy enforced.
- PV-03: network policy enforced.
- PV-04: command denylist applied.
- PV-05: secret scan clean.
- PV-06: dry-run attempted when possible.
- PV-07: logs captured.
- PV-08: diff reviewed.
- PV-09: restore path validated.
- PV-10: out-of-sandbox write blocked.
- PV-11: human gate required for high impact.
- PV-12: post-run state verified.

## Domain checks

- DC-01: `risk classified` must be represented in contract, examples and evidence.
- DC-02: `filesystem policy enforced` must be represented in contract, examples and evidence.
- DC-03: `network policy enforced` must be represented in contract, examples and evidence.
- DC-04: `command denylist applied` must be represented in contract, examples and evidence.
- DC-05: `secret scan clean` must be represented in contract, examples and evidence.
- DC-06: `dry-run attempted when possible` must be represented in contract, examples and evidence.
- DC-07: `logs captured` must be represented in contract, examples and evidence.
- DC-08: `diff reviewed` must be represented in contract, examples and evidence.
- DC-09: `restore path validated` must be represented in contract, examples and evidence.
- DC-10: `out-of-sandbox write blocked` must be represented in contract, examples and evidence.
- DC-11: `human gate required for high impact` must be represented in contract, examples and evidence.
- DC-12: `post-run state verified` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `sandbox_policy` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Command attempts to write outside allowed workspace; expected failed or blocked with no real workspace mutation.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`sandbox_policy`, `filesystem_scope`, `network_scope`, `command_denylist`, `secret_guard`, `dry_run_result`, `diff_review`, `restore_validation`, `filesystem_allowlist`, `network_policy`, `secret_scan`, `command_log`, `filesystem_diff`, `network_log`, `policy_violations`, `approval_record`, `blocked_commands`, `files_changed`, `restore_pass`, `controlled`

## Domain term coverage

This premium validation explicitly checks: `sandbox_policy`, `filesystem_scope`, `network_scope`, `command_denylist`, `secret_guard`, `dry_run_result`, `diff_review`, `restore_validation`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.
