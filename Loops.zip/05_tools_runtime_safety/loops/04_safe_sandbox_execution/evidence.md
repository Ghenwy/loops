# Evidence — F05.L04 safe_sandbox_execution

## Required evidence

- `sandbox_policy`: required for premium closure.
- `command_log`: required for premium closure.
- `filesystem_diff`: required for premium closure.
- `network_log`: required for premium closure.
- `secret_scan`: required for premium closure.
- `restore_validation`: required for premium closure.
- `policy_violations`: required for premium closure.
- `approval_record`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `sandbox_policy` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `command_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `filesystem_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `network_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `secret_scan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `restore_validation` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `policy_violations` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-safe_sandbox_execution-premium
loop_id: F05.L04
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  sandbox_policy: present
  command_log: present
  filesystem_diff: present
  network_log: present
  secret_scan: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F05.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.
