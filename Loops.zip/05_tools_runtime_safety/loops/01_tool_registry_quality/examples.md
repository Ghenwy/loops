# Examples — F05.L01 Tool Registry Quality

  ## Happy path

  ```yaml
  task: "Run tool_registry_quality on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- tool_registry_entry
- schema_validation
- permission_review
- risk_score
  expected_checks:
    - "name and purpose clear"
    - "input_schema present"
  ```

  ## Blocked path

  ```yaml
  task: "Run tool_registry_quality with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run tool_registry_quality with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
