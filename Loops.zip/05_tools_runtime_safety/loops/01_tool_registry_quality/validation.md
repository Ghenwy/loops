# Validation — F05.L01 tool_registry_quality

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F05.L01`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: name and purpose clear.
- DC-02: input_schema present.
- DC-03: output_schema present.
- DC-04: permissions listed.
- DC-05: risk_level set.
- DC-06: owner/version set.
- DC-07: examples present.
- DC-08: selection test exists.

## Negative checks

- Reject if `tool_schema` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: tool_schema, input_schema, output_schema, permission, risk_level, owner, version, selection_test.


## Domain term audit anchors

`tool_schema`, `input_schema`, `output_schema`, `permission`, `risk_level`, `owner`, `version`, `selection_test`
