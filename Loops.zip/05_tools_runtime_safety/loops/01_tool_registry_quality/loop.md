# Tool Registry Quality — Loop Definition

    ## Identity

    - Loop ID: `F05.L01`
    - Family: `F05 — Tools & Runtime Safety`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Maintain a tool registry where every tool has clear schema, permissions, risk, examples, validation and owner/version.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `tool_schema`, `input_schema`, `output_schema`, `permission`, `risk_level`, `owner`, `version`, `selection_test`

    ## Use when

- agents have tools
- tool choice errors occur
- MCP/tool registry must be governed

## Avoid when
- no tools are available

## OODA execution

### Observe

1. list tools and descriptors.
2. inspect schemas, permissions and examples.
3. detect ambiguous names or risky defaults.

### Orient

1. score tool clarity and risk.
2. find missing input/output schema.
3. classify permission needs.

### Decide

1. approve, fix, quarantine or deprecate tool.
2. choose selection tests.
3. require owner/version for registry entry.

### Act

1. update registry and examples.
2. write validation cases.
3. mark risky tools with guardrails.

### Validate

1. run schema and selection checks.
2. reject tool with missing permissions.
3. verify examples match outputs.

### Evidence

- `tool_registry_entry`
- `schema_validation`
- `permission_review`
- `risk_score`
- `selection_test_result`
- `version_log`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: name and purpose clear.
- CHECK-02: input_schema present.
- CHECK-03: output_schema present.
- CHECK-04: permissions listed.
- CHECK-05: risk_level set.
- CHECK-06: owner/version set.
- CHECK-07: examples present.
- CHECK-08: selection test exists.

## Metrics

- `tools_validated`
- `schema_failures`
- `high_risk_tools`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
