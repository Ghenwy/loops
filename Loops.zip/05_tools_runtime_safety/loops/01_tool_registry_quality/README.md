# Tool Registry Quality

## ID

F05.L01

## Score

Tier `C` / score `76`.

## Purpose

Maintain a tool registry where every tool has clear schema, permissions, risk, examples, validation and owner/version.

## Use when

- agents have tools
- tool choice errors occur
- MCP/tool registry must be governed

## Avoid when

- no tools are available

## Domain markers

`tool_schema`, `input_schema`, `output_schema`, `permission`, `risk_level`, `owner`

## Required gates

- name and purpose clear
- input_schema present
- output_schema present
- permissions listed

## Evidence

- `tool_registry_entry`
- `schema_validation`
- `permission_review`
- `risk_score`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
