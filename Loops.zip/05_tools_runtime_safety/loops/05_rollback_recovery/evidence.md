# Evidence — F05.L05 rollback_recovery

## Required evidence

- `last_good_state`: required for normal closure.
- `rollback_plan`: required for normal closure.
- `rollback_log`: required for normal closure.
- `state_after_rollback`: required for normal closure.
- `restore_validation_result`: required for normal closure.
- `failed_rollback_report`: required for normal closure.
- `rollback_type`: required for normal closure.
- `checkpoint_reference`: required for normal closure.
- `restore_validation`: required for normal closure.
- `failed_rollback_plan`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `rollback_type` | rollback_recovery closure | yes |
| `checkpoint_reference` | rollback_recovery closure | yes |
| `restore_validation` | rollback_recovery closure | yes |
| `failed_rollback_plan` | rollback_recovery closure | yes |
| `recovery_report` | rollback_recovery closure | yes |
| `post_rollback_evidence` | rollback_recovery closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f05-l05-ok
loop_id: F05.L05
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  rollback_type: present
  checkpoint_reference: present
  restore_validation: present
  failed_rollback_plan: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f05-l05-bad
loop_id: F05.L05
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.
