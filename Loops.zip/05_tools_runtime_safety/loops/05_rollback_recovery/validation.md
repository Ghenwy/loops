# Validation — F05.L05 rollback_recovery

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F05.L05`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: rollback type is explicit.
- DC-02: restore validation is mandatory.
- DC-03: failed rollback has escalation.
- DC-04: recovery evidence is attached.
- DC-05: artifact `rollback_type` is present.
- DC-06: artifact `checkpoint_reference` is present.
- DC-07: artifact `restore_validation` is present.
- DC-08: artifact `failed_rollback_plan` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: restore_pass, rollback_duration, resources_restored, failed_rollback_count.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Rollback restores files but tests still fail; recovery is not accepted.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.

## Domain term audit anchors

`rollback_type`, `git_revert`, `snapshot_restore`, `checkpoint_restore`, `compensation_action`, `restore_validation`, `rollback_evidence`, `failed_rollback`, `checkpoint_reference`, `failed_rollback_plan`, `recovery_report`, `post_rollback_evidence`

## Domain term coverage

This premium validation explicitly checks: `rollback_type`, `git_revert`, `snapshot_restore`, `checkpoint_restore`, `compensation_action`, `restore_validation`, `rollback_evidence`, `failed_rollback`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.
