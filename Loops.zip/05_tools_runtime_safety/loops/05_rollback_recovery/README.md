# Rollback Recovery

## ID

F05.L05

## Score

Tier `S` / score `100`.

## Purpose

rollback and recovery with rollback type, restore validation, failed rollback handling and postmortem evidence.

## Use when

- change can degrade state
- rollback may be needed
- restore must be auditable

## Avoid when

- no state changed and no recovery path exists

## Domain markers

`rollback_type`, `git_revert`, `snapshot_restore`, `checkpoint_restore`, `compensation_action`, `restore_validation`

## Required gates

- rollback_type selected
- last good state identified
- strategy matches resource
- restore_validation defined

## Evidence

- `last_good_state`
- `rollback_plan`
- `rollback_log`
- `state_after_rollback`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
