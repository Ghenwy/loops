# Python Tool Building Agent

## ID

F05.L03

## Score

Tier `S` / score `100`.

## Purpose

Generating small python tools only inside sandbox, with tests, timeout and registry validation.

## Use when

- agent needs local utility
- tool can be unit-tested
- Python execution is available

## Avoid when

- tool would need production secrets or unsafe side effects

## Domain markers

`generated_tool`, `sandbox_workspace`, `pytest_gate`, `ruff_gate`, `timeout_policy`, `tool_registry_entry`

## Required gates

- tool need justified
- spec written before code
- sandbox used
- tests generated

## Evidence

- `tool_spec`
- `sandbox_workspace`
- `generated_code`
- `pytest_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
