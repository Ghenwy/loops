# Validation — F05.L03 python_tool_building_agent

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F05.L03`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: tool need justified.
- PV-02: spec written before code.
- PV-03: sandbox used.
- PV-04: tests generated.
- PV-05: pytest passes.
- PV-06: lint or syntax check passes.
- PV-07: timeout enforced.
- PV-08: dangerous imports rejected.
- PV-09: registry entry complete.
- PV-10: failed tool not registered.
- PV-11: example invocation captured.
- PV-12: rollback removes generated tool.

## Domain checks

- DC-01: `tool need justified` must be represented in contract, examples and evidence.
- DC-02: `spec written before code` must be represented in contract, examples and evidence.
- DC-03: `sandbox used` must be represented in contract, examples and evidence.
- DC-04: `tests generated` must be represented in contract, examples and evidence.
- DC-05: `pytest passes` must be represented in contract, examples and evidence.
- DC-06: `lint or syntax check passes` must be represented in contract, examples and evidence.
- DC-07: `timeout enforced` must be represented in contract, examples and evidence.
- DC-08: `dangerous imports rejected` must be represented in contract, examples and evidence.
- DC-09: `registry entry complete` must be represented in contract, examples and evidence.
- DC-10: `failed tool not registered` must be represented in contract, examples and evidence.
- DC-11: `example invocation captured` must be represented in contract, examples and evidence.
- DC-12: `rollback removes generated tool` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `tool_spec` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Generated tool passes syntax but fails pytest; expected rejected and not registered.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`generated_tool`, `sandbox_workspace`, `pytest_gate`, `ruff_gate`, `timeout_policy`, `tool_registry_entry`, `input_output_schema`, `reject_failed_tool`, `tool_spec`, `generated_code`, `pytest_report`, `lint_report`, `registry_entry`, `rejection_record`, `generated_tools`, `registered_tools`, `test_pass_rate`, `rejected_tools`, `generating`, `sandbox`

## Domain term coverage

This premium validation explicitly checks: `generated_tool`, `sandbox_workspace`, `pytest_gate`, `ruff_gate`, `timeout_policy`, `tool_registry_entry`, `input_output_schema`, `reject_failed_tool`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- TB-01: generated tool has tool_spec_schema
- TB-02: sandbox_test_runner executes without real workspace writes
- TB-03: pytest_gate passes before registration
- TB-04: timeout_policy prevents hanging tools
- TB-05: failed_tool_quarantine blocks failed registration
- TB-06: registry_entry_schema records permissions

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from tool_registry_quality: tool-building creates and tests tools; registry quality audits existing tool specs.
