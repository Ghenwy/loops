# Python Tool Building Agent — Premium Loop

## Identity

- Loop ID: `F05.L03`
- Family: `F05 — Tools & Runtime Safety`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Generating small python tools only inside sandbox, with tests, timeout and registry validation.

## Why this loop matters

Gives agents hands, but makes them wash those hands before touching the repo.

## Premium artifacts

- `tool_spec`
- `sandbox_workspace`
- `generated_code`
- `pytest_report`
- `lint_report`
- `timeout_policy`
- `registry_entry`

## OODA execution

### Observe

- Capture `tool_spec` and `sandbox_workspace`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `tool need justified` and `spec written before code`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `generated_tools` and `registered_tools`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- tool need justified.
- spec written before code.
- sandbox used.
- tests generated.
- pytest passes.
- lint or syntax check passes.
- timeout enforced.
- dangerous imports rejected.
- registry entry complete.
- failed tool not registered.
- example invocation captured.
- rollback removes generated tool.

## Evidence contract

- `tool_spec`
- `sandbox_workspace`
- `generated_code`
- `pytest_report`
- `lint_report`
- `timeout_policy`
- `registry_entry`
- `rejection_record`

## Edge case

Generated tool passes syntax but fails pytest; expected rejected and not registered.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `tool_spec_schema`
- `sandbox_test_runner`
- `pytest_gate`
- `timeout_policy`
- `registry_entry_schema`
- `failed_tool_quarantine`

### Quality gates
- TB-01: generated tool has tool_spec_schema
- TB-02: sandbox_test_runner executes without real workspace writes
- TB-03: pytest_gate passes before registration
- TB-04: timeout_policy prevents hanging tools
- TB-05: failed_tool_quarantine blocks failed registration
- TB-06: registry_entry_schema records permissions

### Merge boundary
Keep separate from tool_registry_quality: tool-building creates and tests tools; registry quality audits existing tool specs.
