# Examples — F05.L03 Python Tool Building Agent

## Happy path

```yaml
task: "Run python_tool_building_agent with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - tool_spec
  - sandbox_workspace
  - generated_code
expected_checks:
  - tool need justified
  - spec written before code
```

## Blocked path

```yaml
task: "Run python_tool_building_agent with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run python_tool_building_agent with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Generated tool passes syntax but fails pytest; expected rejected and not registered."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails tool need justified."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

