# Evidence — F05.L03 python_tool_building_agent

## Required evidence

- `tool_spec`: required for premium closure.
- `sandbox_workspace`: required for premium closure.
- `generated_code`: required for premium closure.
- `pytest_report`: required for premium closure.
- `lint_report`: required for premium closure.
- `timeout_policy`: required for premium closure.
- `registry_entry`: required for premium closure.
- `rejection_record`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `tool_spec` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `sandbox_workspace` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `generated_code` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `pytest_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `lint_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `timeout_policy` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `registry_entry` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-python_tool_building_agent-premium
loop_id: F05.L03
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  tool_spec: present
  sandbox_workspace: present
  generated_code: present
  pytest_report: present
  lint_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F05.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `tool_spec_schema`: required for target A maturity.
- `sandbox_test_log`: required for target A maturity.
- `pytest_gate_result`: required for target A maturity.
- `timeout_policy`: required for target A maturity.
- `registry_entry`: required for target A maturity.
- `failed_tool_quarantine`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from tool_registry_quality: tool-building creates and tests tools; registry quality audits existing tool specs.
