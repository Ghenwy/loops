# Tools & Runtime Safety Index

- F05.L01 `tool_registry_quality` — C/76
- F05.L02 `tool_poisoning_defense` — S/100
- F05.L03 `python_tool_building_agent` — S/100
- F05.L04 `safe_sandbox_execution` — S/100
- F05.L05 `rollback_recovery` — S/100
- F05.L06 `security_hardening` — S/100
