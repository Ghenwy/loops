# Core Execution Index

- F01.L01 `adaptive_task_execution` — S+/101
- F01.L02 `adaptive_planning` — S/98
- F01.L03 `project_discovery` — C/76
- F01.L04 `context_management` — S/98
- F01.L05 `context_compression_memory` — S/97
- F01.L06 `evidence_generation` — S/98
