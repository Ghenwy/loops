# Core Execution

## Purpose

Core Execution contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F01.L01 | `adaptive_task_execution` | S+ | 101 |
| F01.L02 | `adaptive_planning` | S | 98 |
| F01.L03 | `project_discovery` | C | 76 |
| F01.L04 | `context_management` | S | 98 |
| F01.L05 | `context_compression_memory` | S | 97 |
| F01.L06 | `evidence_generation` | S | 98 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
