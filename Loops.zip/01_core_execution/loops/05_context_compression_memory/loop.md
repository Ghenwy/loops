# Context Compression Memory — Premium Loop

## Identity

- Loop ID: `F01.L05`
- Family: `F01 — Core Execution`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Compressing long context into governed memory with facts, inferences, unknowns and invalidation.

## Why this loop matters

Lets long-running agents remember useful things without hoarding junk.

## Premium artifacts

- `memory_schema`
- `compression_delta`
- `fact_inference_unknown_map`
- `source_bindings`
- `conflict_log`
- `invalidation_rule`
- `retrieval_test`

## OODA execution

### Observe

- Capture `memory_schema` and `compression_delta`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `memory schema applied` and `source binding present`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `compression_ratio` and `critical_items_retained`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- memory schema applied.
- source binding present.
- facts separated from inference.
- unknowns preserved.
- compression delta recorded.
- critical decisions retained.
- duplicates merged.
- conflicts logged.
- stale memory invalidated.
- retrieval test passes.
- sensitive data policy applied.
- summary budget respected.

## Evidence contract

- `memory_schema`
- `compression_delta`
- `fact_inference_unknown_map`
- `source_bindings`
- `conflict_log`
- `invalidation_rule`
- `retrieval_test`
- `sensitivity_review`

## Edge case

Summary drops a decision owner or converts inference into fact; expected failed compression gate.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `memory_entry_schema`
- `compression_policy`
- `fact_inference_unknown_split`
- `conflict_resolution_rule`
- `invalidation_policy`
- `source_binding`

### Quality gates
- CM-01: memory_entry_schema separates fact/inference/unknown
- CM-02: compression_policy preserves decisions and risks
- CM-03: source_binding is mandatory
- CM-04: conflict_resolution_rule handles contradictory memories
- CM-05: invalidation_policy marks stale entries
- CM-06: no sensitive data is stored without policy

### Merge boundary
Keep separate from context_management: context loop selects current inputs; memory loop compresses/persists durable knowledge.
