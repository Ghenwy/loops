# Validation — F01.L05 context_compression_memory

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F01.L05`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: memory schema applied.
- PV-02: source binding present.
- PV-03: facts separated from inference.
- PV-04: unknowns preserved.
- PV-05: compression delta recorded.
- PV-06: critical decisions retained.
- PV-07: duplicates merged.
- PV-08: conflicts logged.
- PV-09: stale memory invalidated.
- PV-10: retrieval test passes.
- PV-11: sensitive data policy applied.
- PV-12: summary budget respected.

## Domain checks

- DC-01: `memory schema applied` must be represented in contract, examples and evidence.
- DC-02: `source binding present` must be represented in contract, examples and evidence.
- DC-03: `facts separated from inference` must be represented in contract, examples and evidence.
- DC-04: `unknowns preserved` must be represented in contract, examples and evidence.
- DC-05: `compression delta recorded` must be represented in contract, examples and evidence.
- DC-06: `critical decisions retained` must be represented in contract, examples and evidence.
- DC-07: `duplicates merged` must be represented in contract, examples and evidence.
- DC-08: `conflicts logged` must be represented in contract, examples and evidence.
- DC-09: `stale memory invalidated` must be represented in contract, examples and evidence.
- DC-10: `retrieval test passes` must be represented in contract, examples and evidence.
- DC-11: `sensitive data policy applied` must be represented in contract, examples and evidence.
- DC-12: `summary budget respected` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `memory_schema` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Summary drops a decision owner or converts inference into fact; expected failed compression gate.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`memory_schema`, `compression_policy`, `fact_inference_unknown`, `source_binding`, `conflict_resolution`, `invalidation_rule`, `retention_window`, `memory_delta`, `compression_delta`, `fact_inference_unknown_map`, `source_bindings`, `conflict_log`, `retrieval_test`, `sensitivity_review`, `compression_ratio`, `critical_items_retained`, `conflicts_found`, `retrieval_pass_rate`, `compressing`, `context`

## Domain term coverage

This premium validation explicitly checks: `memory_schema`, `compression_policy`, `fact_inference_unknown`, `source_binding`, `conflict_resolution`, `invalidation_rule`, `retention_window`, `memory_delta`.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- CM-01: memory_entry_schema separates fact/inference/unknown
- CM-02: compression_policy preserves decisions and risks
- CM-03: source_binding is mandatory
- CM-04: conflict_resolution_rule handles contradictory memories
- CM-05: invalidation_policy marks stale entries
- CM-06: no sensitive data is stored without policy

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from context_management: context loop selects current inputs; memory loop compresses/persists durable knowledge.
