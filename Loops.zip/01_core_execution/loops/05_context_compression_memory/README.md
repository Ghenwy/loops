# Context Compression Memory

## ID

F01.L05

## Score

Tier `S` / score `97`.

## Purpose

Compressing long context into governed memory with facts, inferences, unknowns and invalidation.

## Use when

- session or logs are long
- memory must persist
- old context must be compacted

## Avoid when

- content is short enough to keep raw
- source cannot be tracked

## Domain markers

`memory_schema`, `compression_policy`, `fact_inference_unknown`, `source_binding`, `conflict_resolution`, `invalidation_rule`

## Required gates

- memory schema applied
- source binding present
- facts separated from inference
- unknowns preserved

## Evidence

- `memory_schema`
- `compression_delta`
- `fact_inference_unknown_map`
- `source_bindings`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
