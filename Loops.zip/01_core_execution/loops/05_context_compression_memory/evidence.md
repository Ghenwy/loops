# Evidence — F01.L05 context_compression_memory

## Required evidence

- `memory_schema`: required for premium closure.
- `compression_delta`: required for premium closure.
- `fact_inference_unknown_map`: required for premium closure.
- `source_bindings`: required for premium closure.
- `conflict_log`: required for premium closure.
- `invalidation_rule`: required for premium closure.
- `retrieval_test`: required for premium closure.
- `sensitivity_review`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `memory_schema` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `compression_delta` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `fact_inference_unknown_map` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `source_bindings` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `conflict_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `invalidation_rule` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `retrieval_test` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-context_compression_memory-premium
loop_id: F01.L05
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  memory_schema: present
  compression_delta: present
  fact_inference_unknown_map: present
  source_bindings: present
  conflict_log: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F01.L05
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `memory_entry_schema`: required for target A maturity.
- `compression_policy`: required for target A maturity.
- `fact_inference_unknown_split`: required for target A maturity.
- `conflict_resolution_result`: required for target A maturity.
- `invalidation_policy`: required for target A maturity.
- `source_binding`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from context_management: context loop selects current inputs; memory loop compresses/persists durable knowledge.
