# Examples — F01.L05 Context Compression Memory

## Happy path

```yaml
task: "Run context_compression_memory with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - memory_schema
  - compression_delta
  - fact_inference_unknown_map
expected_checks:
  - memory schema applied
  - source binding present
```

## Blocked path

```yaml
task: "Run context_compression_memory with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run context_compression_memory with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Summary drops a decision owner or converts inference into fact; expected failed compression gate."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

