# Adaptive Planning

## ID

F01.L02

## Score

Tier `S` / score `98`.

## Purpose

adaptive planning using task graph, dependency state, priority deltas and blocker recovery.

## Use when

- plan has dependencies
- priorities can change
- work must be resumed later

## Avoid when

- one-step task
- plan is externally fixed and cannot change

## Domain markers

`task_graph`, `dependency`, `priority_shift`, `plan_delta`, `blocker`, `critical_path`

## Required gates

- plan has task ids and states
- dependencies are explicit
- priority changes have reason
- blocked task has unblock action

## Evidence

- `plan_before`
- `plan_after`
- `plan_delta`
- `dependency_map`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
