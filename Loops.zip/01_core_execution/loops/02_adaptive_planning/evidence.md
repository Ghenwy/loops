# Evidence — F01.L02 adaptive_planning

## Required evidence

- `plan_before`: required for normal closure.
- `plan_after`: required for normal closure.
- `plan_delta`: required for normal closure.
- `dependency_map`: required for normal closure.
- `blocker_log`: required for normal closure.
- `priority_reason`: required for normal closure.
- `next_action`: required for normal closure.
- `plan_state`: required for normal closure.
- `task_graph`: required for normal closure.
- `priority_delta`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `plan_state` | adaptive_planning closure | yes |
| `task_graph` | adaptive_planning closure | yes |
| `dependency_map` | adaptive_planning closure | yes |
| `priority_delta` | adaptive_planning closure | yes |
| `blocker_log` | adaptive_planning closure | yes |
| `plan_revision_report` | adaptive_planning closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f01-l02-ok
loop_id: F01.L02
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  plan_state: present
  task_graph: present
  dependency_map: present
  priority_delta: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f01-l02-bad
loop_id: F01.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
