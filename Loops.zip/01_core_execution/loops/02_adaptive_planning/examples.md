# Examples — F01.L02 adaptive_planning

## Happy path

```yaml
task: "Run adaptive_planning on bounded input."
expected_status: completed
expected_output: "validated result with evidence bundle"
expected_evidence: ['plan_before', 'plan_after', 'plan_delta', 'dependency_map']
```

## Blocked path

```yaml
task: "Run adaptive_planning with missing critical context or permission."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_output: "blocked with explicit next required input"
expected_evidence: [blocker_reason, next_required_input]
```

## Failed path

```yaml
task: "Run adaptive_planning with invalid output or failed gate."
expected_status: failed
expected_reason: "validation_failed"
expected_output: "failed with failed_check and validation report"
expected_evidence: [failed_check, validation_report]
```

## Edge case

```yaml
task: "A new critical risk appears and the plan must reprioritize without discarding evidence."
expected_status: completed
expected_output: "edge case handled without hidden assumption"
expected_evidence: ['plan_before', 'plan_after', 'plan_delta', 'dependency_map', 'blocker_log']
expected_checks: [edge_case_result, validation_report, evidence_bundle]
```

## Expected checks

- expected_status must match fixture.
- expected_evidence must exist in final bundle.
- expected_output must be backed by validation.
