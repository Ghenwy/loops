# Loop — F01.L02 Adaptive Planning

## Operating intent

adaptive planning using task graph, dependency state, priority deltas and blocker recovery.

## OODA runtime

### Observe

- Load task input, current state, prior evidence and fixture expectations.
- Inspect these artifacts: plan_state, task_graph, dependency_map, priority_delta.
- Mark missing inputs, stale evidence and unsafe assumptions before acting.

### Orient

- Apply domain gates before choosing an action.
- Required gates: plan changes require delta evidence, blocked dependency has next action, priority change has cause, completed plan has no unresolved critical task.
- Split notes into `[evidence]`, `[inference]` and `[unknown]`.

### Decide

- Select one atomic action that improves validation, evidence or safety.
- Block if the first critical gate cannot be checked.
- Escalate only when risk or contradiction is explicit.

### Act

- Update the smallest artifact set needed: plan_state, task_graph, dependency_map.
- Capture command/tool/model inputs and outputs.
- Persist provisional evidence before validation.

### Validate

- Run structural, semantic, domain, negative and fixture checks.
- Execute happy, blocked, failed and edge fixtures.
- Reject completion when evidence is absent or the edge case is unresolved.

## Premium validation gates

- PVG-01: plan changes require delta evidence.
- PVG-02: blocked dependency has next action.
- PVG-03: priority change has cause.
- PVG-04: completed plan has no unresolved critical task.

## Failure handling

- `blocked`: missing permission, missing source, critical ambiguity or unsafe policy.
- `failed`: validation failure, negative case accepted, evidence missing or rollback failure.
- `completed`: all premium gates pass and the final evidence bundle is complete.

## Edge case

A new critical risk appears and the plan must reprioritize without discarding evidence.

## Final output

Return status, iterations, validation result, evidence IDs, unresolved risks and next action.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.
