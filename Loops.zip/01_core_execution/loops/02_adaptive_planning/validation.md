# Validation — F01.L02 adaptive_planning

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F01.L02`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: plan changes require delta evidence.
- DC-02: blocked dependency has next action.
- DC-03: priority change has cause.
- DC-04: completed plan has no unresolved critical task.
- DC-05: artifact `plan_state` is present.
- DC-06: artifact `task_graph` is present.
- DC-07: artifact `dependency_map` is present.
- DC-08: artifact `priority_delta` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: ready_task_count, blocked_task_count, plan_delta_size, dependency_failures.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: A new critical risk appears and the plan must reprioritize without discarding evidence.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.

## Domain term audit anchors

`task_graph`, `dependency`, `priority_shift`, `plan_delta`, `blocker`, `critical_path`, `replan_reason`, `next_action`, `plan_state`, `dependency_map`, `priority_delta`, `blocker_log`, `plan_revision_report`

## Domain term coverage

This premium validation explicitly checks: `task_graph`, `dependency`, `priority_shift`, `plan_delta`, `blocker`, `critical_path`, `replan_reason`, `next_action`.
