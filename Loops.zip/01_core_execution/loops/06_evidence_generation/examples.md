# Examples — F01.L06 evidence_generation

## Happy path

```yaml
task: "Run evidence_generation on bounded input."
expected_status: completed
expected_output: "validated result with evidence bundle"
expected_evidence: ['evidence_bundle', 'domain_matrix', 'source_hashes', 'validation_trace']
```

## Blocked path

```yaml
task: "Run evidence_generation with missing critical context or permission."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_output: "blocked with explicit next required input"
expected_evidence: [blocker_reason, next_required_input]
```

## Failed path

```yaml
task: "Run evidence_generation with invalid output or failed gate."
expected_status: failed
expected_reason: "validation_failed"
expected_output: "failed with failed_check and validation report"
expected_evidence: [failed_check, validation_report]
```

## Edge case

```yaml
task: "An output is correct but has no validation source; the evidence loop keeps it unresolved."
expected_status: completed
expected_output: "edge case handled without hidden assumption"
expected_evidence: ['evidence_bundle', 'domain_matrix', 'source_hashes', 'validation_trace', 'rejected_evidence_log']
expected_checks: [edge_case_result, validation_report, evidence_bundle]
```

## Expected checks

- expected_status must match fixture.
- expected_evidence must exist in final bundle.
- expected_output must be backed by validation.
