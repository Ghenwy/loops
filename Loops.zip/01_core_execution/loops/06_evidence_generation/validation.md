# Validation — F01.L06 evidence_generation

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F01.L06`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: completion requires evidence bundle.
- DC-02: evidence links to action and validation.
- DC-03: invalid evidence is rejected.
- DC-04: domain fields are present.
- DC-05: artifact `evidence_schema` is present.
- DC-06: artifact `domain_evidence_matrix` is present.
- DC-07: artifact `valid_evidence_bundle` is present.
- DC-08: artifact `rejected_evidence_case` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: evidence_items, missing_required_evidence, rejected_evidence_count, bundle_completeness.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: An output is correct but has no validation source; the evidence loop keeps it unresolved.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.

## Domain term audit anchors

`evidence_bundle`, `evidence_id`, `validation_trace`, `domain_evidence`, `rejected_evidence`, `source_hash`, `audit_trail`, `final_report`, `evidence_schema`, `domain_evidence_matrix`, `valid_evidence_bundle`, `rejected_evidence_case`, `final_report_links`, `evidence_validator_output`

## Domain term coverage

This premium validation explicitly checks: `evidence_bundle`, `evidence_id`, `validation_trace`, `domain_evidence`, `rejected_evidence`, `source_hash`, `audit_trail`, `final_report`.
