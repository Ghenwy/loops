# Loop — F01.L06 Evidence Generation

## Operating intent

evidence generation with domain bundle, valid/rejected examples and final-report linkage.

## OODA runtime

### Observe

- Load task input, current state, prior evidence and fixture expectations.
- Inspect these artifacts: evidence_schema, domain_evidence_matrix, valid_evidence_bundle, rejected_evidence_case.
- Mark missing inputs, stale evidence and unsafe assumptions before acting.

### Orient

- Apply domain gates before choosing an action.
- Required gates: completion requires evidence bundle, evidence links to action and validation, invalid evidence is rejected, domain fields are present.
- Split notes into `[evidence]`, `[inference]` and `[unknown]`.

### Decide

- Select one atomic action that improves validation, evidence or safety.
- Block if the first critical gate cannot be checked.
- Escalate only when risk or contradiction is explicit.

### Act

- Update the smallest artifact set needed: evidence_schema, domain_evidence_matrix, valid_evidence_bundle.
- Capture command/tool/model inputs and outputs.
- Persist provisional evidence before validation.

### Validate

- Run structural, semantic, domain, negative and fixture checks.
- Execute happy, blocked, failed and edge fixtures.
- Reject completion when evidence is absent or the edge case is unresolved.

## Premium validation gates

- PVG-01: completion requires evidence bundle.
- PVG-02: evidence links to action and validation.
- PVG-03: invalid evidence is rejected.
- PVG-04: domain fields are present.

## Failure handling

- `blocked`: missing permission, missing source, critical ambiguity or unsafe policy.
- `failed`: validation failure, negative case accepted, evidence missing or rollback failure.
- `completed`: all premium gates pass and the final evidence bundle is complete.

## Edge case

An output is correct but has no validation source; the evidence loop keeps it unresolved.

## Final output

Return status, iterations, validation result, evidence IDs, unresolved risks and next action.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.
