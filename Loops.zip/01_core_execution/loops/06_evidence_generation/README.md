# Evidence Generation

## ID

F01.L06

## Score

Tier `S` / score `98`.

## Purpose

evidence generation with domain bundle, valid/rejected examples and final-report linkage.

## Use when

- task must be auditable
- final answer needs proof
- loop execution changes files or decisions

## Avoid when

- pure conversation with no claim to validate

## Domain markers

`evidence_bundle`, `evidence_id`, `validation_trace`, `domain_evidence`, `rejected_evidence`, `source_hash`

## Required gates

- evidence_id unique
- timestamp present
- domain_evidence matrix applied
- changed files listed

## Evidence

- `evidence_bundle`
- `domain_matrix`
- `source_hashes`
- `validation_trace`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
