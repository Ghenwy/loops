# Evidence — F01.L06 evidence_generation

## Required evidence

- `evidence_bundle`: required for normal closure.
- `domain_matrix`: required for normal closure.
- `source_hashes`: required for normal closure.
- `validation_trace`: required for normal closure.
- `rejected_evidence_log`: required for normal closure.
- `final_report_link`: required for normal closure.
- `evidence_schema`: required for normal closure.
- `domain_evidence_matrix`: required for normal closure.
- `valid_evidence_bundle`: required for normal closure.
- `rejected_evidence_case`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `evidence_schema` | evidence_generation closure | yes |
| `domain_evidence_matrix` | evidence_generation closure | yes |
| `valid_evidence_bundle` | evidence_generation closure | yes |
| `rejected_evidence_case` | evidence_generation closure | yes |
| `final_report_links` | evidence_generation closure | yes |
| `evidence_validator_output` | evidence_generation closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f01-l06-ok
loop_id: F01.L06
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  evidence_schema: present
  domain_evidence_matrix: present
  valid_evidence_bundle: present
  rejected_evidence_case: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f01-l06-bad
loop_id: F01.L06
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
