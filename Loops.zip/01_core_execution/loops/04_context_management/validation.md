# Validation — F01.L04 context_management

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F01.L04`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: no memory entry without source binding.
- DC-02: inference cannot be saved as fact.
- DC-03: stale memories require invalidation or expiry.
- DC-04: compression must preserve decisions, risks and blockers.
- DC-05: artifact `source_scorecard` is present.
- DC-06: artifact `context_budget` is present.
- DC-07: artifact `read_skip_matrix` is present.
- DC-08: artifact `fact_inference_unknown_table` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: context_tokens_estimated, sources_read, sources_skipped, pruning_ratio.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: The agent has many sources, but one critical source is stale; it must not close context as sufficient.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.

## Domain term audit anchors

`context_budget`, `source_score`, `required_source`, `stale_source`, `pruning`, `evidence_inference_unknown`, `context_pack`, `saturation_guard`, `source_scorecard`, `read_skip_matrix`, `fact_inference_unknown_table`, `pruning_log`, `sufficient_context_decision`

## Domain term coverage

This premium validation explicitly checks: `context_budget`, `source_score`, `required_source`, `stale_source`, `pruning`, `evidence_inference_unknown`, `context_pack`, `saturation_guard`.
