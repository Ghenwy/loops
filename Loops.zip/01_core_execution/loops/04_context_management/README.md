# Context Management

## ID

F01.L04

## Score

Tier `S` / score `98`.

## Purpose

context management with source scoring, budget, read/skip decision and unknown tracking.

## Use when

- many sources exist
- context budget is constrained
- evidence must be separated from inference

## Avoid when

- single authoritative source is already provided

## Domain markers

`context_budget`, `source_score`, `required_source`, `stale_source`, `pruning`, `evidence_inference_unknown`

## Required gates

- source_score exists for each source
- critical sources not skipped
- context budget enforced
- stale sources marked

## Evidence

- `source_inventory`
- `source_scores`
- `context_budget`
- `pruned_items`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
