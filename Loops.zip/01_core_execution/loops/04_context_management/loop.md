# Loop — F01.L04 Context Management

## Operating intent

context management with source scoring, budget, read/skip decision and unknown tracking.

## OODA runtime

### Observe

- Load task input, current state, prior evidence and fixture expectations.
- Inspect these artifacts: source_scorecard, context_budget, read_skip_matrix, fact_inference_unknown_table.
- Mark missing inputs, stale evidence and unsafe assumptions before acting.

### Orient

- Apply domain gates before choosing an action.
- Required gates: no memory entry without source binding, inference cannot be saved as fact, stale memories require invalidation or expiry, compression must preserve decisions, risks and blockers.
- Split notes into `[evidence]`, `[inference]` and `[unknown]`.

### Decide

- Select one atomic action that improves validation, evidence or safety.
- Block if the first critical gate cannot be checked.
- Escalate only when risk or contradiction is explicit.

### Act

- Update the smallest artifact set needed: source_scorecard, context_budget, read_skip_matrix.
- Capture command/tool/model inputs and outputs.
- Persist provisional evidence before validation.

### Validate

- Run structural, semantic, domain, negative and fixture checks.
- Execute happy, blocked, failed and edge fixtures.
- Reject completion when evidence is absent or the edge case is unresolved.

## Premium validation gates

- PVG-01: no memory entry without source binding.
- PVG-02: inference cannot be saved as fact.
- PVG-03: stale memories require invalidation or expiry.
- PVG-04: compression must preserve decisions, risks and blockers.

## Failure handling

- `blocked`: missing permission, missing source, critical ambiguity or unsafe policy.
- `failed`: validation failure, negative case accepted, evidence missing or rollback failure.
- `completed`: all premium gates pass and the final evidence bundle is complete.

## Edge case

The agent has many sources, but one critical source is stale; it must not close context as sufficient.

## Final output

Return status, iterations, validation result, evidence IDs, unresolved risks and next action.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.
