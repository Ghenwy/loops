# Evidence — F01.L04 context_management

## Required evidence

- `source_inventory`: required for normal closure.
- `source_scores`: required for normal closure.
- `context_budget`: required for normal closure.
- `pruned_items`: required for normal closure.
- `context_pack`: required for normal closure.
- `unknowns`: required for normal closure.
- `source_scorecard`: required for normal closure.
- `read_skip_matrix`: required for normal closure.
- `fact_inference_unknown_table`: required for normal closure.
- `pruning_log`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `source_scorecard` | context_management closure | yes |
| `context_budget` | context_management closure | yes |
| `read_skip_matrix` | context_management closure | yes |
| `fact_inference_unknown_table` | context_management closure | yes |
| `pruning_log` | context_management closure | yes |
| `sufficient_context_decision` | context_management closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f01-l04-ok
loop_id: F01.L04
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  source_scorecard: present
  context_budget: present
  read_skip_matrix: present
  fact_inference_unknown_table: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f01-l04-bad
loop_id: F01.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
