# Validation — F01.L01 adaptive_task_execution

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F01.L01`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: no unbounded iteration.
- DC-02: checkpoint after each validated step.
- DC-03: blocked state names missing input.
- DC-04: failed state records cause.
- DC-05: artifact `state_schema` is present.
- DC-06: artifact `checkpoint_log` is present.
- DC-07: artifact `decision_tree` is present.
- DC-08: artifact `partial_delivery` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: iterations_used, completion_ratio, blocked_reason_count, validation_pass_rate.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: The task reaches max_iterations after useful partial work and must deliver partial evidence instead of pretending completion.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.


## Rollback validation

- Rollback is required when state changes fail validation.
- The rollback plan, restore validation and post-rollback evidence must be present.
- Completion is rejected if rollback is impossible or undocumented.

## Domain term audit anchors

`checkpoint`, `atomic_action`, `partial_delivery`, `iteration_budget`, `state_transition`, `completion_criteria`, `recovery_point`, `final_report`, `state_schema`, `checkpoint_log`, `decision_tree`, `retry_policy`, `final_report_schema`

## Domain term coverage

This premium validation explicitly checks: `checkpoint`, `atomic_action`, `partial_delivery`, `iteration_budget`, `state_transition`, `completion_criteria`, `recovery_point`, `final_report`.
