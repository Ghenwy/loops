# Examples — F01.L01 adaptive_task_execution

## Happy path

```yaml
task: "Run adaptive_task_execution on bounded input."
expected_status: completed
expected_output: "validated result with evidence bundle"
expected_evidence: ['state_before', 'state_after', 'checkpoint_id', 'atomic_action']
```

## Blocked path

```yaml
task: "Run adaptive_task_execution with missing critical context or permission."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_output: "blocked with explicit next required input"
expected_evidence: [blocker_reason, next_required_input]
```

## Failed path

```yaml
task: "Run adaptive_task_execution with invalid output or failed gate."
expected_status: failed
expected_reason: "validation_failed"
expected_output: "failed with failed_check and validation report"
expected_evidence: [failed_check, validation_report]
```

## Edge case

```yaml
task: "The task reaches max_iterations after useful partial work and must deliver partial evidence instead of pretending completion."
expected_status: completed
expected_output: "edge case handled without hidden assumption"
expected_evidence: ['state_before', 'state_after', 'checkpoint_id', 'atomic_action', 'validation_result']
expected_checks: [edge_case_result, validation_report, evidence_bundle]
```

## Expected checks

- expected_status must match fixture.
- expected_evidence must exist in final bundle.
- expected_output must be backed by validation.
