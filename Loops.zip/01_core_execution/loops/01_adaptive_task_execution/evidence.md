# Evidence — F01.L01 adaptive_task_execution

## Required evidence

- `state_before`: required for normal closure.
- `state_after`: required for normal closure.
- `checkpoint_id`: required for normal closure.
- `atomic_action`: required for normal closure.
- `validation_result`: required for normal closure.
- `partial_delivery`: required for normal closure.
- `final_report`: required for normal closure.
- `changed_paths`: required for normal closure.
- `state_schema`: required for normal closure.
- `checkpoint_log`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `state_schema` | adaptive_task_execution closure | yes |
| `checkpoint_log` | adaptive_task_execution closure | yes |
| `decision_tree` | adaptive_task_execution closure | yes |
| `iteration_evidence` | adaptive_task_execution closure | yes |
| `partial_delivery` | adaptive_task_execution closure | yes |
| `final_report_schema` | adaptive_task_execution closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f01-l01-ok
loop_id: F01.L01
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  state_schema: present
  checkpoint_log: present
  decision_tree: present
  iteration_evidence: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f01-l01-bad
loop_id: F01.L01
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.


## Rollback validation

- Rollback is required when state changes fail validation.
- The rollback plan, restore validation and post-rollback evidence must be present.
- Completion is rejected if rollback is impossible or undocumented.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.
