# Adaptive Task Execution

## ID

F01.L01

## Score

Tier `S+` / score `101`.

## Purpose

canonical bounded OODA task runtime with checkpoints, partial delivery and final report.

## Use when

- task has multiple steps
- state can change during execution
- agent must continue without losing context

## Avoid when

- single trivial answer
- no validation can be defined

## Domain markers

`checkpoint`, `atomic_action`, `partial_delivery`, `iteration_budget`, `state_transition`, `completion_criteria`

## Required gates

- state has pending/running/blocked/completed/failed only
- checkpoint exists before risky action
- max_iterations stops execution
- partial result is deliverable when blocked

## Evidence

- `state_before`
- `state_after`
- `checkpoint_id`
- `atomic_action`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
