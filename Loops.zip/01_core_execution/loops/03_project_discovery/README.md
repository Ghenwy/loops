# Project Discovery

## ID

F01.L03

## Score

Tier `C` / score `76`.

## Purpose

Discover a project before modification by mapping stack, rules, tests, entrypoints, risks and working conventions.

## Use when

- repo is unknown
- agent must modify code later
- onboarding requires real project map

## Avoid when

- user already provided authoritative project map
- task only asks for isolated text

## Domain markers

`repo_tree`, `stack_detector`, `entrypoint`, `config_file`, `test_command`, `ci_file`

## Required gates

- README inspected or missing recorded
- config files mapped
- test command found or unknown
- entrypoints listed

## Evidence

- `repo_tree_summary`
- `files_inspected`
- `stack_map`
- `command_inventory`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
