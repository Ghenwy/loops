# Project Discovery — Loop Definition

    ## Identity

    - Loop ID: `F01.L03`
    - Family: `F01 — Core Execution`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Discover a project before modification by mapping stack, rules, tests, entrypoints, risks and working conventions.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `repo_tree`, `stack_detector`, `entrypoint`, `config_file`, `test_command`, `ci_file`, `convention`, `risk_map`

    ## Use when

- repo is unknown
- agent must modify code later
- onboarding requires real project map

## Avoid when
- user already provided authoritative project map
- task only asks for isolated text

## OODA execution

### Observe

1. list repo tree and root files.
2. read README, configs, package manifests and CI files.
3. inspect tests, scripts and entrypoints.

### Orient

1. infer stack and conventions from files not guesses.
2. map rules, generated files and unsafe zones.
3. classify modification risk by area.

### Decide

1. choose next source to inspect by uncertainty.
2. stop discovery when stack/rules/tests are sufficient.
3. defer writes until discovery complete.

### Act

1. create project map and command inventory.
2. record detected test/build/lint commands.
3. mark unknowns and unverified assumptions.

### Validate

1. verify commands exist before recommending them.
2. check map covers stack/rules/tests/risks.
3. reject unsupported claims.

### Evidence

- `repo_tree_summary`
- `files_inspected`
- `stack_map`
- `command_inventory`
- `risk_map`
- `unknowns`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: README inspected or missing recorded.
- CHECK-02: config files mapped.
- CHECK-03: test command found or unknown.
- CHECK-04: entrypoints listed.
- CHECK-05: CI files checked.
- CHECK-06: rules/conventions listed.
- CHECK-07: risk map exists.
- CHECK-08: unsupported assumptions marked unknown.

## Metrics

- `files_inspected_count`
- `unknown_count`
- `commands_detected`
- `risk_count`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
