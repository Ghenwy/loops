# Evidence — F01.L03 project_discovery

    ## Required evidence

- `repo_tree_summary`: required for normal closure.
- `files_inspected`: required for normal closure.
- `stack_map`: required for normal closure.
- `command_inventory`: required for normal closure.
- `risk_map`: required for normal closure.
- `unknowns`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F01.L03
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  repo_tree_summary: present
  files_inspected: present
  stack_map: present
  command_inventory: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F01.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
