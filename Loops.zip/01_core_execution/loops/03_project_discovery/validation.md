# Validation — F01.L03 project_discovery

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F01.L03`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: README inspected or missing recorded.
- DC-02: config files mapped.
- DC-03: test command found or unknown.
- DC-04: entrypoints listed.
- DC-05: CI files checked.
- DC-06: rules/conventions listed.
- DC-07: risk map exists.
- DC-08: unsupported assumptions marked unknown.

## Negative checks

- Reject if `repo_tree` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: repo_tree, stack_detector, entrypoint, config_file, test_command, ci_file, convention, risk_map.


## Domain term audit anchors

`repo_tree`, `stack_detector`, `entrypoint`, `config_file`, `test_command`, `ci_file`, `convention`, `risk_map`
