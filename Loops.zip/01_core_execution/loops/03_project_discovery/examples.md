# Examples — F01.L03 Project Discovery

  ## Happy path

  ```yaml
  task: "Run project_discovery on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- repo_tree_summary
- files_inspected
- stack_map
- command_inventory
  expected_checks:
    - "README inspected or missing recorded"
    - "config files mapped"
  ```

  ## Blocked path

  ```yaml
  task: "Run project_discovery with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run project_discovery with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
