# Local Embeddings Bare Metal

## ID

F06.L01

## Score

Tier `S` / score `100`.

## Purpose

Local embedding pipelines without ollama or lm studio, with backend, chunking, index and retrieval evaluation.

## Use when

- offline/local RAG is needed
- documents are sensitive
- embedding backend must be explicit

## Avoid when

- remote embedding service is mandated

## Domain markers

`embedding_backend`, `model_metadata`, `tokenizer_policy`, `chunking_strategy`, `vector_index`, `retrieval_eval`

## Required gates

- model loads locally
- backend declared
- dimensions recorded
- tokenizer known

## Evidence

- `model_card_local`
- `backend_config`
- `chunking_policy`
- `vector_index_manifest`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
