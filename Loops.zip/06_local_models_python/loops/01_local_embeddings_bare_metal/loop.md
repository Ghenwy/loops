# Local Embeddings Bare Metal — Premium Loop

## Identity

- Loop ID: `F06.L01`
- Family: `F06 — Local Models & Python Agents`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Local embedding pipelines without ollama or lm studio, with backend, chunking, index and retrieval evaluation.

## Why this loop matters

Unlocks private, local semantic memory and rag without wrapper dependency.

## Premium artifacts

- `model_card_local`
- `backend_config`
- `chunking_policy`
- `vector_index_manifest`
- `query_eval_set`
- `retrieval_metrics`
- `rebuild_plan`

## OODA execution

### Observe

- Capture `model_card_local` and `backend_config`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `model loads locally` and `backend declared`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `recall_at_k` and `latency_ms`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- model loads locally.
- backend declared.
- dimensions recorded.
- tokenizer known.
- chunking policy set.
- index rebuildable.
- query eval set present.
- recall@k measured.
- latency measured.
- corpus hash captured.
- no external wrapper required.
- privacy boundary documented.

## Evidence contract

- `model_card_local`
- `backend_config`
- `chunking_policy`
- `vector_index_manifest`
- `query_eval_set`
- `retrieval_metrics`
- `latency_report`
- `corpus_hash`

## Edge case

Model loads but embedding dimension changes after swap; expected failed until index rebuild is performed.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `backend_matrix`
- `model_metadata`
- `chunking_policy`
- `vector_index_manifest`
- `retrieval_query_set`
- `recall_at_k_report`

### Quality gates
- EM-01: backend_matrix excludes Ollama/LM Studio dependency
- EM-02: model_metadata records name/path/dimensions/tokenizer
- EM-03: chunking_policy is explicit
- EM-04: vector_index_manifest records metric and rebuild plan
- EM-05: retrieval_query_set runs known queries
- EM-06: recall_at_k_report meets threshold

### Merge boundary
Keep separate from local_knowledge_graph: embeddings support semantic similarity; graph stores typed relationships.
