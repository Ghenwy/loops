# Examples — F06.L01 Local Embeddings Bare Metal

## Happy path

```yaml
task: "Run local_embeddings_bare_metal with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - model_card_local
  - backend_config
  - chunking_policy
expected_checks:
  - model loads locally
  - backend declared
```

## Blocked path

```yaml
task: "Run local_embeddings_bare_metal with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run local_embeddings_bare_metal with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Model loads but embedding dimension changes after swap; expected failed until index rebuild is performed."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails model loads locally."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

