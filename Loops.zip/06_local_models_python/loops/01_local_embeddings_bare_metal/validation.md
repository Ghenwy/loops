# Validation — F06.L01 local_embeddings_bare_metal

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F06.L01`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: model loads locally.
- PV-02: backend declared.
- PV-03: dimensions recorded.
- PV-04: tokenizer known.
- PV-05: chunking policy set.
- PV-06: index rebuildable.
- PV-07: query eval set present.
- PV-08: recall@k measured.
- PV-09: latency measured.
- PV-10: corpus hash captured.
- PV-11: no external wrapper required.
- PV-12: privacy boundary documented.

## Domain checks

- DC-01: `model loads locally` must be represented in contract, examples and evidence.
- DC-02: `backend declared` must be represented in contract, examples and evidence.
- DC-03: `dimensions recorded` must be represented in contract, examples and evidence.
- DC-04: `tokenizer known` must be represented in contract, examples and evidence.
- DC-05: `chunking policy set` must be represented in contract, examples and evidence.
- DC-06: `index rebuildable` must be represented in contract, examples and evidence.
- DC-07: `query eval set present` must be represented in contract, examples and evidence.
- DC-08: `recall@k measured` must be represented in contract, examples and evidence.
- DC-09: `latency measured` must be represented in contract, examples and evidence.
- DC-10: `corpus hash captured` must be represented in contract, examples and evidence.
- DC-11: `no external wrapper required` must be represented in contract, examples and evidence.
- DC-12: `privacy boundary documented` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `model_card_local` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Model loads but embedding dimension changes after swap; expected failed until index rebuild is performed.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`embedding_backend`, `model_metadata`, `tokenizer_policy`, `chunking_strategy`, `vector_index`, `retrieval_eval`, `recall_at_k`, `rebuild_policy`, `model_card_local`, `backend_config`, `chunking_policy`, `vector_index_manifest`, `query_eval_set`, `retrieval_metrics`, `rebuild_plan`, `latency_report`, `corpus_hash`, `latency_ms`, `embedding_dim`, `index_size`

## Domain term coverage

This premium validation explicitly checks: `embedding_backend`, `model_metadata`, `tokenizer_policy`, `chunking_strategy`, `vector_index`, `retrieval_eval`, `recall_at_k`, `rebuild_policy`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- EM-01: backend_matrix excludes Ollama/LM Studio dependency
- EM-02: model_metadata records name/path/dimensions/tokenizer
- EM-03: chunking_policy is explicit
- EM-04: vector_index_manifest records metric and rebuild plan
- EM-05: retrieval_query_set runs known queries
- EM-06: recall_at_k_report meets threshold

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from local_knowledge_graph: embeddings support semantic similarity; graph stores typed relationships.
