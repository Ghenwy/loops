# Evidence — F06.L01 local_embeddings_bare_metal

## Required evidence

- `model_card_local`: required for premium closure.
- `backend_config`: required for premium closure.
- `chunking_policy`: required for premium closure.
- `vector_index_manifest`: required for premium closure.
- `query_eval_set`: required for premium closure.
- `retrieval_metrics`: required for premium closure.
- `latency_report`: required for premium closure.
- `corpus_hash`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `model_card_local` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `backend_config` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `chunking_policy` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `vector_index_manifest` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `query_eval_set` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `retrieval_metrics` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `latency_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-local_embeddings_bare_metal-premium
loop_id: F06.L01
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  model_card_local: present
  backend_config: present
  chunking_policy: present
  vector_index_manifest: present
  query_eval_set: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F06.L01
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `backend_matrix`: required for target A maturity.
- `model_metadata`: required for target A maturity.
- `chunking_policy`: required for target A maturity.
- `vector_index_manifest`: required for target A maturity.
- `retrieval_query_set`: required for target A maturity.
- `recall_at_k_report`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from local_knowledge_graph: embeddings support semantic similarity; graph stores typed relationships.
