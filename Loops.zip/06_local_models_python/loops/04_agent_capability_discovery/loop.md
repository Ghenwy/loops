# Agent Capability Discovery — Loop Definition

    ## Identity

    - Loop ID: `F06.L04`
    - Family: `F06 — Local Models & Python Agents`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Discover actual capabilities of agent/model/CLI/runtime through probes instead of assuming tools, permissions or packages.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `capability_profile`, `tool_probe`, `filesystem_probe`, `network_probe`, `model_probe`, `permission_probe`, `smoke_test`, `limit`

    ## Use when

- environment may differ
- routing depends on capability
- agent must know limits

## Avoid when
- capabilities are already verified in current session

## OODA execution

### Observe

1. list tools, models, filesystem and package access.
2. run non-destructive probes.
3. capture permissions and limits.

### Orient

1. classify verified, unavailable and unknown capabilities.
2. map task needs to capability profile.
3. identify unsafe assumptions.

### Decide

1. assign compatible work or block.
2. choose fallback for missing capability.
3. require smoke test for critical tool.

### Act

1. write capability_profile.
2. run smoke tests.
3. update routing constraints.

### Validate

1. capability marked verified only after probe.
2. unknown capabilities not used.
3. profile timestamp recorded.

### Evidence

- `capability_profile`
- `probe_results`
- `smoke_tests`
- `permission_matrix`
- `unknown_capabilities`
- `routing_constraints`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: tool probe run.
- CHECK-02: filesystem probe run.
- CHECK-03: model probe run.
- CHECK-04: network probe handled.
- CHECK-05: permission probe recorded.
- CHECK-06: smoke test exists.
- CHECK-07: unknowns visible.
- CHECK-08: verified status has evidence.

## Metrics

- `verified_capabilities`
- `unknown_capabilities`
- `probe_failures`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
