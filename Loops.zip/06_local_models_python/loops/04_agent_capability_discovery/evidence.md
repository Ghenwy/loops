# Evidence — F06.L04 agent_capability_discovery

    ## Required evidence

- `capability_profile`: required for normal closure.
- `probe_results`: required for normal closure.
- `smoke_tests`: required for normal closure.
- `permission_matrix`: required for normal closure.
- `unknown_capabilities`: required for normal closure.
- `routing_constraints`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F06.L04
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  capability_profile: present
  probe_results: present
  smoke_tests: present
  permission_matrix: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F06.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
