# Examples — F06.L04 Agent Capability Discovery

  ## Happy path

  ```yaml
  task: "Run agent_capability_discovery on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- capability_profile
- probe_results
- smoke_tests
- permission_matrix
  expected_checks:
    - "tool probe run"
    - "filesystem probe run"
  ```

  ## Blocked path

  ```yaml
  task: "Run agent_capability_discovery with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run agent_capability_discovery with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
