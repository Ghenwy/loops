# Validation — F06.L04 agent_capability_discovery

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F06.L04`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: tool probe run.
- DC-02: filesystem probe run.
- DC-03: model probe run.
- DC-04: network probe handled.
- DC-05: permission probe recorded.
- DC-06: smoke test exists.
- DC-07: unknowns visible.
- DC-08: verified status has evidence.

## Negative checks

- Reject if `capability_profile` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: capability_profile, tool_probe, filesystem_probe, network_probe, model_probe, permission_probe, smoke_test, limit.


## Domain term audit anchors

`capability_profile`, `tool_probe`, `filesystem_probe`, `network_probe`, `model_probe`, `permission_probe`, `smoke_test`, `limit`
