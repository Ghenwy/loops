# Agent Capability Discovery

## ID

F06.L04

## Score

Tier `C` / score `76`.

## Purpose

Discover actual capabilities of agent/model/CLI/runtime through probes instead of assuming tools, permissions or packages.

## Use when

- environment may differ
- routing depends on capability
- agent must know limits

## Avoid when

- capabilities are already verified in current session

## Domain markers

`capability_profile`, `tool_probe`, `filesystem_probe`, `network_probe`, `model_probe`, `permission_probe`

## Required gates

- tool probe run
- filesystem probe run
- model probe run
- network probe handled

## Evidence

- `capability_profile`
- `probe_results`
- `smoke_tests`
- `permission_matrix`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
