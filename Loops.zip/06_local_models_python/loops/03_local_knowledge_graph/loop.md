# Local Knowledge Graph — Premium Loop

## Identity

- Loop ID: `F06.L03`
- Family: `F06 — Local Models & Python Agents`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Building local graphs of entities, relationships, decisions, modules and risks with source-bound edges.

## Why this loop matters

Adds structure where embeddings alone become a semantic soup.

## Premium artifacts

- `node_schema`
- `edge_schema`
- `entity_extraction_log`
- `relation_extraction_log`
- `source_binding_table`
- `graph_query_set`
- `stale_node_report`

## OODA execution

### Observe

- Capture `node_schema` and `edge_schema`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `node schema defined` and `edge schema defined`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `node_count` and `edge_count`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- node schema defined.
- edge schema defined.
- source binding required.
- entities extracted.
- relations typed.
- inferred edges marked.
- duplicate nodes merged.
- stale nodes flagged.
- queries return expected answers.
- orphan nodes reviewed.
- graph update incremental.
- export reproducible.

## Evidence contract

- `node_schema`
- `edge_schema`
- `entity_extraction_log`
- `relation_extraction_log`
- `source_binding_table`
- `graph_query_set`
- `query_result_report`

## Edge case

Relation is inferred without source evidence; expected marked inference or rejected.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target B

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `B` with score >= 84.

### Required artifacts
- `node_schema`
- `edge_schema`
- `source_binding`
- `relation_validation`
- `query_suite`

### Quality gates
- KG-01: node_schema requires type and source
- KG-02: edge_schema records relation and confidence
- KG-03: source_binding links each graph fact to evidence
- KG-04: relation_validation separates evidence from inference
- KG-05: query_suite answers known graph questions

### Merge boundary
Keep separate from local_embeddings_bare_metal: graph gives typed relations; embeddings give semantic retrieval.
