# Examples — F06.L03 Local Knowledge Graph

## Happy path

```yaml
task: "Run local_knowledge_graph with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - node_schema
  - edge_schema
  - entity_extraction_log
expected_checks:
  - node schema defined
  - edge schema defined
```

## Blocked path

```yaml
task: "Run local_knowledge_graph with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run local_knowledge_graph with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Relation is inferred without source evidence; expected marked inference or rejected."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails node schema defined."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

