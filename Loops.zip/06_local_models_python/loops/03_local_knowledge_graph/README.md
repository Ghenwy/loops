# Local Knowledge Graph

## ID

F06.L03

## Score

Tier `S` / score `98`.

## Purpose

Building local graphs of entities, relationships, decisions, modules and risks with source-bound edges.

## Use when

- project knowledge needs structure
- embeddings alone are insufficient
- entities/relations matter

## Avoid when

- flat search is enough

## Domain markers

`node_schema`, `edge_schema`, `entity_extraction`, `relation_extraction`, `source_binding`, `typed_edge`

## Required gates

- node schema defined
- edge schema defined
- source binding required
- entities extracted

## Evidence

- `node_schema`
- `edge_schema`
- `entity_extraction_log`
- `relation_extraction_log`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
