# Evidence — F06.L03 local_knowledge_graph

## Required evidence

- `node_schema`: required for premium closure.
- `edge_schema`: required for premium closure.
- `entity_extraction_log`: required for premium closure.
- `relation_extraction_log`: required for premium closure.
- `source_binding_table`: required for premium closure.
- `graph_query_set`: required for premium closure.
- `query_result_report`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `node_schema` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `edge_schema` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `entity_extraction_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `relation_extraction_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `source_binding_table` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `graph_query_set` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `query_result_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-local_knowledge_graph-premium
loop_id: F06.L03
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  node_schema: present
  edge_schema: present
  entity_extraction_log: present
  relation_extraction_log: present
  source_binding_table: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F06.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Baseline upgrade evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `node_schema`: required for target B maturity.
- `edge_schema`: required for target B maturity.
- `source_binding`: required for target B maturity.
- `relation_validation`: required for target B maturity.
- `query_suite`: required for target B maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from local_embeddings_bare_metal: graph gives typed relations; embeddings give semantic retrieval.
