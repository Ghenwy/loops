# Validation — F06.L03 local_knowledge_graph

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F06.L03`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: node schema defined.
- PV-02: edge schema defined.
- PV-03: source binding required.
- PV-04: entities extracted.
- PV-05: relations typed.
- PV-06: inferred edges marked.
- PV-07: duplicate nodes merged.
- PV-08: stale nodes flagged.
- PV-09: queries return expected answers.
- PV-10: orphan nodes reviewed.
- PV-11: graph update incremental.
- PV-12: export reproducible.

## Domain checks

- DC-01: `node schema defined` must be represented in contract, examples and evidence.
- DC-02: `edge schema defined` must be represented in contract, examples and evidence.
- DC-03: `source binding required` must be represented in contract, examples and evidence.
- DC-04: `entities extracted` must be represented in contract, examples and evidence.
- DC-05: `relations typed` must be represented in contract, examples and evidence.
- DC-06: `inferred edges marked` must be represented in contract, examples and evidence.
- DC-07: `duplicate nodes merged` must be represented in contract, examples and evidence.
- DC-08: `stale nodes flagged` must be represented in contract, examples and evidence.
- DC-09: `queries return expected answers` must be represented in contract, examples and evidence.
- DC-10: `orphan nodes reviewed` must be represented in contract, examples and evidence.
- DC-11: `graph update incremental` must be represented in contract, examples and evidence.
- DC-12: `export reproducible` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `node_schema` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Relation is inferred without source evidence; expected marked inference or rejected.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`node_schema`, `edge_schema`, `entity_extraction`, `relation_extraction`, `source_binding`, `typed_edge`, `stale_node`, `graph_query`, `entity_extraction_log`, `relation_extraction_log`, `source_binding_table`, `graph_query_set`, `stale_node_report`, `query_result_report`, `node_count`, `edge_count`, `query_pass_rate`, `orphan_nodes`, `building`, `entities`

## Domain term coverage

This premium validation explicitly checks: `node_schema`, `edge_schema`, `entity_extraction`, `relation_extraction`, `source_binding`, `typed_edge`, `stale_node`, `graph_query`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Baseline upgrade gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- KG-01: node_schema requires type and source
- KG-02: edge_schema records relation and confidence
- KG-03: source_binding links each graph fact to evidence
- KG-04: relation_validation separates evidence from inference
- KG-05: query_suite answers known graph questions

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from local_embeddings_bare_metal: graph gives typed relations; embeddings give semantic retrieval.
