# Python Agent Orchestration

## ID

F06.L02

## Score

Tier `C` / score `76`.

## Purpose

Orchestrate Python agents with typed state, tool schemas, retry policy, validation and evidence-first runner.

## Use when

- agent should run as Python workflow
- tools need structured IO
- tests can validate behavior

## Avoid when

- plain text response is enough

## Domain markers

`pydantic_state`, `tool_schema`, `runner`, `retry_policy`, `typed_output`, `langgraph`

## Required gates

- typed state defined
- tool schema present
- runner loop bounded
- retry policy exists

## Evidence

- `state_schema`
- `tool_schema`
- `runner_trace`
- `validation_output`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
