# Python Agent Orchestration — Loop Definition

    ## Identity

    - Loop ID: `F06.L02`
    - Family: `F06 — Local Models & Python Agents`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Orchestrate Python agents with typed state, tool schemas, retry policy, validation and evidence-first runner.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `pydantic_state`, `tool_schema`, `runner`, `retry_policy`, `typed_output`, `langgraph`, `pydantic_ai`, `litellm`, `pytest_fixture`

    ## Use when

- agent should run as Python workflow
- tools need structured IO
- tests can validate behavior

## Avoid when
- plain text response is enough

## OODA execution

### Observe

1. load task, available Python packages and tool schemas.
2. inspect current agent state.
3. detect missing validators.

### Orient

1. choose state machine, graph or planner/executor pattern.
2. define typed outputs and retry policy.
3. map validation functions.

### Decide

1. execute next node/tool/model call.
2. block if schema or permission missing.
3. set evidence for runner step.

### Act

1. run Python agent step.
2. validate Pydantic output.
3. persist trace and errors.

### Validate

1. schema validation passes.
2. retry policy bounded.
3. fixture expected output matches result.

### Evidence

- `state_schema`
- `tool_schema`
- `runner_trace`
- `validation_output`
- `pytest_result`
- `error_log`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: typed state defined.
- CHECK-02: tool schema present.
- CHECK-03: runner loop bounded.
- CHECK-04: retry policy exists.
- CHECK-05: Pydantic validation used.
- CHECK-06: pytest fixture exists.
- CHECK-07: errors captured.
- CHECK-08: evidence per step recorded.

## Metrics

- `steps_run`
- `schema_failures`
- `retry_count`
- `fixture_pass`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
