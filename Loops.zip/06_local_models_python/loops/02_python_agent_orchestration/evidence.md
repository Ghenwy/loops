# Evidence — F06.L02 python_agent_orchestration

    ## Required evidence

- `state_schema`: required for normal closure.
- `tool_schema`: required for normal closure.
- `runner_trace`: required for normal closure.
- `validation_output`: required for normal closure.
- `pytest_result`: required for normal closure.
- `error_log`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F06.L02
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  state_schema: present
  tool_schema: present
  runner_trace: present
  validation_output: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F06.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
