# Validation — F06.L02 python_agent_orchestration

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F06.L02`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: typed state defined.
- DC-02: tool schema present.
- DC-03: runner loop bounded.
- DC-04: retry policy exists.
- DC-05: Pydantic validation used.
- DC-06: pytest fixture exists.
- DC-07: errors captured.
- DC-08: evidence per step recorded.

## Negative checks

- Reject if `pydantic_state` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: pydantic_state, tool_schema, runner, retry_policy, typed_output, langgraph, pydantic_ai, litellm.


## Domain term audit anchors

`pydantic_state`, `tool_schema`, `runner`, `retry_policy`, `typed_output`, `langgraph`, `pydantic_ai`, `litellm`, `pytest_fixture`
