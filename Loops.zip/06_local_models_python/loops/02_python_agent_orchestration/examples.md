# Examples — F06.L02 Python Agent Orchestration

  ## Happy path

  ```yaml
  task: "Run python_agent_orchestration on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- state_schema
- tool_schema
- runner_trace
- validation_output
  expected_checks:
    - "typed state defined"
    - "tool schema present"
  ```

  ## Blocked path

  ```yaml
  task: "Run python_agent_orchestration with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run python_agent_orchestration with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
