# Local Models & Python Agents Index

- F06.L01 `local_embeddings_bare_metal` — S/100
- F06.L02 `python_agent_orchestration` — C/76
- F06.L03 `local_knowledge_graph` — S/98
- F06.L04 `agent_capability_discovery` — C/76
