# Local Models & Python Agents

## Purpose

Local Models & Python Agents contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F06.L01 | `local_embeddings_bare_metal` | S | 100 |
| F06.L02 | `python_agent_orchestration` | C | 76 |
| F06.L03 | `local_knowledge_graph` | S | 98 |
| F06.L04 | `agent_capability_discovery` | C | 76 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
