# Architecture & Documentation

## Purpose

Architecture & Documentation contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F03.L01 | `architecture_decision` | C | 76 |
| F03.L02 | `impact_analysis` | C | 76 |
| F03.L03 | `living_documentation` | S | 99 |
| F03.L04 | `automatic_onboarding` | C | 76 |
| F03.L05 | `postmortem_learning` | C | 76 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
