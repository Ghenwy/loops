# Architecture Decision

## ID

F03.L01

## Score

Tier `C` / score `76`.

## Purpose

Record architecture decisions with drivers, constraints, options, trade-offs, consequences and review triggers.

## Use when

- decision has long-term impact
- multiple options exist
- trade-offs matter

## Avoid when

- implementation detail with no architectural consequence

## Domain markers

`ADR`, `driver`, `constraint`, `option`, `tradeoff`, `consequence`

## Required gates

- drivers listed
- constraints listed
- at least two options or defer reason
- tradeoffs explicit

## Evidence

- `ADR`
- `driver_matrix`
- `option_comparison`
- `tradeoff_log`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
