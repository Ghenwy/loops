# Evidence — F03.L01 architecture_decision

    ## Required evidence

- `ADR`: required for normal closure.
- `driver_matrix`: required for normal closure.
- `option_comparison`: required for normal closure.
- `tradeoff_log`: required for normal closure.
- `review_trigger`: required for normal closure.
- `impacted_artifacts`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F03.L01
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  ADR: present
  driver_matrix: present
  option_comparison: present
  tradeoff_log: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F03.L01
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
