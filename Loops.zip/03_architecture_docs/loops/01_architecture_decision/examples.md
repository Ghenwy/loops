# Examples — F03.L01 Architecture Decision

  ## Happy path

  ```yaml
  task: "Run architecture_decision on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- ADR
- driver_matrix
- option_comparison
- tradeoff_log
  expected_checks:
    - "drivers listed"
    - "constraints listed"
  ```

  ## Blocked path

  ```yaml
  task: "Run architecture_decision with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run architecture_decision with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
