# Architecture Decision — Loop Definition

    ## Identity

    - Loop ID: `F03.L01`
    - Family: `F03 — Architecture & Documentation`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Record architecture decisions with drivers, constraints, options, trade-offs, consequences and review triggers.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `ADR`, `driver`, `constraint`, `option`, `tradeoff`, `consequence`, `fitness_function`, `review_trigger`

    ## Use when

- decision has long-term impact
- multiple options exist
- trade-offs matter

## Avoid when
- implementation detail with no architectural consequence

## OODA execution

### Observe

1. collect requirements, constraints and stakeholders.
2. identify decision drivers and non-goals.
3. list current architecture facts.

### Orient

1. generate viable options and trade-offs.
2. evaluate options against drivers.
3. find risks and future review triggers.

### Decide

1. choose option or defer.
2. record rejected alternatives.
3. define fitness_function or validation method.

### Act

1. write ADR with context, decision and consequences.
2. link impacted docs/tests/contracts.
3. assign review trigger.

### Validate

1. check alternatives are real.
2. verify decision follows drivers.
3. ensure consequences are explicit.

### Evidence

- `ADR`
- `driver_matrix`
- `option_comparison`
- `tradeoff_log`
- `review_trigger`
- `impacted_artifacts`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: drivers listed.
- CHECK-02: constraints listed.
- CHECK-03: at least two options or defer reason.
- CHECK-04: tradeoffs explicit.
- CHECK-05: consequences present.
- CHECK-06: rejected options recorded.
- CHECK-07: fitness/review trigger exists.
- CHECK-08: ADR source links included.

## Metrics

- `options_count`
- `risk_count`
- `fitness_checks`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
