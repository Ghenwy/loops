# Validation — F03.L01 architecture_decision

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F03.L01`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: drivers listed.
- DC-02: constraints listed.
- DC-03: at least two options or defer reason.
- DC-04: tradeoffs explicit.
- DC-05: consequences present.
- DC-06: rejected options recorded.
- DC-07: fitness/review trigger exists.
- DC-08: ADR source links included.

## Negative checks

- Reject if `ADR` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: ADR, driver, constraint, option, tradeoff, consequence, fitness_function, review_trigger.


## Domain term audit anchors

`ADR`, `driver`, `constraint`, `option`, `tradeoff`, `consequence`, `fitness_function`, `review_trigger`
