# Impact Analysis — Loop Definition

    ## Identity

    - Loop ID: `F03.L02`
    - Family: `F03 — Architecture & Documentation`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Map blast radius of a proposed change across modules, contracts, tests, docs, owners and mitigation actions.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `blast_radius`, `dependency_graph`, `affected_tests`, `affected_docs`, `affected_contracts`, `owner`, `mitigation`, `risk_matrix`

    ## Use when

- change touches shared behavior
- dependencies are unclear
- risk must be scoped

## Avoid when
- isolated change with known local impact

## OODA execution

### Observe

1. inspect proposed change and dependency graph.
2. find affected modules, contracts, docs and tests.
3. identify owners or interfaces.

### Orient

1. classify impact by severity and likelihood.
2. map direct and indirect dependencies.
3. detect missing mitigation.

### Decide

1. accept scope, reduce scope or require mitigation.
2. choose validation for each impacted area.
3. escalate if blast_radius is high.

### Act

1. write impact matrix.
2. update test/doc checklist.
3. attach mitigation plan.

### Validate

1. verify every affected area has validation.
2. check high-risk impacts have owner/action.
3. reject unknown blast radius for risky change.

### Evidence

- `impact_matrix`
- `dependency_graph`
- `affected_tests`
- `affected_docs`
- `affected_contracts`
- `mitigation_plan`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: dependency graph or import map exists.
- CHECK-02: affected tests listed.
- CHECK-03: affected docs listed.
- CHECK-04: contracts checked.
- CHECK-05: risk matrix present.
- CHECK-06: mitigation plan exists.
- CHECK-07: high-risk owner/action set.
- CHECK-08: unknown impact not hidden.

## Metrics

- `affected_modules`
- `risk_score`
- `unknown_impacts`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
