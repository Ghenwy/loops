# Evidence — F03.L02 impact_analysis

    ## Required evidence

- `impact_matrix`: required for normal closure.
- `dependency_graph`: required for normal closure.
- `affected_tests`: required for normal closure.
- `affected_docs`: required for normal closure.
- `affected_contracts`: required for normal closure.
- `mitigation_plan`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F03.L02
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  impact_matrix: present
  dependency_graph: present
  affected_tests: present
  affected_docs: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F03.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
