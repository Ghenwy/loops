# Validation — F03.L02 impact_analysis

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F03.L02`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: dependency graph or import map exists.
- DC-02: affected tests listed.
- DC-03: affected docs listed.
- DC-04: contracts checked.
- DC-05: risk matrix present.
- DC-06: mitigation plan exists.
- DC-07: high-risk owner/action set.
- DC-08: unknown impact not hidden.

## Negative checks

- Reject if `blast_radius` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: blast_radius, dependency_graph, affected_tests, affected_docs, affected_contracts, owner, mitigation, risk_matrix.


## Domain term audit anchors

`blast_radius`, `dependency_graph`, `affected_tests`, `affected_docs`, `affected_contracts`, `owner`, `mitigation`, `risk_matrix`
