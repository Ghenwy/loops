# Examples — F03.L02 Impact Analysis

  ## Happy path

  ```yaml
  task: "Run impact_analysis on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- impact_matrix
- dependency_graph
- affected_tests
- affected_docs
  expected_checks:
    - "dependency graph or import map exists"
    - "affected tests listed"
  ```

  ## Blocked path

  ```yaml
  task: "Run impact_analysis with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run impact_analysis with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
