# Impact Analysis

## ID

F03.L02

## Score

Tier `C` / score `76`.

## Purpose

Map blast radius of a proposed change across modules, contracts, tests, docs, owners and mitigation actions.

## Use when

- change touches shared behavior
- dependencies are unclear
- risk must be scoped

## Avoid when

- isolated change with known local impact

## Domain markers

`blast_radius`, `dependency_graph`, `affected_tests`, `affected_docs`, `affected_contracts`, `owner`

## Required gates

- dependency graph or import map exists
- affected tests listed
- affected docs listed
- contracts checked

## Evidence

- `impact_matrix`
- `dependency_graph`
- `affected_tests`
- `affected_docs`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
