# Postmortem Learning — Loop Definition

    ## Identity

    - Loop ID: `F03.L05`
    - Family: `F03 — Architecture & Documentation`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Convert incidents, bugs or process failures into timeline, cause, prevention, rule/test/memory and verification.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `incident_timeline`, `impact`, `cause`, `preventive_action`, `owner`, `recurrence_test`, `lesson`, `memory_update`

    ## Use when

- something failed and should not repeat
- lesson must become system change

## Avoid when
- no observable event or impact

## OODA execution

### Observe

1. collect incident facts, timeline and impact.
2. identify decisions and context before failure.
3. gather existing tests/rules/memory.

### Orient

1. separate cause from contributing factors.
2. choose preventive action type: test, rule, doc, memory or process.
3. rank actions by recurrence reduction.

### Decide

1. select one prevention to implement first.
2. assign owner or next action.
3. defer unsupported conclusions.

### Act

1. write postmortem and prevention artifact.
2. update test/rule/memory/doc.
3. record unresolved risks.

### Validate

1. verify prevention would detect or reduce recurrence.
2. check postmortem is blameless and evidence-backed.
3. ensure action is not vague.

### Evidence

- `postmortem`
- `timeline`
- `cause_evidence`
- `prevention_artifact`
- `memory_or_test_update`
- `risk_log`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: timeline present.
- CHECK-02: impact described.
- CHECK-03: cause evidence present.
- CHECK-04: prevention action exists.
- CHECK-05: owner/next action set.
- CHECK-06: rule/test/memory update recorded.
- CHECK-07: unresolved risks listed.
- CHECK-08: recurrence verification included.

## Metrics

- `actions_created`
- `recurrence_guard`
- `unresolved_risks`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
