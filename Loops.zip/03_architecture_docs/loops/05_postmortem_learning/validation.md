# Validation — F03.L05 postmortem_learning

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F03.L05`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: timeline present.
- DC-02: impact described.
- DC-03: cause evidence present.
- DC-04: prevention action exists.
- DC-05: owner/next action set.
- DC-06: rule/test/memory update recorded.
- DC-07: unresolved risks listed.
- DC-08: recurrence verification included.

## Negative checks

- Reject if `incident_timeline` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: incident_timeline, impact, cause, preventive_action, owner, recurrence_test, lesson, memory_update.


## Domain term audit anchors

`incident_timeline`, `impact`, `cause`, `preventive_action`, `owner`, `recurrence_test`, `lesson`, `memory_update`
