# Postmortem Learning

## ID

F03.L05

## Score

Tier `C` / score `76`.

## Purpose

Convert incidents, bugs or process failures into timeline, cause, prevention, rule/test/memory and verification.

## Use when

- something failed and should not repeat
- lesson must become system change

## Avoid when

- no observable event or impact

## Domain markers

`incident_timeline`, `impact`, `cause`, `preventive_action`, `owner`, `recurrence_test`

## Required gates

- timeline present
- impact described
- cause evidence present
- prevention action exists

## Evidence

- `postmortem`
- `timeline`
- `cause_evidence`
- `prevention_artifact`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
