# Examples — F03.L05 Postmortem Learning

  ## Happy path

  ```yaml
  task: "Run postmortem_learning on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- postmortem
- timeline
- cause_evidence
- prevention_artifact
  expected_checks:
    - "timeline present"
    - "impact described"
  ```

  ## Blocked path

  ```yaml
  task: "Run postmortem_learning with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run postmortem_learning with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
