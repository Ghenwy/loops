# Evidence — F03.L05 postmortem_learning

    ## Required evidence

- `postmortem`: required for normal closure.
- `timeline`: required for normal closure.
- `cause_evidence`: required for normal closure.
- `prevention_artifact`: required for normal closure.
- `memory_or_test_update`: required for normal closure.
- `risk_log`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F03.L05
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  postmortem: present
  timeline: present
  cause_evidence: present
  prevention_artifact: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F03.L05
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
