# Validation — F03.L04 automatic_onboarding

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F03.L04`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: setup steps present.
- DC-02: project map present.
- DC-03: first task present.
- DC-04: role paths if relevant.
- DC-05: pitfalls listed.
- DC-06: source links exist.
- DC-07: commands verified or unknown.
- DC-08: onboarding completion criteria present.

## Negative checks

- Reject if `setup_path` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: setup_path, role_path, first_task, walkthrough, project_map, common_pitfall, workflow, runbook.


## Domain term audit anchors

`setup_path`, `role_path`, `first_task`, `walkthrough`, `project_map`, `common_pitfall`, `workflow`, `runbook`
