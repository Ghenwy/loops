# Automatic Onboarding

## ID

F03.L04

## Score

Tier `C` / score `76`.

## Purpose

Generate onboarding from actual project state: setup, map, workflows, first task, pitfalls and role-specific paths.

## Use when

- new agent/person enters project
- repo needs handoff
- project map is missing

## Avoid when

- no access to project sources

## Domain markers

`setup_path`, `role_path`, `first_task`, `walkthrough`, `project_map`, `common_pitfall`

## Required gates

- setup steps present
- project map present
- first task present
- role paths if relevant

## Evidence

- `onboarding_doc`
- `setup_validation`
- `project_map`
- `first_task`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
