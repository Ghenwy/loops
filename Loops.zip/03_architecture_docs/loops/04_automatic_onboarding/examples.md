# Examples — F03.L04 Automatic Onboarding

  ## Happy path

  ```yaml
  task: "Run automatic_onboarding on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- onboarding_doc
- setup_validation
- project_map
- first_task
  expected_checks:
    - "setup steps present"
    - "project map present"
  ```

  ## Blocked path

  ```yaml
  task: "Run automatic_onboarding with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run automatic_onboarding with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
