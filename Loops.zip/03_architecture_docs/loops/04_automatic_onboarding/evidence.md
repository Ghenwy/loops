# Evidence — F03.L04 automatic_onboarding

    ## Required evidence

- `onboarding_doc`: required for normal closure.
- `setup_validation`: required for normal closure.
- `project_map`: required for normal closure.
- `first_task`: required for normal closure.
- `pitfall_list`: required for normal closure.
- `source_links`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F03.L04
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  onboarding_doc: present
  setup_validation: present
  project_map: present
  first_task: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F03.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
