# Automatic Onboarding — Loop Definition

    ## Identity

    - Loop ID: `F03.L04`
    - Family: `F03 — Architecture & Documentation`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Generate onboarding from actual project state: setup, map, workflows, first task, pitfalls and role-specific paths.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `setup_path`, `role_path`, `first_task`, `walkthrough`, `project_map`, `common_pitfall`, `workflow`, `runbook`

    ## Use when

- new agent/person enters project
- repo needs handoff
- project map is missing

## Avoid when
- no access to project sources

## OODA execution

### Observe

1. inspect repo structure, setup files and workflows.
2. identify roles and entrypoints.
3. collect common failure points from docs/tests.

### Orient

1. map onboarding sections by role and first task.
2. detect missing setup validation.
3. rank pitfalls by likelihood.

### Decide

1. create minimal onboarding path or block on missing setup.
2. choose first task fixture.
3. select validation commands.

### Act

1. write setup, project map, workflow and first task.
2. add pitfalls and troubleshooting.
3. link source files.

### Validate

1. verify setup path is runnable or marked unknown.
2. check first task is concrete.
3. ensure role paths do not contradict repo.

### Evidence

- `onboarding_doc`
- `setup_validation`
- `project_map`
- `first_task`
- `pitfall_list`
- `source_links`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: setup steps present.
- CHECK-02: project map present.
- CHECK-03: first task present.
- CHECK-04: role paths if relevant.
- CHECK-05: pitfalls listed.
- CHECK-06: source links exist.
- CHECK-07: commands verified or unknown.
- CHECK-08: onboarding completion criteria present.

## Metrics

- `setup_steps`
- `roles_covered`
- `pitfalls_count`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
