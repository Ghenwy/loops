# Examples — F03.L03 Living Documentation

## Happy path

```yaml
task: "Run living_documentation with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - source_of_truth_map
  - doc_drift_report
  - claim_source_links
expected_checks:
  - source of truth identified
  - doc claims mapped to sources
```

## Blocked path

```yaml
task: "Run living_documentation with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run living_documentation with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Documentation claims a CLI command exists but repo has no script; expected failed until corrected or marked unknown."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails source of truth identified."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

