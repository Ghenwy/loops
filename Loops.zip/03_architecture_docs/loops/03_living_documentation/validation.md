# Validation — F03.L03 living_documentation

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F03.L03`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: source of truth identified.
- PV-02: doc claims mapped to sources.
- PV-03: stale claims detected.
- PV-04: examples executed or marked unverified.
- PV-05: setup instructions tested.
- PV-06: new behavior documented.
- PV-07: removed behavior deleted.
- PV-08: unknowns marked.
- PV-09: doc diff reviewed.
- PV-10: owner assigned.
- PV-11: date/version updated.
- PV-12: no unsupported promise remains.

## Domain checks

- DC-01: `source of truth identified` must be represented in contract, examples and evidence.
- DC-02: `doc claims mapped to sources` must be represented in contract, examples and evidence.
- DC-03: `stale claims detected` must be represented in contract, examples and evidence.
- DC-04: `examples executed or marked unverified` must be represented in contract, examples and evidence.
- DC-05: `setup instructions tested` must be represented in contract, examples and evidence.
- DC-06: `new behavior documented` must be represented in contract, examples and evidence.
- DC-07: `removed behavior deleted` must be represented in contract, examples and evidence.
- DC-08: `unknowns marked` must be represented in contract, examples and evidence.
- DC-09: `doc diff reviewed` must be represented in contract, examples and evidence.
- DC-10: `owner assigned` must be represented in contract, examples and evidence.
- DC-11: `date/version updated` must be represented in contract, examples and evidence.
- DC-12: `no unsupported promise remains` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `source_of_truth_map` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Documentation claims a CLI command exists but repo has no script; expected failed until corrected or marked unknown.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`source_of_truth_map`, `doc_drift`, `claim_source`, `stale_marker`, `example_verification`, `docs_delta`, `reader_path`, `doc_owner`, `doc_drift_report`, `claim_source_links`, `updated_doc_patch`, `example_execution_report`, `stale_claim_list`, `updated_doc_diff`, `stale_claims_removed`, `verified_examples`, `unsupported_claims`, `doc_coverage`, `keeping`, `current`

## Domain term coverage

This premium validation explicitly checks: `source_of_truth_map`, `doc_drift`, `claim_source`, `stale_marker`, `example_verification`, `docs_delta`, `reader_path`, `doc_owner`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- LD-01: every factual claim links to source_of_truth_map
- LD-02: doc_drift_scan flags stale sections
- LD-03: stale_doc_marker is applied before rewrite
- LD-04: doc_update_diff matches current repo state
- LD-05: unsupported claims are rejected

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from automatic_onboarding: living docs maintain truth; onboarding packages first-use guidance.
