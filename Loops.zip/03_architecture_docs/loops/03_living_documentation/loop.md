# Living Documentation — Premium Loop

## Identity

- Loop ID: `F03.L03`
- Family: `F03 — Architecture & Documentation`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Keeping docs tied to current source of truth, behavior and setup reality.

## Why this loop matters

Keeps docs from becoming archaeological fiction.

## Premium artifacts

- `source_of_truth_map`
- `doc_drift_report`
- `claim_source_links`
- `updated_doc_patch`
- `example_execution_report`
- `stale_claim_list`

## OODA execution

### Observe

- Capture `source_of_truth_map` and `doc_drift_report`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `source of truth identified` and `doc claims mapped to sources`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `stale_claims_removed` and `verified_examples`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- source of truth identified.
- doc claims mapped to sources.
- stale claims detected.
- examples executed or marked unverified.
- setup instructions tested.
- new behavior documented.
- removed behavior deleted.
- unknowns marked.
- doc diff reviewed.
- owner assigned.
- date/version updated.
- no unsupported promise remains.

## Evidence contract

- `source_of_truth_map`
- `doc_drift_report`
- `claim_source_links`
- `updated_doc_diff`
- `example_execution_report`
- `stale_claim_list`

## Edge case

Documentation claims a CLI command exists but repo has no script; expected failed until corrected or marked unknown.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `source_of_truth_map`
- `doc_drift_scan`
- `claim_source_links`
- `stale_doc_marker`
- `doc_update_diff`

### Quality gates
- LD-01: every factual claim links to source_of_truth_map
- LD-02: doc_drift_scan flags stale sections
- LD-03: stale_doc_marker is applied before rewrite
- LD-04: doc_update_diff matches current repo state
- LD-05: unsupported claims are rejected

### Merge boundary
Keep separate from automatic_onboarding: living docs maintain truth; onboarding packages first-use guidance.
