# Evidence — F03.L03 living_documentation

## Required evidence

- `source_of_truth_map`: required for premium closure.
- `doc_drift_report`: required for premium closure.
- `claim_source_links`: required for premium closure.
- `updated_doc_diff`: required for premium closure.
- `example_execution_report`: required for premium closure.
- `stale_claim_list`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `source_of_truth_map` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `doc_drift_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `claim_source_links` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `updated_doc_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `example_execution_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `stale_claim_list` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-living_documentation-premium
loop_id: F03.L03
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  source_of_truth_map: present
  doc_drift_report: present
  claim_source_links: present
  updated_doc_diff: present
  example_execution_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F03.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `source_of_truth_map`: required for target A maturity.
- `doc_drift_scan`: required for target A maturity.
- `claim_source_links`: required for target A maturity.
- `stale_doc_marker`: required for target A maturity.
- `doc_update_diff`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from automatic_onboarding: living docs maintain truth; onboarding packages first-use guidance.
