# Living Documentation

## ID

F03.L03

## Score

Tier `S` / score `99`.

## Purpose

Keeping docs tied to current source of truth, behavior and setup reality.

## Use when

- docs may be stale
- repo changed
- users rely on instructions

## Avoid when

- pure prose not tied to system behavior

## Domain markers

`source_of_truth_map`, `doc_drift`, `claim_source`, `stale_marker`, `example_verification`, `docs_delta`

## Required gates

- source of truth identified
- doc claims mapped to sources
- stale claims detected
- examples executed or marked unverified

## Evidence

- `source_of_truth_map`
- `doc_drift_report`
- `claim_source_links`
- `updated_doc_diff`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
