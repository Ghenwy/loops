# Architecture & Documentation Index

- F03.L01 `architecture_decision` — C/76
- F03.L02 `impact_analysis` — C/76
- F03.L03 `living_documentation` — S/99
- F03.L04 `automatic_onboarding` — C/76
- F03.L05 `postmortem_learning` — C/76
