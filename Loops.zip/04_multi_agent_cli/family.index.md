# Multi-Agent & Multi-CLI Index

- F04.L01 `model_routing_selection` — A/95
- F04.L02 `multi_cli_orchestration` — S/98
- F04.L03 `multi_agent_fanout_consensus` — C/76
- F04.L04 `cross_audit_maker_checker` — S/98
- F04.L05 `handoff_governance` — C/76
- F04.L06 `intelligent_human_in_loop` — C/76
