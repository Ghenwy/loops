# Evidence — F04.L06 intelligent_human_in_loop

    ## Required evidence

- `risk_matrix`: required for normal closure.
- `human_question`: required for normal closure.
- `resume_state`: required for normal closure.
- `human_answer`: required for normal closure.
- `decision_after_answer`: required for normal closure.
- `fallback_plan`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F04.L06
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  risk_matrix: present
  human_question: present
  resume_state: present
  human_answer: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F04.L06
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
