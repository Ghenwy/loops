# Examples — F04.L06 Intelligent Human In Loop

  ## Happy path

  ```yaml
  task: "Run intelligent_human_in_loop on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- risk_matrix
- human_question
- resume_state
- human_answer
  expected_checks:
    - "risk/reversibility scored"
    - "minimal question used"
  ```

  ## Blocked path

  ```yaml
  task: "Run intelligent_human_in_loop with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run intelligent_human_in_loop with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
