# Intelligent Human In Loop

## ID

F04.L06

## Score

Tier `C` / score `76`.

## Purpose

Ask humans only when risk, ambiguity, reversibility or missing authority makes autonomy unsafe or inefficient.

## Use when

- decision has high impact
- approval or missing fact is required
- human input changes outcome

## Avoid when

- agent is asking to avoid doing available work

## Domain markers

`human_gate`, `risk_reversibility_matrix`, `minimal_question`, `resume_state`, `approval`, `blocker`

## Required gates

- risk/reversibility scored
- minimal question used
- resume_state saved
- ask reason not convenience

## Evidence

- `risk_matrix`
- `human_question`
- `resume_state`
- `human_answer`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
