# Validation — F04.L06 intelligent_human_in_loop

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F04.L06`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: risk/reversibility scored.
- DC-02: minimal question used.
- DC-03: resume_state saved.
- DC-04: ask reason not convenience.
- DC-05: approval captured for high risk.
- DC-06: fallback exists.
- DC-07: answer mapped to decision.
- DC-08: unresolved ambiguity visible.

## Negative checks

- Reject if `human_gate` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: human_gate, risk_reversibility_matrix, minimal_question, resume_state, approval, blocker, authority, ask_policy.


## Domain term audit anchors

`human_gate`, `risk_reversibility_matrix`, `minimal_question`, `resume_state`, `approval`, `blocker`, `authority`, `ask_policy`
