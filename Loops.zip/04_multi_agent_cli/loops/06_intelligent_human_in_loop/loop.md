# Intelligent Human In Loop — Loop Definition

    ## Identity

    - Loop ID: `F04.L06`
    - Family: `F04 — Multi-Agent & Multi-CLI`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Ask humans only when risk, ambiguity, reversibility or missing authority makes autonomy unsafe or inefficient.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `human_gate`, `risk_reversibility_matrix`, `minimal_question`, `resume_state`, `approval`, `blocker`, `authority`, `ask_policy`

    ## Use when

- decision has high impact
- approval or missing fact is required
- human input changes outcome

## Avoid when
- agent is asking to avoid doing available work

## OODA execution

### Observe

1. identify pending decision and autonomy risk.
2. classify reversibility, sensitivity and ambiguity.
3. detect whether data can be obtained without human.

### Orient

1. score ask/no-ask using risk matrix.
2. write minimal question and options.
3. persist resume_state before blocking.

### Decide

1. continue autonomously, ask, require approval or fail.
2. avoid asking for convenience.
3. set fallback if no response.

### Act

1. emit one precise human request or continue.
2. record answer and authority.
3. resume from saved state.

### Validate

1. check question was necessary.
2. verify answer resolves blocker.
3. ensure state resumed without loss.

### Evidence

- `risk_matrix`
- `human_question`
- `resume_state`
- `human_answer`
- `decision_after_answer`
- `fallback_plan`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: risk/reversibility scored.
- CHECK-02: minimal question used.
- CHECK-03: resume_state saved.
- CHECK-04: ask reason not convenience.
- CHECK-05: approval captured for high risk.
- CHECK-06: fallback exists.
- CHECK-07: answer mapped to decision.
- CHECK-08: unresolved ambiguity visible.

## Metrics

- `human_requests`
- `blocked_time`
- `unresolved_ambiguity`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
