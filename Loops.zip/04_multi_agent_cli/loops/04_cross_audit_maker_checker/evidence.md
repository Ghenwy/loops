# Evidence — F04.L04 cross_audit_maker_checker

## Required evidence

- `maker_output`: required for normal closure.
- `checker_audit`: required for normal closure.
- `issue_matrix`: required for normal closure.
- `maker_response`: required for normal closure.
- `rework_diff`: required for normal closure.
- `acceptance_gate_result`: required for normal closure.
- `checker_rubric`: required for normal closure.
- `audit_report`: required for normal closure.
- `issue_response_map`: required for normal closure.
- `disagreement_record`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `maker_output` | cross_audit_maker_checker closure | yes |
| `checker_rubric` | cross_audit_maker_checker closure | yes |
| `audit_report` | cross_audit_maker_checker closure | yes |
| `issue_response_map` | cross_audit_maker_checker closure | yes |
| `disagreement_record` | cross_audit_maker_checker closure | yes |
| `resolution_evidence` | cross_audit_maker_checker closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f04-l04-ok
loop_id: F04.L04
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  maker_output: present
  checker_rubric: present
  audit_report: present
  issue_response_map: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f04-l04-bad
loop_id: F04.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
