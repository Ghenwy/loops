# Examples — F04.L04 cross_audit_maker_checker

## Happy path

```yaml
task: "Run cross_audit_maker_checker on bounded input."
expected_status: completed
expected_output: "validated result with evidence bundle"
expected_evidence: ['maker_output', 'checker_audit', 'issue_matrix', 'maker_response']
```

## Blocked path

```yaml
task: "Run cross_audit_maker_checker with missing critical context or permission."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_output: "blocked with explicit next required input"
expected_evidence: [blocker_reason, next_required_input]
```

## Failed path

```yaml
task: "Run cross_audit_maker_checker with invalid output or failed gate."
expected_status: failed
expected_reason: "validation_failed"
expected_output: "failed with failed_check and validation report"
expected_evidence: [failed_check, validation_report]
```

## Edge case

```yaml
task: "Maker claims issue is minor; checker marks critical and evidence decides."
expected_status: completed
expected_output: "edge case handled without hidden assumption"
expected_evidence: ['maker_output', 'checker_audit', 'issue_matrix', 'maker_response', 'rework_diff']
expected_checks: [edge_case_result, validation_report, evidence_bundle]
```

## Expected checks

- expected_status must match fixture.
- expected_evidence must exist in final bundle.
- expected_output must be backed by validation.
