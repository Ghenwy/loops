# Loop — F04.L04 Cross Audit Maker Checker

## Operating intent

maker-checker audit with independent review, issue severity and evidence-based disagreement resolution.

## OODA runtime

### Observe

- Load task input, current state, prior evidence and fixture expectations.
- Inspect these artifacts: maker_output, checker_rubric, audit_report, issue_response_map.
- Mark missing inputs, stale evidence and unsafe assumptions before acting.

### Orient

- Apply domain gates before choosing an action.
- Required gates: checker is independent, critical issue blocks closure, each issue has response, disagreement resolves by evidence.
- Split notes into `[evidence]`, `[inference]` and `[unknown]`.

### Decide

- Select one atomic action that improves validation, evidence or safety.
- Block if the first critical gate cannot be checked.
- Escalate only when risk or contradiction is explicit.

### Act

- Update the smallest artifact set needed: maker_output, checker_rubric, audit_report.
- Capture command/tool/model inputs and outputs.
- Persist provisional evidence before validation.

### Validate

- Run structural, semantic, domain, negative and fixture checks.
- Execute happy, blocked, failed and edge fixtures.
- Reject completion when evidence is absent or the edge case is unresolved.

## Premium validation gates

- PVG-01: checker is independent.
- PVG-02: critical issue blocks closure.
- PVG-03: each issue has response.
- PVG-04: disagreement resolves by evidence.

## Failure handling

- `blocked`: missing permission, missing source, critical ambiguity or unsafe policy.
- `failed`: validation failure, negative case accepted, evidence missing or rollback failure.
- `completed`: all premium gates pass and the final evidence bundle is complete.

## Edge case

Maker claims issue is minor; checker marks critical and evidence decides.

## Final output

Return status, iterations, validation result, evidence IDs, unresolved risks and next action.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.
