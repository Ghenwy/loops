# Validation — F04.L04 cross_audit_maker_checker

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F04.L04`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: checker is independent.
- DC-02: critical issue blocks closure.
- DC-03: each issue has response.
- DC-04: disagreement resolves by evidence.
- DC-05: artifact `maker_output` is present.
- DC-06: artifact `checker_rubric` is present.
- DC-07: artifact `audit_report` is present.
- DC-08: artifact `issue_response_map` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: issues_found, critical_count, rework_rounds, acceptance_pass.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Maker claims issue is minor; checker marks critical and evidence decides.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.

## Domain term audit anchors

`maker_contract`, `checker_contract`, `independent_review`, `audit_report`, `severity`, `rework_loop`, `disagreement`, `acceptance_gate`, `maker_output`, `checker_rubric`, `issue_response_map`, `disagreement_record`, `resolution_evidence`

## Domain term coverage

This premium validation explicitly checks: `maker_contract`, `checker_contract`, `independent_review`, `audit_report`, `severity`, `rework_loop`, `disagreement`, `acceptance_gate`.
