# Cross Audit Maker Checker

## ID

F04.L04

## Score

Tier `S` / score `98`.

## Purpose

maker-checker audit with independent review, issue severity and evidence-based disagreement resolution.

## Use when

- output needs independent audit
- high confidence is required
- self-review is insufficient

## Avoid when

- trivial output with no risk

## Domain markers

`maker_contract`, `checker_contract`, `independent_review`, `audit_report`, `severity`, `rework_loop`

## Required gates

- maker contract exists
- checker contract exists
- reviewer independent
- severity rubric applied

## Evidence

- `maker_output`
- `checker_audit`
- `issue_matrix`
- `maker_response`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
