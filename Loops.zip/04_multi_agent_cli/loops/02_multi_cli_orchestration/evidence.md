# Evidence — F04.L02 multi_cli_orchestration

## Required evidence

- `cli_role_matrix`: required for premium closure.
- `handoff_packet`: required for premium closure.
- `execution_trace`: required for premium closure.
- `cross_validation_report`: required for premium closure.
- `conflict_resolution_log`: required for premium closure.
- `fallback_plan`: required for premium closure.
- `merged_evidence_bundle`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `cli_role_matrix` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `handoff_packet` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `execution_trace` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `cross_validation_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `conflict_resolution_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `fallback_plan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `merged_evidence_bundle` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-multi_cli_orchestration-premium
loop_id: F04.L02
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  cli_role_matrix: present
  handoff_packet: present
  execution_trace: present
  cross_validation_report: present
  conflict_resolution_log: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F04.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.
