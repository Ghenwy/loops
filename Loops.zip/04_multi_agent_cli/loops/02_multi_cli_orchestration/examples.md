# Examples — F04.L02 Multi CLI Orchestration

## Happy path

```yaml
task: "Run multi_cli_orchestration with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - cli_role_matrix
  - handoff_packet
  - execution_trace
expected_checks:
  - CLI roles assigned
  - planner/executor/reviewer separated when risk high
```

## Blocked path

```yaml
task: "Run multi_cli_orchestration with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run multi_cli_orchestration with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Two CLIs disagree on patch safety; expected evidence-weighted resolution or blocked status."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

