# Multi Cli Orchestration

## ID

F04.L02

## Score

Tier `S` / score `98`.

## Purpose

Assigning codex, claude, copilot, gemini or local clis by role, context and validation boundary.

## Use when

- Codex/Claude/Copilot/Gemini or other CLIs must cooperate
- independent validation is needed

## Avoid when

- single CLI can safely complete task

## Domain markers

`cli_role_matrix`, `executor_cli`, `reviewer_cli`, `handoff_packet`, `cross_validation`, `conflict_resolution`

## Required gates

- CLI roles assigned
- planner/executor/reviewer separated when risk high
- handoff packet minimal
- context loss checked

## Evidence

- `cli_role_matrix`
- `handoff_packet`
- `execution_trace`
- `cross_validation_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
