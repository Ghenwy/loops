# Multi CLI Orchestration — Premium Loop

## Identity

- Loop ID: `F04.L02`
- Family: `F04 — Multi-Agent & Multi-CLI`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Assigning codex, claude, copilot, gemini or local clis by role, context and validation boundary.

## Why this loop matters

Turns many clis from a circus into a workflow.

## Premium artifacts

- `cli_role_matrix`
- `handoff_packet`
- `execution_trace`
- `cross_validation_report`
- `conflict_resolution_log`
- `fallback_plan`

## OODA execution

### Observe

- Capture `cli_role_matrix` and `handoff_packet`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `CLI roles assigned` and `planner/executor/reviewer separated when risk high`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `cli_calls` and `conflicts_resolved`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- CLI roles assigned.
- planner/executor/reviewer separated when risk high.
- handoff packet minimal.
- context loss checked.
- execution trace captured.
- validation CLI independent when needed.
- conflict policy applied.
- fallback selected.
- cost/latency noted.
- outputs consolidated.
- evidence bundle merged.
- human gate for destructive action.

## Evidence contract

- `cli_role_matrix`
- `handoff_packet`
- `execution_trace`
- `cross_validation_report`
- `conflict_resolution_log`
- `fallback_plan`
- `merged_evidence_bundle`

## Edge case

Two CLIs disagree on patch safety; expected evidence-weighted resolution or blocked status.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target S

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `S` with score >= 96.

### Required artifacts
- `cli_role_matrix`
- `context_handoff_packet`
- `cross_cli_validation_gate`
- `fallback_policy`
- `conflict_resolution_matrix`
- `evidence_fanin_report`

### Quality gates
- MC-01: each CLI has one primary role
- MC-02: context_handoff_packet is minimal and sufficient
- MC-03: high-risk execution requires cross_cli_validation_gate
- MC-04: fallback_policy triggers on unavailable CLI
- MC-05: conflict_resolution_matrix resolves disagreements by evidence
- MC-06: evidence_fanin_report consolidates outputs

### Merge boundary
Keep separate from multi_agent_fanout_consensus: multi_cli_orchestration coordinates concrete CLIs; fanout_consensus coordinates agent reasoning roles.
