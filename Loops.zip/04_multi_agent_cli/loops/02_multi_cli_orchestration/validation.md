# Validation — F04.L02 multi_cli_orchestration

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F04.L02`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: CLI roles assigned.
- PV-02: planner/executor/reviewer separated when risk high.
- PV-03: handoff packet minimal.
- PV-04: context loss checked.
- PV-05: execution trace captured.
- PV-06: validation CLI independent when needed.
- PV-07: conflict policy applied.
- PV-08: fallback selected.
- PV-09: cost/latency noted.
- PV-10: outputs consolidated.
- PV-11: evidence bundle merged.
- PV-12: human gate for destructive action.

## Domain checks

- DC-01: `CLI roles assigned` must be represented in contract, examples and evidence.
- DC-02: `planner/executor/reviewer separated when risk high` must be represented in contract, examples and evidence.
- DC-03: `handoff packet minimal` must be represented in contract, examples and evidence.
- DC-04: `context loss checked` must be represented in contract, examples and evidence.
- DC-05: `execution trace captured` must be represented in contract, examples and evidence.
- DC-06: `validation CLI independent when needed` must be represented in contract, examples and evidence.
- DC-07: `conflict policy applied` must be represented in contract, examples and evidence.
- DC-08: `fallback selected` must be represented in contract, examples and evidence.
- DC-09: `cost/latency noted` must be represented in contract, examples and evidence.
- DC-10: `outputs consolidated` must be represented in contract, examples and evidence.
- DC-11: `evidence bundle merged` must be represented in contract, examples and evidence.
- DC-12: `human gate for destructive action` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `cli_role_matrix` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Two CLIs disagree on patch safety; expected evidence-weighted resolution or blocked status.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`cli_role_matrix`, `executor_cli`, `reviewer_cli`, `handoff_packet`, `cross_validation`, `conflict_resolution`, `fallback_cli`, `consolidated_evidence`, `execution_trace`, `cross_validation_report`, `conflict_resolution_log`, `fallback_plan`, `merged_evidence_bundle`, `cli_calls`, `conflicts_resolved`, `validation_pass_rate`, `handoff_loss_count`, `assigning`, `copilot`, `context`

## Domain term coverage

This premium validation explicitly checks: `cli_role_matrix`, `executor_cli`, `reviewer_cli`, `handoff_packet`, `cross_validation`, `conflict_resolution`, `fallback_cli`, `consolidated_evidence`.
