# Validation — F04.L05 handoff_governance

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F04.L05`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: delegation reason present.
- DC-02: minimal context present.
- DC-03: expected output defined.
- DC-04: owner set.
- DC-05: timeout set.
- DC-06: return validation present.
- DC-07: ping-pong detected.
- DC-08: handoff evidence retained.

## Negative checks

- Reject if `handoff_contract` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: handoff_contract, minimal_context, expected_output, owner, timeout, return_validation, ping_pong, delegation_reason.


## Domain term audit anchors

`handoff_contract`, `minimal_context`, `expected_output`, `owner`, `timeout`, `return_validation`, `ping_pong`, `delegation_reason`
