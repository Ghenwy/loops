# Examples — F04.L05 Handoff Governance

  ## Happy path

  ```yaml
  task: "Run handoff_governance on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- handoff_contract
- delegation_reason
- request_packet
- response_packet
  expected_checks:
    - "delegation reason present"
    - "minimal context present"
  ```

  ## Blocked path

  ```yaml
  task: "Run handoff_governance with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run handoff_governance with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
