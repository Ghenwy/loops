# Handoff Governance — Loop Definition

    ## Identity

    - Loop ID: `F04.L05`
    - Family: `F04 — Multi-Agent & Multi-CLI`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Govern agent handoffs with minimal context, expected output, ownership, timeout, return validation and ping-pong prevention.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `handoff_contract`, `minimal_context`, `expected_output`, `owner`, `timeout`, `return_validation`, `ping_pong`, `delegation_reason`

    ## Use when

- one agent must delegate
- specialist context is needed
- handoff must be auditable

## Avoid when
- delegation adds no value

## OODA execution

### Observe

1. detect delegation need and missing capability.
2. identify receiving agent/tool capability.
3. collect minimal context required.

### Orient

1. write handoff_contract with expected output and timeout.
2. classify delegation risk.
3. detect ping-pong risk.

### Decide

1. delegate, keep local, or escalate.
2. choose owner and return validation.
3. block if output expectation unclear.

### Act

1. send handoff packet.
2. receive response and metadata.
3. merge accepted result into parent state.

### Validate

1. check response matches expected output.
2. verify no context loss.
3. reject ping-pong or vague return.

### Evidence

- `handoff_contract`
- `delegation_reason`
- `request_packet`
- `response_packet`
- `return_validation`
- `ownership_log`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: delegation reason present.
- CHECK-02: minimal context present.
- CHECK-03: expected output defined.
- CHECK-04: owner set.
- CHECK-05: timeout set.
- CHECK-06: return validation present.
- CHECK-07: ping-pong detected.
- CHECK-08: handoff evidence retained.

## Metrics

- `handoff_count`
- `timeouts`
- `invalid_returns`
- `ping_pong_count`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
