# Evidence — F04.L05 handoff_governance

    ## Required evidence

- `handoff_contract`: required for normal closure.
- `delegation_reason`: required for normal closure.
- `request_packet`: required for normal closure.
- `response_packet`: required for normal closure.
- `return_validation`: required for normal closure.
- `ownership_log`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F04.L05
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  handoff_contract: present
  delegation_reason: present
  request_packet: present
  response_packet: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F04.L05
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
