# Handoff Governance

## ID

F04.L05

## Score

Tier `C` / score `76`.

## Purpose

Govern agent handoffs with minimal context, expected output, ownership, timeout, return validation and ping-pong prevention.

## Use when

- one agent must delegate
- specialist context is needed
- handoff must be auditable

## Avoid when

- delegation adds no value

## Domain markers

`handoff_contract`, `minimal_context`, `expected_output`, `owner`, `timeout`, `return_validation`

## Required gates

- delegation reason present
- minimal context present
- expected output defined
- owner set

## Evidence

- `handoff_contract`
- `delegation_reason`
- `request_packet`
- `response_packet`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
