# Validation — F04.L03 multi_agent_fanout_consensus

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F04.L03`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: agent roles non-overlapping.
- DC-02: output contract exists.
- DC-03: disagreement matrix present.
- DC-04: evidence weighting used.
- DC-05: judge policy exists.
- DC-06: minority risks captured.
- DC-07: final decision traced.
- DC-08: no majority-only unsupported decision.

## Negative checks

- Reject if `fanout` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: fanout, fanin, agent_role, output_contract, disagreement_matrix, evidence_weight, judge, consensus_decision.


## Domain term audit anchors

`fanout`, `fanin`, `agent_role`, `output_contract`, `disagreement_matrix`, `evidence_weight`, `judge`, `consensus_decision`
