# Evidence — F04.L03 multi_agent_fanout_consensus

    ## Required evidence

- `agent_outputs`: required for normal closure.
- `disagreement_matrix`: required for normal closure.
- `evidence_scores`: required for normal closure.
- `judge_decision`: required for normal closure.
- `consensus_report`: required for normal closure.
- `minority_risks`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F04.L03
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  agent_outputs: present
  disagreement_matrix: present
  evidence_scores: present
  judge_decision: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F04.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
