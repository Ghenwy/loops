# Examples — F04.L03 Multi Agent Fanout Consensus

  ## Happy path

  ```yaml
  task: "Run multi_agent_fanout_consensus on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- agent_outputs
- disagreement_matrix
- evidence_scores
- judge_decision
  expected_checks:
    - "agent roles non-overlapping"
    - "output contract exists"
  ```

  ## Blocked path

  ```yaml
  task: "Run multi_agent_fanout_consensus with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run multi_agent_fanout_consensus with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
