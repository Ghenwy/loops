# Multi Agent Fanout Consensus

## ID

F04.L03

## Score

Tier `C` / score `76`.

## Purpose

Run specialist agents in fan-out, merge outputs in fan-in, resolve contradictions and decide by evidence weighting.

## Use when

- problem spans domains
- parallel review helps
- contradictions likely

## Avoid when

- single clear task with one source of truth

## Domain markers

`fanout`, `fanin`, `agent_role`, `output_contract`, `disagreement_matrix`, `evidence_weight`

## Required gates

- agent roles non-overlapping
- output contract exists
- disagreement matrix present
- evidence weighting used

## Evidence

- `agent_outputs`
- `disagreement_matrix`
- `evidence_scores`
- `judge_decision`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
