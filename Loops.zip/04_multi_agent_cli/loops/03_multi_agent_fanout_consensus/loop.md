# Multi Agent Fanout Consensus — Loop Definition

    ## Identity

    - Loop ID: `F04.L03`
    - Family: `F04 — Multi-Agent & Multi-CLI`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Run specialist agents in fan-out, merge outputs in fan-in, resolve contradictions and decide by evidence weighting.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `fanout`, `fanin`, `agent_role`, `output_contract`, `disagreement_matrix`, `evidence_weight`, `judge`, `consensus_decision`

    ## Use when

- problem spans domains
- parallel review helps
- contradictions likely

## Avoid when
- single clear task with one source of truth

## OODA execution

### Observe

1. decompose task into specialist roles.
2. define output_contract per agent.
3. collect independent outputs.

### Orient

1. compare agreements, gaps and contradictions.
2. score evidence strength per output.
3. identify missing perspective.

### Decide

1. accept consensus, ask targeted rerun or appoint judge.
2. choose final decision by evidence not vote only.
3. record minority risks.

### Act

1. run fan-out agents or simulate roles.
2. create disagreement_matrix.
3. write consensus_decision.

### Validate

1. check every claim has evidence.
2. verify contradictions resolved or retained as risk.
3. reject consensus without contract.

### Evidence

- `agent_outputs`
- `disagreement_matrix`
- `evidence_scores`
- `judge_decision`
- `consensus_report`
- `minority_risks`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: agent roles non-overlapping.
- CHECK-02: output contract exists.
- CHECK-03: disagreement matrix present.
- CHECK-04: evidence weighting used.
- CHECK-05: judge policy exists.
- CHECK-06: minority risks captured.
- CHECK-07: final decision traced.
- CHECK-08: no majority-only unsupported decision.

## Metrics

- `agents_used`
- `contradictions`
- `resolved_conflicts`
- `evidence_score`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
