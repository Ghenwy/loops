# Examples — F04.L01 Model Routing Selection

## Happy path

```yaml
task: "Run model_routing_selection with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - task_classification
  - model_capability_matrix
  - privacy_score
expected_checks:
  - task classified
  - privacy sensitivity scored
```

## Blocked path

```yaml
task: "Run model_routing_selection with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run model_routing_selection with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Sensitive local-only task routes to cloud model; expected failed unless explicit approval exists."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

