# Model Routing Selection — Premium Loop

## Identity

- Loop ID: `F04.L01`
- Family: `F04 — Multi-Agent & Multi-CLI`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Choosing local/cloud/cheap/strong models by task, privacy, risk, latency and cost.

## Why this loop matters

Keeps flagship models for work that actually deserves flagship models.

## Premium artifacts

- `task_classification`
- `model_capability_matrix`
- `privacy_score`
- `cost_latency_estimate`
- `routing_decision`
- `fallback_policy`

## OODA execution

### Observe

- Capture `task_classification` and `model_capability_matrix`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `task classified` and `privacy sensitivity scored`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `routing_accuracy` and `cost_estimate`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- task classified.
- privacy sensitivity scored.
- risk scored.
- latency budget known.
- cost budget known.
- model capabilities matched.
- local option considered.
- cloud use justified.
- fallback defined.
- routing decision logged.
- result quality checked.
- misroute recorded.

## Evidence contract

- `task_classification`
- `model_capability_matrix`
- `privacy_score`
- `cost_latency_estimate`
- `routing_decision`
- `fallback_policy`
- `quality_check`

## Edge case

Sensitive local-only task routes to cloud model; expected failed unless explicit approval exists.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target B

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `B` with score >= 84.

### Required artifacts
- `model_task_matrix`
- `privacy_risk_score`
- `cost_latency_score`
- `local_cloud_decision`
- `fallback_route`

### Quality gates
- MR-01: model_task_matrix maps task to capability
- MR-02: privacy_risk_score blocks cloud when sensitive
- MR-03: cost_latency_score prevents overkill model use
- MR-04: local_cloud_decision is explicit
- MR-05: fallback_route is defined

### Merge boundary
Keep separate from local_embeddings_bare_metal: router chooses backend; embeddings loop builds local retrieval capability.
