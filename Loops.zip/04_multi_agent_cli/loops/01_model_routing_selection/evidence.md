# Evidence — F04.L01 model_routing_selection

## Required evidence

- `task_classification`: required for premium closure.
- `model_capability_matrix`: required for premium closure.
- `privacy_score`: required for premium closure.
- `cost_latency_estimate`: required for premium closure.
- `routing_decision`: required for premium closure.
- `fallback_policy`: required for premium closure.
- `quality_check`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `task_classification` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `model_capability_matrix` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `privacy_score` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `cost_latency_estimate` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `routing_decision` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `fallback_policy` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `quality_check` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-model_routing_selection-premium
loop_id: F04.L01
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  task_classification: present
  model_capability_matrix: present
  privacy_score: present
  cost_latency_estimate: present
  routing_decision: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F04.L01
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Baseline upgrade evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `model_task_matrix`: required for target B maturity.
- `privacy_risk_score`: required for target B maturity.
- `cost_latency_score`: required for target B maturity.
- `local_cloud_decision`: required for target B maturity.
- `fallback_route`: required for target B maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from local_embeddings_bare_metal: router chooses backend; embeddings loop builds local retrieval capability.
