# Model Routing Selection

## ID

F04.L01

## Score

Tier `A` / score `95`.

## Purpose

Choosing local/cloud/cheap/strong models by task, privacy, risk, latency and cost.

## Use when

- multiple models/backends exist
- privacy or cost matters
- routing should be explicit

## Avoid when

- only one backend available

## Domain markers

`routing_matrix`, `privacy_class`, `risk_score`, `latency_budget`, `cost_budget`, `capability_match`

## Required gates

- task classified
- privacy sensitivity scored
- risk scored
- latency budget known

## Evidence

- `task_classification`
- `model_capability_matrix`
- `privacy_score`
- `cost_latency_estimate`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
