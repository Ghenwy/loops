# Validation — F04.L01 model_routing_selection

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F04.L01`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: task classified.
- PV-02: privacy sensitivity scored.
- PV-03: risk scored.
- PV-04: latency budget known.
- PV-05: cost budget known.
- PV-06: model capabilities matched.
- PV-07: local option considered.
- PV-08: cloud use justified.
- PV-09: fallback defined.
- PV-10: routing decision logged.
- PV-11: result quality checked.
- PV-12: misroute recorded.

## Domain checks

- DC-01: `task classified` must be represented in contract, examples and evidence.
- DC-02: `privacy sensitivity scored` must be represented in contract, examples and evidence.
- DC-03: `risk scored` must be represented in contract, examples and evidence.
- DC-04: `latency budget known` must be represented in contract, examples and evidence.
- DC-05: `cost budget known` must be represented in contract, examples and evidence.
- DC-06: `model capabilities matched` must be represented in contract, examples and evidence.
- DC-07: `local option considered` must be represented in contract, examples and evidence.
- DC-08: `cloud use justified` must be represented in contract, examples and evidence.
- DC-09: `fallback defined` must be represented in contract, examples and evidence.
- DC-10: `routing decision logged` must be represented in contract, examples and evidence.
- DC-11: `result quality checked` must be represented in contract, examples and evidence.
- DC-12: `misroute recorded` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `task_classification` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Sensitive local-only task routes to cloud model; expected failed unless explicit approval exists.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`routing_matrix`, `privacy_class`, `risk_score`, `latency_budget`, `cost_budget`, `capability_match`, `fallback_model`, `local_cloud_policy`, `task_classification`, `model_capability_matrix`, `privacy_score`, `cost_latency_estimate`, `routing_decision`, `fallback_policy`, `quality_check`, `routing_accuracy`, `cost_estimate`, `latency_budget_hit`, `fallback_count`, `choosing`

## Domain term coverage

This premium validation explicitly checks: `routing_matrix`, `privacy_class`, `risk_score`, `latency_budget`, `cost_budget`, `capability_match`, `fallback_model`, `local_cloud_policy`.

## Baseline upgrade gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- MR-01: model_task_matrix maps task to capability
- MR-02: privacy_risk_score blocks cloud when sensitive
- MR-03: cost_latency_score prevents overkill model use
- MR-04: local_cloud_decision is explicit
- MR-05: fallback_route is defined

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from local_embeddings_bare_metal: router chooses backend; embeddings loop builds local retrieval capability.
