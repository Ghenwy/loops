# Multi-Agent & Multi-CLI

## Purpose

Multi-Agent & Multi-CLI contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F04.L01 | `model_routing_selection` | A | 95 |
| F04.L02 | `multi_cli_orchestration` | S | 98 |
| F04.L03 | `multi_agent_fanout_consensus` | C | 76 |
| F04.L04 | `cross_audit_maker_checker` | S | 98 |
| F04.L05 | `handoff_governance` | C | 76 |
| F04.L06 | `intelligent_human_in_loop` | C | 76 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
