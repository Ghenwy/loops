# Datasets & DeepResearch

## Purpose

Datasets & DeepResearch contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F07.L01 | `dataset_curation` | C | 76 |
| F07.L02 | `synthetic_task_generation` | C | 76 |
| F07.L03 | `deepresearch_dataset_builder` | S | 97 |
| F07.L04 | `dataset_validation_triangulation` | C | 76 |
| F07.L05 | `benchmark_loop` | A | 95 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
