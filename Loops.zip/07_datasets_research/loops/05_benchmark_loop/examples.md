# Examples — F07.L05 Benchmark Loop

## Happy path

```yaml
task: "Run benchmark_loop with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - benchmark_manifest
  - dataset_version
  - metric_definition
expected_checks:
  - benchmark goal stated
  - dataset version pinned
```

## Blocked path

```yaml
task: "Run benchmark_loop with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run benchmark_loop with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Candidate wins on quality but doubles cost beyond budget; expected trade-off decision rather than automatic win."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

