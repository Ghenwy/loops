# Benchmark Loop — Premium Loop

## Identity

- Loop ID: `F07.L05`
- Family: `F07 — Datasets & DeepResearch`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Comparing agents, models, prompts or clis against versioned datasets and explicit metrics.

## Why this loop matters

Replaces “seems better” with a scoreboard.

## Premium artifacts

- `benchmark_manifest`
- `dataset_version`
- `metric_definition`
- `baseline_result`
- `candidate_result`
- `failure_analysis`
- `ranking_report`

## OODA execution

### Observe

- Capture `benchmark_manifest` and `dataset_version`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `benchmark goal stated` and `dataset version pinned`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `quality_score` and `cost_per_task`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- benchmark goal stated.
- dataset version pinned.
- metrics defined.
- baseline recorded.
- candidate run recorded.
- thresholds known.
- cost measured.
- latency measured.
- failures categorized.
- ranking reproducible.
- randomness controlled.
- report exported.

## Evidence contract

- `benchmark_manifest`
- `dataset_version`
- `metric_definition`
- `baseline_result`
- `candidate_result`
- `failure_analysis`
- `ranking_report`
- `run_config`

## Edge case

Candidate wins on quality but doubles cost beyond budget; expected trade-off decision rather than automatic win.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target B

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `B` with score >= 84.

### Required artifacts
- `benchmark_dataset_version`
- `metric_definition`
- `baseline_result`
- `threshold_policy`
- `failure_analysis`

### Quality gates
- BM-01: benchmark_dataset_version is pinned
- BM-02: metric_definition is explicit
- BM-03: baseline_result exists
- BM-04: threshold_policy decides pass/fail
- BM-05: failure_analysis is produced for regressions

### Merge boundary
Keep separate from dataset_curation: curation builds cases; benchmark loop runs repeatable comparisons.
