# Benchmark Loop

## ID

F07.L05

## Score

Tier `A` / score `95`.

## Purpose

Comparing agents, models, prompts or clis against versioned datasets and explicit metrics.

## Use when

- comparison must be repeatable
- quality/cost/latency trade-off matters

## Avoid when

- no dataset or metric exists

## Domain markers

`dataset_version`, `metric_definition`, `threshold_policy`, `baseline_result`, `ranking_table`, `failure_analysis`

## Required gates

- benchmark goal stated
- dataset version pinned
- metrics defined
- baseline recorded

## Evidence

- `benchmark_manifest`
- `dataset_version`
- `metric_definition`
- `baseline_result`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
