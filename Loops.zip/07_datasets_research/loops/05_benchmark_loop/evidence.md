# Evidence — F07.L05 benchmark_loop

## Required evidence

- `benchmark_manifest`: required for premium closure.
- `dataset_version`: required for premium closure.
- `metric_definition`: required for premium closure.
- `baseline_result`: required for premium closure.
- `candidate_result`: required for premium closure.
- `failure_analysis`: required for premium closure.
- `ranking_report`: required for premium closure.
- `run_config`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `benchmark_manifest` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `dataset_version` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `metric_definition` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `baseline_result` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `candidate_result` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `failure_analysis` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `ranking_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-benchmark_loop-premium
loop_id: F07.L05
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  benchmark_manifest: present
  dataset_version: present
  metric_definition: present
  baseline_result: present
  candidate_result: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F07.L05
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Baseline upgrade evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `benchmark_dataset_version`: required for target B maturity.
- `metric_definition`: required for target B maturity.
- `baseline_result`: required for target B maturity.
- `threshold_policy`: required for target B maturity.
- `failure_analysis`: required for target B maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from dataset_curation: curation builds cases; benchmark loop runs repeatable comparisons.
