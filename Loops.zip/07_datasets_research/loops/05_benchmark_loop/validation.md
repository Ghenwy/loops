# Validation — F07.L05 benchmark_loop

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F07.L05`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: benchmark goal stated.
- PV-02: dataset version pinned.
- PV-03: metrics defined.
- PV-04: baseline recorded.
- PV-05: candidate run recorded.
- PV-06: thresholds known.
- PV-07: cost measured.
- PV-08: latency measured.
- PV-09: failures categorized.
- PV-10: ranking reproducible.
- PV-11: randomness controlled.
- PV-12: report exported.

## Domain checks

- DC-01: `benchmark goal stated` must be represented in contract, examples and evidence.
- DC-02: `dataset version pinned` must be represented in contract, examples and evidence.
- DC-03: `metrics defined` must be represented in contract, examples and evidence.
- DC-04: `baseline recorded` must be represented in contract, examples and evidence.
- DC-05: `candidate run recorded` must be represented in contract, examples and evidence.
- DC-06: `thresholds known` must be represented in contract, examples and evidence.
- DC-07: `cost measured` must be represented in contract, examples and evidence.
- DC-08: `latency measured` must be represented in contract, examples and evidence.
- DC-09: `failures categorized` must be represented in contract, examples and evidence.
- DC-10: `ranking reproducible` must be represented in contract, examples and evidence.
- DC-11: `randomness controlled` must be represented in contract, examples and evidence.
- DC-12: `report exported` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `benchmark_manifest` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Candidate wins on quality but doubles cost beyond budget; expected trade-off decision rather than automatic win.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`dataset_version`, `metric_definition`, `threshold_policy`, `baseline_result`, `ranking_table`, `failure_analysis`, `cost_latency`, `regression_suite`, `benchmark_manifest`, `candidate_result`, `ranking_report`, `run_config`, `quality_score`, `cost_per_task`, `latency_ms`, `failure_rate`, `comparing`, `prompts`, `against`, `versioned`

## Domain term coverage

This premium validation explicitly checks: `dataset_version`, `metric_definition`, `threshold_policy`, `baseline_result`, `ranking_table`, `failure_analysis`, `cost_latency`, `regression_suite`.

## Baseline upgrade gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- BM-01: benchmark_dataset_version is pinned
- BM-02: metric_definition is explicit
- BM-03: baseline_result exists
- BM-04: threshold_policy decides pass/fail
- BM-05: failure_analysis is produced for regressions

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from dataset_curation: curation builds cases; benchmark loop runs repeatable comparisons.
