# Validation — F07.L04 dataset_validation_triangulation

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F07.L04`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: accepted/rejected split exists.
- DC-02: near-duplicates detected.
- DC-03: source weighting applied.
- DC-04: confidence score set.
- DC-05: contradictions marked.
- DC-06: missing source rejected.
- DC-07: validation report written.
- DC-08: triangulation rule applied.

## Negative checks

- Reject if `source_weight` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: source_weight, contradiction, near_duplicate, confidence_score, accepted_split, rejected_split, validation_report, triangulation.


## Domain term audit anchors

`source_weight`, `contradiction`, `near_duplicate`, `confidence_score`, `accepted_split`, `rejected_split`, `validation_report`, `triangulation`
