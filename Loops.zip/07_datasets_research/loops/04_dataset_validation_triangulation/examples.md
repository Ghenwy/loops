# Examples — F07.L04 Dataset Validation Triangulation

  ## Happy path

  ```yaml
  task: "Run dataset_validation_triangulation on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- raw_dataset_hash
- accepted_dataset
- rejected_dataset
- duplicate_report
  expected_checks:
    - "accepted/rejected split exists"
    - "near-duplicates detected"
  ```

  ## Blocked path

  ```yaml
  task: "Run dataset_validation_triangulation with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run dataset_validation_triangulation with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
