# Dataset Validation Triangulation — Loop Definition

    ## Identity

    - Loop ID: `F07.L04`
    - Family: `F07 — Datasets & DeepResearch`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Validate datasets through dedupe, source weighting, contradiction marking, confidence scoring and accepted/rejected split.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `source_weight`, `contradiction`, `near_duplicate`, `confidence_score`, `accepted_split`, `rejected_split`, `validation_report`, `triangulation`

    ## Use when

- dataset is raw or web-derived
- quality must be proven before benchmark

## Avoid when
- dataset already validated by stronger process

## OODA execution

### Observe

1. load raw dataset and metadata.
2. group rows by claim/source/topic.
3. detect duplicates and missing fields.

### Orient

1. weight sources and compare claims.
2. mark contradictions or weak support.
3. compute confidence_score.

### Decide

1. accept, reject, merge or flag row.
2. require triangulation for high-impact claim.
3. set review queue for contradictions.

### Act

1. write accepted/rejected outputs.
2. generate validation_report.
3. update confidence fields.

### Validate

1. duplicate rows rejected/merged.
2. low-quality source downgraded.
3. contradictions visible not hidden.

### Evidence

- `raw_dataset_hash`
- `accepted_dataset`
- `rejected_dataset`
- `duplicate_report`
- `contradiction_report`
- `confidence_scores`
- `validation_report`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: accepted/rejected split exists.
- CHECK-02: near-duplicates detected.
- CHECK-03: source weighting applied.
- CHECK-04: confidence score set.
- CHECK-05: contradictions marked.
- CHECK-06: missing source rejected.
- CHECK-07: validation report written.
- CHECK-08: triangulation rule applied.

## Metrics

- `accepted_rows`
- `rejected_rows`
- `duplicate_count`
- `contradictions`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
