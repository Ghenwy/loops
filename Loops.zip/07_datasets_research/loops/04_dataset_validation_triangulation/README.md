# Dataset Validation Triangulation

## ID

F07.L04

## Score

Tier `C` / score `76`.

## Purpose

Validate datasets through dedupe, source weighting, contradiction marking, confidence scoring and accepted/rejected split.

## Use when

- dataset is raw or web-derived
- quality must be proven before benchmark

## Avoid when

- dataset already validated by stronger process

## Domain markers

`source_weight`, `contradiction`, `near_duplicate`, `confidence_score`, `accepted_split`, `rejected_split`

## Required gates

- accepted/rejected split exists
- near-duplicates detected
- source weighting applied
- confidence score set

## Evidence

- `raw_dataset_hash`
- `accepted_dataset`
- `rejected_dataset`
- `duplicate_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
