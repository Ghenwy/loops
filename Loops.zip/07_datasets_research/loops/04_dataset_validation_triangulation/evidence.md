# Evidence — F07.L04 dataset_validation_triangulation

    ## Required evidence

- `raw_dataset_hash`: required for normal closure.
- `accepted_dataset`: required for normal closure.
- `rejected_dataset`: required for normal closure.
- `duplicate_report`: required for normal closure.
- `contradiction_report`: required for normal closure.
- `confidence_scores`: required for normal closure.
- `validation_report`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F07.L04
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  raw_dataset_hash: present
  accepted_dataset: present
  rejected_dataset: present
  duplicate_report: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F07.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
