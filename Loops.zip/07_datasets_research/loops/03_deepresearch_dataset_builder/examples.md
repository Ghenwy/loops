# Examples — F07.L03 DeepResearch Dataset Builder

## Happy path

```yaml
task: "Run deepresearch_dataset_builder with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - research_query_plan
  - source_quality_scores
  - extraction_log
expected_checks:
  - query plan explicit
  - source allow/deny policy set
```

## Blocked path

```yaml
task: "Run deepresearch_dataset_builder with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run deepresearch_dataset_builder with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "High-ranking SEO article conflicts with official source; expected downgraded or rejected unless triangulated."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

