# Deepresearch Dataset Builder

## ID

F07.L03

## Score

Tier `S` / score `97`.

## Purpose

Building datasets from web research with source scoring, extraction, claims, hashes and export.

## Use when

- current web research becomes dataset
- sources must be traceable

## Avoid when

- web access not allowed and no cached sources exist

## Domain markers

`query_plan`, `source_scoring`, `content_extraction`, `deduplication`, `claim_extraction`, `evidence_hash`

## Required gates

- query plan explicit
- source allow/deny policy set
- source quality scored
- retrieval date captured

## Evidence

- `research_query_plan`
- `source_quality_scores`
- `extraction_log`
- `chunk_manifest`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
