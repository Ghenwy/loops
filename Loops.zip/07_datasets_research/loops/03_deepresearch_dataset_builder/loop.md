# DeepResearch Dataset Builder — Premium Loop

## Identity

- Loop ID: `F07.L03`
- Family: `F07 — Datasets & DeepResearch`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Building datasets from web research with source scoring, extraction, claims, hashes and export.

## Why this loop matters

Turns internet research into reusable evaluation data instead of browser confetti.

## Premium artifacts

- `research_query_plan`
- `source_quality_scores`
- `extraction_log`
- `chunk_manifest`
- `claim_table`
- `dedupe_report`
- `dataset_card`

## OODA execution

### Observe

- Capture `research_query_plan` and `source_quality_scores`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `query plan explicit` and `source allow/deny policy set`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `source_count` and `accepted_rows`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- query plan explicit.
- source allow/deny policy set.
- source quality scored.
- retrieval date captured.
- content hash stored.
- extraction cleaned.
- chunks linked to source.
- claims extracted.
- dedupe applied.
- accepted/rejected split produced.
- JSONL or dataset export valid.
- dataset card written.

## Evidence contract

- `research_query_plan`
- `source_quality_scores`
- `extraction_log`
- `chunk_manifest`
- `claim_table`
- `dedupe_report`
- `dataset_export`
- `dataset_card`

## Edge case

High-ranking SEO article conflicts with official source; expected downgraded or rejected unless triangulated.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `search_query_plan`
- `source_quality_score`
- `extraction_policy`
- `dedupe_hash_manifest`
- `claim_chunk_map`
- `dataset_card`

### Quality gates
- DR-01: search_query_plan records all queries
- DR-02: source_quality_score rejects weak sources
- DR-03: extraction_policy stores raw/extracted hash
- DR-04: dedupe_hash_manifest removes duplicates
- DR-05: claim_chunk_map links claims to sources
- DR-06: dataset_card explains scope and limitations

### Merge boundary
Keep separate from dataset_validation_triangulation: builder creates sourced dataset; validation triangulates and rejects weak rows.
