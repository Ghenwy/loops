# Validation — F07.L03 deepresearch_dataset_builder

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F07.L03`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: query plan explicit.
- PV-02: source allow/deny policy set.
- PV-03: source quality scored.
- PV-04: retrieval date captured.
- PV-05: content hash stored.
- PV-06: extraction cleaned.
- PV-07: chunks linked to source.
- PV-08: claims extracted.
- PV-09: dedupe applied.
- PV-10: accepted/rejected split produced.
- PV-11: JSONL or dataset export valid.
- PV-12: dataset card written.

## Domain checks

- DC-01: `query plan explicit` must be represented in contract, examples and evidence.
- DC-02: `source allow/deny policy set` must be represented in contract, examples and evidence.
- DC-03: `source quality scored` must be represented in contract, examples and evidence.
- DC-04: `retrieval date captured` must be represented in contract, examples and evidence.
- DC-05: `content hash stored` must be represented in contract, examples and evidence.
- DC-06: `extraction cleaned` must be represented in contract, examples and evidence.
- DC-07: `chunks linked to source` must be represented in contract, examples and evidence.
- DC-08: `claims extracted` must be represented in contract, examples and evidence.
- DC-09: `dedupe applied` must be represented in contract, examples and evidence.
- DC-10: `accepted/rejected split produced` must be represented in contract, examples and evidence.
- DC-11: `JSONL or dataset export valid` must be represented in contract, examples and evidence.
- DC-12: `dataset card written` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `research_query_plan` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: High-ranking SEO article conflicts with official source; expected downgraded or rejected unless triangulated.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`query_plan`, `source_scoring`, `content_extraction`, `deduplication`, `claim_extraction`, `evidence_hash`, `jsonl_export`, `dataset_card`, `research_query_plan`, `source_quality_scores`, `extraction_log`, `chunk_manifest`, `claim_table`, `dedupe_report`, `dataset_export`, `source_count`, `accepted_rows`, `dedupe_rate`, `claim_coverage`, `building`

## Domain term coverage

This premium validation explicitly checks: `query_plan`, `source_scoring`, `content_extraction`, `deduplication`, `claim_extraction`, `evidence_hash`, `jsonl_export`, `dataset_card`.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- DR-01: search_query_plan records all queries
- DR-02: source_quality_score rejects weak sources
- DR-03: extraction_policy stores raw/extracted hash
- DR-04: dedupe_hash_manifest removes duplicates
- DR-05: claim_chunk_map links claims to sources
- DR-06: dataset_card explains scope and limitations

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from dataset_validation_triangulation: builder creates sourced dataset; validation triangulates and rejects weak rows.
