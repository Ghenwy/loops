# Evidence — F07.L03 deepresearch_dataset_builder

## Required evidence

- `research_query_plan`: required for premium closure.
- `source_quality_scores`: required for premium closure.
- `extraction_log`: required for premium closure.
- `chunk_manifest`: required for premium closure.
- `claim_table`: required for premium closure.
- `dedupe_report`: required for premium closure.
- `dataset_export`: required for premium closure.
- `dataset_card`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `research_query_plan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `source_quality_scores` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `extraction_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `chunk_manifest` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `claim_table` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `dedupe_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `dataset_export` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-deepresearch_dataset_builder-premium
loop_id: F07.L03
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  research_query_plan: present
  source_quality_scores: present
  extraction_log: present
  chunk_manifest: present
  claim_table: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F07.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `search_query_plan`: required for target A maturity.
- `source_quality_score`: required for target A maturity.
- `extraction_policy`: required for target A maturity.
- `dedupe_hash_manifest`: required for target A maturity.
- `claim_chunk_map`: required for target A maturity.
- `dataset_card`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from dataset_validation_triangulation: builder creates sourced dataset; validation triangulates and rejects weak rows.
