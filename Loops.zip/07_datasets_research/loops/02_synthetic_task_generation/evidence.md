# Evidence — F07.L02 synthetic_task_generation

    ## Required evidence

- `coverage_gap`: required for normal closure.
- `synthetic_cases`: required for normal closure.
- `realism_scores`: required for normal closure.
- `expected_behavior`: required for normal closure.
- `review_log`: required for normal closure.
- `contamination_guard`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F07.L02
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  coverage_gap: present
  synthetic_cases: present
  realism_scores: present
  expected_behavior: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F07.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
