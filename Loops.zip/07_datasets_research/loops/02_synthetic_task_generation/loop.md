# Synthetic Task Generation — Loop Definition

    ## Identity

    - Loop ID: `F07.L02`
    - Family: `F07 — Datasets & DeepResearch`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Generate synthetic tasks only when realism, difficulty, expected behavior and contamination controls are explicit.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `synthetic_task`, `realism_score`, `difficulty`, `edge_case`, `expected_behavior`, `contamination_guard`, `review_status`, `coverage_gap`

    ## Use when

- benchmark lacks edge cases
- rare scenarios need coverage

## Avoid when
- synthetic data would contaminate main benchmark unreviewed

## OODA execution

### Observe

1. identify coverage gaps in dataset.
2. define task categories and difficulty.
3. inspect contamination risk.

### Orient

1. generate candidates with expected behavior.
2. score realism and usefulness.
3. classify edge cases.

### Decide

1. accept, revise, reject or quarantine synthetic task.
2. keep synthetic split separate.
3. set review status.

### Act

1. write synthetic tasks and metadata.
2. attach expected behavior.
3. update coverage map.

### Validate

1. reject low realism tasks.
2. ensure expected behavior exists.
3. prevent unreviewed merge into benchmark.

### Evidence

- `coverage_gap`
- `synthetic_cases`
- `realism_scores`
- `expected_behavior`
- `review_log`
- `contamination_guard`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: coverage gap identified.
- CHECK-02: difficulty set.
- CHECK-03: realism score present.
- CHECK-04: expected behavior present.
- CHECK-05: edge category set.
- CHECK-06: contamination guard active.
- CHECK-07: review status present.
- CHECK-08: low realism rejected.

## Metrics

- `tasks_generated`
- `tasks_accepted`
- `realism_avg`
- `edge_categories`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
