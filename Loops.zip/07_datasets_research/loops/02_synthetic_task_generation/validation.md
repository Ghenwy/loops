# Validation — F07.L02 synthetic_task_generation

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F07.L02`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: coverage gap identified.
- DC-02: difficulty set.
- DC-03: realism score present.
- DC-04: expected behavior present.
- DC-05: edge category set.
- DC-06: contamination guard active.
- DC-07: review status present.
- DC-08: low realism rejected.

## Negative checks

- Reject if `synthetic_task` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: synthetic_task, realism_score, difficulty, edge_case, expected_behavior, contamination_guard, review_status, coverage_gap.


## Domain term audit anchors

`synthetic_task`, `realism_score`, `difficulty`, `edge_case`, `expected_behavior`, `contamination_guard`, `review_status`, `coverage_gap`
