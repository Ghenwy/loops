# Examples — F07.L02 Synthetic Task Generation

  ## Happy path

  ```yaml
  task: "Run synthetic_task_generation on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- coverage_gap
- synthetic_cases
- realism_scores
- expected_behavior
  expected_checks:
    - "coverage gap identified"
    - "difficulty set"
  ```

  ## Blocked path

  ```yaml
  task: "Run synthetic_task_generation with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run synthetic_task_generation with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
