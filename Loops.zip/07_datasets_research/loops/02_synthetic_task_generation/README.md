# Synthetic Task Generation

## ID

F07.L02

## Score

Tier `C` / score `76`.

## Purpose

Generate synthetic tasks only when realism, difficulty, expected behavior and contamination controls are explicit.

## Use when

- benchmark lacks edge cases
- rare scenarios need coverage

## Avoid when

- synthetic data would contaminate main benchmark unreviewed

## Domain markers

`synthetic_task`, `realism_score`, `difficulty`, `edge_case`, `expected_behavior`, `contamination_guard`

## Required gates

- coverage gap identified
- difficulty set
- realism score present
- expected behavior present

## Evidence

- `coverage_gap`
- `synthetic_cases`
- `realism_scores`
- `expected_behavior`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
