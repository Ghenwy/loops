# Validation — F07.L01 dataset_curation

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F07.L01`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: dataset schema exists.
- DC-02: case_id unique.
- DC-03: expected output present.
- DC-04: negative cases included.
- DC-05: split strategy defined.
- DC-06: dataset card exists.
- DC-07: version set.
- DC-08: rejected cases tracked.

## Negative checks

- Reject if `dataset_schema` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: dataset_schema, expected_output, negative_case, train_eval_split, dataset_card, version, case_id, label_quality.


## Domain term audit anchors

`dataset_schema`, `expected_output`, `negative_case`, `train_eval_split`, `dataset_card`, `version`, `case_id`, `label_quality`
