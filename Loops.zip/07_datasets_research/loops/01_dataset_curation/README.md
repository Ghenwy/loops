# Dataset Curation

## ID

F07.L01

## Score

Tier `C` / score `76`.

## Purpose

Curate evaluation datasets with schema, expected outputs, negative cases, splits, versioning and dataset card.

## Use when

- benchmark needs real cases
- agent changes need regression suite

## Avoid when

- no expected behavior can be defined

## Domain markers

`dataset_schema`, `expected_output`, `negative_case`, `train_eval_split`, `dataset_card`, `version`

## Required gates

- dataset schema exists
- case_id unique
- expected output present
- negative cases included

## Evidence

- `dataset_schema`
- `accepted_cases`
- `rejected_cases`
- `expected_outputs`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
