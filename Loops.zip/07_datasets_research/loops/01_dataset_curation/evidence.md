# Evidence — F07.L01 dataset_curation

    ## Required evidence

- `dataset_schema`: required for normal closure.
- `accepted_cases`: required for normal closure.
- `rejected_cases`: required for normal closure.
- `expected_outputs`: required for normal closure.
- `dataset_card`: required for normal closure.
- `version_manifest`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F07.L01
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  dataset_schema: present
  accepted_cases: present
  rejected_cases: present
  expected_outputs: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F07.L01
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
