# Examples — F07.L01 Dataset Curation

  ## Happy path

  ```yaml
  task: "Run dataset_curation on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- dataset_schema
- accepted_cases
- rejected_cases
- expected_outputs
  expected_checks:
    - "dataset schema exists"
    - "case_id unique"
  ```

  ## Blocked path

  ```yaml
  task: "Run dataset_curation with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run dataset_curation with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
