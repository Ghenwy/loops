# Dataset Curation — Loop Definition

    ## Identity

    - Loop ID: `F07.L01`
    - Family: `F07 — Datasets & DeepResearch`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Curate evaluation datasets with schema, expected outputs, negative cases, splits, versioning and dataset card.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `dataset_schema`, `expected_output`, `negative_case`, `train_eval_split`, `dataset_card`, `version`, `case_id`, `label_quality`

    ## Use when

- benchmark needs real cases
- agent changes need regression suite

## Avoid when
- no expected behavior can be defined

## OODA execution

### Observe

1. collect candidate cases and sources.
2. inspect expected outputs and labels.
3. detect duplicates and weak cases.

### Orient

1. classify cases by domain, difficulty and risk.
2. define schema and split strategy.
3. identify negative cases.

### Decide

1. accept, revise or reject each case.
2. set version and dataset card fields.
3. choose scoring method.

### Act

1. write dataset files and metadata.
2. create expected outputs.
3. separate rejected cases.

### Validate

1. schema validates every row.
2. expected output exists.
3. splits and version are stable.

### Evidence

- `dataset_schema`
- `accepted_cases`
- `rejected_cases`
- `expected_outputs`
- `dataset_card`
- `version_manifest`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: dataset schema exists.
- CHECK-02: case_id unique.
- CHECK-03: expected output present.
- CHECK-04: negative cases included.
- CHECK-05: split strategy defined.
- CHECK-06: dataset card exists.
- CHECK-07: version set.
- CHECK-08: rejected cases tracked.

## Metrics

- `accepted_rows`
- `rejected_rows`
- `negative_cases`
- `coverage_score`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
