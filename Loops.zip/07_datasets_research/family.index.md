# Datasets & DeepResearch Index

- F07.L01 `dataset_curation` — C/76
- F07.L02 `synthetic_task_generation` — C/76
- F07.L03 `deepresearch_dataset_builder` — S/97
- F07.L04 `dataset_validation_triangulation` — C/76
- F07.L05 `benchmark_loop` — A/95
