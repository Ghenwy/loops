# Incremental Refactor

## ID

F02.L01

## Score

Tier `S` / score `99`.

## Purpose

Small behavior-preserving refactors with diff limits, tests and rollback.

## Use when

- code needs clarity or decomposition
- behavior must stay unchanged
- small safe changes are possible

## Avoid when

- feature change disguised as refactor
- no tests or validation path exists

## Domain markers

`diff_budget`, `behavior_preservation`, `test_before_after`, `refactor_scope`, `rollback_point`, `changed_files`

## Required gates

- refactor goal explicit
- diff budget respected
- behavior contract declared
- tests run before

## Evidence

- `refactor_slice`
- `diff_budget`
- `behavior_contract`
- `before_after_test_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
