# Evidence — F02.L01 incremental_refactor

## Required evidence

- `refactor_slice`: required for premium closure.
- `diff_budget`: required for premium closure.
- `behavior_contract`: required for premium closure.
- `before_after_test_report`: required for premium closure.
- `code_diff`: required for premium closure.
- `rollback_patch`: required for premium closure.
- `review_note`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `refactor_slice` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `diff_budget` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `behavior_contract` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `before_after_test_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `code_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `rollback_patch` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `review_note` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-incremental_refactor-premium
loop_id: F02.L01
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  refactor_slice: present
  diff_budget: present
  behavior_contract: present
  before_after_test_report: present
  code_diff: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F02.L01
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `diff_budget`: required for target A maturity.
- `behavior_preservation_rule`: required for target A maturity.
- `test_before_after`: required for target A maturity.
- `refactor_intent_record`: required for target A maturity.
- `rollback_patch`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from technical_debt_cleanup: refactor transforms structure; debt cleanup prioritizes what deserves cleanup.
