# Incremental Refactor — Premium Loop

## Identity

- Loop ID: `F02.L01`
- Family: `F02 — Code Change`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Small behavior-preserving refactors with diff limits, tests and rollback.

## Why this loop matters

Turns refactor from heroic rewrite into controlled surgery.

## Premium artifacts

- `refactor_slice`
- `diff_budget`
- `behavior_contract`
- `before_after_tests`
- `rollback_patch`
- `review_note`

## OODA execution

### Observe

- Capture `refactor_slice` and `diff_budget`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `refactor goal explicit` and `diff budget respected`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `files_changed` and `diff_lines`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- refactor goal explicit.
- diff budget respected.
- behavior contract declared.
- tests run before.
- tests run after.
- public API preserved.
- no unrelated formatting churn.
- risk classified.
- rollback patch available.
- reviewer can explain diff.
- docs updated if behavior documented.
- completion criteria met.

## Evidence contract

- `refactor_slice`
- `diff_budget`
- `behavior_contract`
- `before_after_test_report`
- `code_diff`
- `rollback_patch`
- `review_note`

## Edge case

Refactor changes behavior while claiming no behavior change; expected failed unless reclassified as functional change.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `diff_budget`
- `behavior_preservation_rule`
- `test_before_after`
- `refactor_intent_record`
- `rollback_patch`

### Quality gates
- RF-01: diff_budget is declared before edits
- RF-02: behavior_preservation_rule blocks functional drift
- RF-03: test_before_after evidence exists
- RF-04: refactor_intent_record explains why change is minimal
- RF-05: rollback_patch can revert safely

### Merge boundary
Keep separate from technical_debt_cleanup: refactor transforms structure; debt cleanup prioritizes what deserves cleanup.
