# Validation — F02.L01 incremental_refactor

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F02.L01`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: refactor goal explicit.
- PV-02: diff budget respected.
- PV-03: behavior contract declared.
- PV-04: tests run before.
- PV-05: tests run after.
- PV-06: public API preserved.
- PV-07: no unrelated formatting churn.
- PV-08: risk classified.
- PV-09: rollback patch available.
- PV-10: reviewer can explain diff.
- PV-11: docs updated if behavior documented.
- PV-12: completion criteria met.

## Domain checks

- DC-01: `refactor goal explicit` must be represented in contract, examples and evidence.
- DC-02: `diff budget respected` must be represented in contract, examples and evidence.
- DC-03: `behavior contract declared` must be represented in contract, examples and evidence.
- DC-04: `tests run before` must be represented in contract, examples and evidence.
- DC-05: `tests run after` must be represented in contract, examples and evidence.
- DC-06: `public API preserved` must be represented in contract, examples and evidence.
- DC-07: `no unrelated formatting churn` must be represented in contract, examples and evidence.
- DC-08: `risk classified` must be represented in contract, examples and evidence.
- DC-09: `rollback patch available` must be represented in contract, examples and evidence.
- DC-10: `reviewer can explain diff` must be represented in contract, examples and evidence.
- DC-11: `docs updated if behavior documented` must be represented in contract, examples and evidence.
- DC-12: `completion criteria met` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `refactor_slice` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Refactor changes behavior while claiming no behavior change; expected failed unless reclassified as functional change.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`diff_budget`, `behavior_preservation`, `test_before_after`, `refactor_scope`, `rollback_point`, `changed_files`, `semantic_equivalence`, `review_patch`, `refactor_slice`, `behavior_contract`, `before_after_tests`, `rollback_patch`, `review_note`, `before_after_test_report`, `code_diff`, `files_changed`, `diff_lines`, `tests_passed`, `behavior_delta`, `behavior-preserving`

## Domain term coverage

This premium validation explicitly checks: `diff_budget`, `behavior_preservation`, `test_before_after`, `refactor_scope`, `rollback_point`, `changed_files`, `semantic_equivalence`, `review_patch`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- RF-01: diff_budget is declared before edits
- RF-02: behavior_preservation_rule blocks functional drift
- RF-03: test_before_after evidence exists
- RF-04: refactor_intent_record explains why change is minimal
- RF-05: rollback_patch can revert safely

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from technical_debt_cleanup: refactor transforms structure; debt cleanup prioritizes what deserves cleanup.
