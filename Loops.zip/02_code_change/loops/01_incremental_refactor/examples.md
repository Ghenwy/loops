# Examples — F02.L01 Incremental Refactor

## Happy path

```yaml
task: "Run incremental_refactor with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - refactor_slice
  - diff_budget
  - behavior_contract
expected_checks:
  - refactor goal explicit
  - diff budget respected
```

## Blocked path

```yaml
task: "Run incremental_refactor with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run incremental_refactor with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Refactor changes behavior while claiming no behavior change; expected failed unless reclassified as functional change."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails refactor goal explicit."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

