# Validation — F02.L04 root_cause_analysis

    ## Automated validation scope

    This file defines checks that must be auditable from files, fixtures or execution reports. Claims without evidence are rejected.

    ## Structural checks

    - Contract YAML parses and contains loop_id `F02.L04`.
    - README is <= 60 LOC.
    - Required fixtures exist.
    - Stop conditions include completed, blocked and failed.

    ## Domain checks

- DC-01: timeline present.
- DC-02: cause has evidence.
- DC-03: symptom separated from cause.
- DC-04: rejected causes recorded.
- DC-05: prevention defined.
- DC-06: recurrence guard exists.
- DC-07: owner or next action set.
- DC-08: validation of prevention included.

## Negative checks

- Reject if `five_whys` is missing from contract or evidence.
- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All domain checks represented in contract/evidence/examples.
- Score meets configured target.
## Status validation

The fixture runner must verify explicit statuses: completed, blocked and failed. Domain terms checked here: five_whys, timeline, causal_graph, fault_tree, hypothesis, prevention, symptom, recurrence_guard.


## Domain term audit anchors

`five_whys`, `timeline`, `causal_graph`, `fault_tree`, `hypothesis`, `prevention`, `symptom`, `recurrence_guard`
