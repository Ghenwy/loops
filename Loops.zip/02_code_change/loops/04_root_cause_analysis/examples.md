# Examples — F02.L04 Root Cause Analysis

  ## Happy path

  ```yaml
  task: "Run root_cause_analysis on a bounded, verifiable input."
  expected_status: completed
    expected_output: "validated loop result with evidence bundle"
  expected_evidence:

- timeline
- causal_graph
- five_whys
- cause_evidence
  expected_checks:
    - "timeline present"
    - "cause has evidence"
  ```

  ## Blocked path

  ```yaml
  task: "Run root_cause_analysis with missing required context or permission."
  expected_status: blocked
  expected_reason: "missing_required_context_or_permission"
  expected_evidence:
    - blocker_reason
    - next_required_input
  ```

  ## Failed path

  ```yaml
  task: "Run root_cause_analysis with invalid output or failed validation."
  expected_status: failed
  expected_reason: "validation_failed"
  expected_evidence:
    - failed_check
    - validation_report
  ```
