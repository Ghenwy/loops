# Root Cause Analysis — Loop Definition

    ## Identity

    - Loop ID: `F02.L04`
    - Family: `F02 — Code Change`
    - Quality target: `C+` / `76+`
    - Execution style: bounded OODA, evidence-first, no unbounded retries.

    ## Purpose

    Identify root cause of repeated or systemic failure using evidence-backed causal analysis and prevention validation.

    ## Operating principle

    The loop is accepted only when its contract, fixtures, validation and evidence are coherent. A readable explanation is not enough. The agent must prove that the loop can complete, block and fail correctly.

    ## Domain vocabulary

    `five_whys`, `timeline`, `causal_graph`, `fault_tree`, `hypothesis`, `prevention`, `symptom`, `recurrence_guard`

    ## Use when

- same failure recurs
- incident has multiple symptoms
- prevention matters

## Avoid when
- single obvious typo with direct test

## OODA execution

### Observe

1. collect symptoms, timeline and impacted areas.
2. gather logs, commits, decisions and environment changes.
3. separate direct failure from downstream effects.

### Orient

1. build five_whys or causal_graph.
2. rank causes by evidence strength.
3. identify prevention candidates.

### Decide

1. select cause to validate or discard.
2. choose prevention with measurable guard.
3. stop if evidence insufficient.

### Act

1. validate cause with targeted check.
2. implement prevention rule/test/process.
3. record rejected causes.

### Validate

1. prevention would catch recurrence.
2. cause evidence is stronger than alternatives.
3. postmortem contains owner/action.

### Evidence

- `timeline`
- `causal_graph`
- `five_whys`
- `cause_evidence`
- `prevention_action`
- `recurrence_guard`

## Decision tree

```text
pending -> running
running -> completed when all required checks pass
running -> blocked when missing authority/context/tool prevents safe action
running -> failed when validation fails and recovery is not possible
running -> rollback when state changed and validation fails
rollback -> failed or completed_recovered after restore validation
```

## Mandatory validation checks

- CHECK-01: timeline present.
- CHECK-02: cause has evidence.
- CHECK-03: symptom separated from cause.
- CHECK-04: rejected causes recorded.
- CHECK-05: prevention defined.
- CHECK-06: recurrence guard exists.
- CHECK-07: owner or next action set.
- CHECK-08: validation of prevention included.

## Metrics

- `causes_tested`
- `evidence_strength`
- `recurrence_guard_pass`

## Fixture contract

Each loop folder must contain:

- `fixtures/golden_task.yaml`
- `fixtures/blocked_task.yaml`
- `fixtures/failed_task.yaml`

## Closure rule

The loop cannot close on model confidence. It closes only on contract pass, validation pass and evidence bundle completeness.
