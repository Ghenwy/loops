# Evidence — F02.L04 root_cause_analysis

    ## Required evidence

- `timeline`: required for normal closure.
- `causal_graph`: required for normal closure.
- `five_whys`: required for normal closure.
- `cause_evidence`: required for normal closure.
- `prevention_action`: required for normal closure.
- `recurrence_guard`: required for normal closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-demo
loop_id: F02.L04
iteration: 1
selected_action: validate_domain_gate
validation_status: ok
domain_evidence:
  timeline: present
  causal_graph: present
  five_whys: present
  cause_evidence: present
notes:
  evidence: [source-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F02.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
