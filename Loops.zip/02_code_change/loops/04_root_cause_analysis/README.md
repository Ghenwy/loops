# Root Cause Analysis

## ID

F02.L04

## Score

Tier `C` / score `76`.

## Purpose

Identify root cause of repeated or systemic failure using evidence-backed causal analysis and prevention validation.

## Use when

- same failure recurs
- incident has multiple symptoms
- prevention matters

## Avoid when

- single obvious typo with direct test

## Domain markers

`five_whys`, `timeline`, `causal_graph`, `fault_tree`, `hypothesis`, `prevention`

## Required gates

- timeline present
- cause has evidence
- symptom separated from cause
- rejected causes recorded

## Evidence

- `timeline`
- `causal_graph`
- `five_whys`
- `cause_evidence`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
