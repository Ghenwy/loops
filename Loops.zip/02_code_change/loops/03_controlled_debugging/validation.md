# Validation — F02.L03 controlled_debugging

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F02.L03`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: bug reproduced.
- PV-02: scope isolated.
- PV-03: hypotheses listed.
- PV-04: one hypothesis tested per iteration.
- PV-05: probe result captured.
- PV-06: cause confirmed before fix.
- PV-07: fix is minimal.
- PV-08: regression test added.
- PV-09: unrelated changes rejected.
- PV-10: logs preserved.
- PV-11: validation rerun.
- PV-12: remaining uncertainty declared.

## Domain checks

- DC-01: `bug reproduced` must be represented in contract, examples and evidence.
- DC-02: `scope isolated` must be represented in contract, examples and evidence.
- DC-03: `hypotheses listed` must be represented in contract, examples and evidence.
- DC-04: `one hypothesis tested per iteration` must be represented in contract, examples and evidence.
- DC-05: `probe result captured` must be represented in contract, examples and evidence.
- DC-06: `cause confirmed before fix` must be represented in contract, examples and evidence.
- DC-07: `fix is minimal` must be represented in contract, examples and evidence.
- DC-08: `regression test added` must be represented in contract, examples and evidence.
- DC-09: `unrelated changes rejected` must be represented in contract, examples and evidence.
- DC-10: `logs preserved` must be represented in contract, examples and evidence.
- DC-11: `validation rerun` must be represented in contract, examples and evidence.
- DC-12: `remaining uncertainty declared` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `minimal_reproduction` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Fix appears to work but cause is unconfirmed; expected blocked or failed until hypothesis is validated.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`minimal_reproduction`, `hypothesis_matrix`, `diagnostic_probe`, `confirmed_cause`, `fix_candidate`, `regression_test`, `failure_trace`, `discarded_hypothesis`, `probe_result`, `fix_patch`, `regression_test_report`, `validation_log`, `hypotheses_tested`, `repro_rate`, `fix_size`, `regression_pass`, `reproduction`, `hypothesis`, `minimal`, `confirmed`

## Domain term coverage

This premium validation explicitly checks: `minimal_reproduction`, `hypothesis_matrix`, `diagnostic_probe`, `confirmed_cause`, `fix_candidate`, `regression_test`, `failure_trace`, `discarded_hypothesis`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- DB-01: minimal_reproduction exists before fix
- DB-02: hypothesis_matrix tracks confirmed/rejected causes
- DB-03: probe_result_table supports the chosen cause
- DB-04: confirmed_cause_record precedes code change
- DB-05: regression_test prevents recurrence

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from root_cause_analysis: debugging fixes a concrete bug; RCA analyzes systemic causality and prevention.
