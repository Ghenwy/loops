# Examples — F02.L03 Controlled Debugging

## Happy path

```yaml
task: "Run controlled_debugging with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - minimal_reproduction
  - hypothesis_matrix
  - probe_result
expected_checks:
  - bug reproduced
  - scope isolated
```

## Blocked path

```yaml
task: "Run controlled_debugging with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run controlled_debugging with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Fix appears to work but cause is unconfirmed; expected blocked or failed until hypothesis is validated."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails bug reproduced."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

