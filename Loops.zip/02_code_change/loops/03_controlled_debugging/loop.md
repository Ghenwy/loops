# Controlled Debugging — Premium Loop

## Identity

- Loop ID: `F02.L03`
- Family: `F02 — Code Change`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Bug fixing by reproduction, hypothesis, minimal test and confirmed cause.

## Why this loop matters

Stops debugging by astrology.

## Premium artifacts

- `minimal_reproduction`
- `hypothesis_matrix`
- `probe_result`
- `confirmed_cause`
- `fix_patch`
- `regression_test`

## OODA execution

### Observe

- Capture `minimal_reproduction` and `hypothesis_matrix`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `bug reproduced` and `scope isolated`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `hypotheses_tested` and `repro_rate`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- bug reproduced.
- scope isolated.
- hypotheses listed.
- one hypothesis tested per iteration.
- probe result captured.
- cause confirmed before fix.
- fix is minimal.
- regression test added.
- unrelated changes rejected.
- logs preserved.
- validation rerun.
- remaining uncertainty declared.

## Evidence contract

- `minimal_reproduction`
- `hypothesis_matrix`
- `probe_result`
- `confirmed_cause`
- `fix_patch`
- `regression_test_report`
- `validation_log`

## Edge case

Fix appears to work but cause is unconfirmed; expected blocked or failed until hypothesis is validated.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `minimal_reproduction`
- `hypothesis_matrix`
- `probe_result_table`
- `confirmed_cause_record`
- `regression_test`

### Quality gates
- DB-01: minimal_reproduction exists before fix
- DB-02: hypothesis_matrix tracks confirmed/rejected causes
- DB-03: probe_result_table supports the chosen cause
- DB-04: confirmed_cause_record precedes code change
- DB-05: regression_test prevents recurrence

### Merge boundary
Keep separate from root_cause_analysis: debugging fixes a concrete bug; RCA analyzes systemic causality and prevention.
