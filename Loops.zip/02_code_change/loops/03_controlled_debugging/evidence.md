# Evidence — F02.L03 controlled_debugging

## Required evidence

- `minimal_reproduction`: required for premium closure.
- `hypothesis_matrix`: required for premium closure.
- `probe_result`: required for premium closure.
- `confirmed_cause`: required for premium closure.
- `fix_patch`: required for premium closure.
- `regression_test_report`: required for premium closure.
- `validation_log`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `minimal_reproduction` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `hypothesis_matrix` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `probe_result` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `confirmed_cause` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `fix_patch` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `regression_test_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `validation_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-controlled_debugging-premium
loop_id: F02.L03
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  minimal_reproduction: present
  hypothesis_matrix: present
  probe_result: present
  confirmed_cause: present
  fix_patch: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F02.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `minimal_reproduction`: required for target A maturity.
- `hypothesis_matrix`: required for target A maturity.
- `probe_result_table`: required for target A maturity.
- `confirmed_cause_record`: required for target A maturity.
- `regression_test_result`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from root_cause_analysis: debugging fixes a concrete bug; RCA analyzes systemic causality and prevention.
