# Controlled Debugging

## ID

F02.L03

## Score

Tier `S` / score `99`.

## Purpose

Bug fixing by reproduction, hypothesis, minimal test and confirmed cause.

## Use when

- bug is observable
- hypotheses can be tested
- fix must be minimal

## Avoid when

- no reproduction path and no observable symptom

## Domain markers

`minimal_reproduction`, `hypothesis_matrix`, `diagnostic_probe`, `confirmed_cause`, `fix_candidate`, `regression_test`

## Required gates

- bug reproduced
- scope isolated
- hypotheses listed
- one hypothesis tested per iteration

## Evidence

- `minimal_reproduction`
- `hypothesis_matrix`
- `probe_result`
- `confirmed_cause`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
