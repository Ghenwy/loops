# Evidence — F02.L06 performance_optimization

## Required evidence

- `baseline_profile`: required for premium closure.
- `metric_definition`: required for premium closure.
- `profile_trace`: required for premium closure.
- `optimization_patch`: required for premium closure.
- `before_after_report`: required for premium closure.
- `regression_guard`: required for premium closure.
- `tradeoff_note`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `baseline_profile` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `metric_definition` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `profile_trace` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `optimization_patch` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `before_after_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `regression_guard` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `tradeoff_note` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-performance_optimization-premium
loop_id: F02.L06
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  baseline_profile: present
  metric_definition: present
  profile_trace: present
  optimization_patch: present
  before_after_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F02.L06
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `performance_baseline`: required for target A maturity.
- `profiling_report`: required for target A maturity.
- `bottleneck_hypothesis`: required for target A maturity.
- `before_after_measurement`: required for target A maturity.
- `perf_budget_result`: required for target A maturity.
- `regression_guard_result`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from technical_debt_cleanup: performance loop requires measurement improvement; debt loop requires maintainability improvement.
