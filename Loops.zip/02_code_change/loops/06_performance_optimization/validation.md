# Validation — F02.L06 performance_optimization

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F02.L06`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: baseline captured.
- PV-02: primary metric defined.
- PV-03: profiling identifies bottleneck.
- PV-04: single hypothesis selected.
- PV-05: change is minimal.
- PV-06: before/after measured.
- PV-07: functional regression checked.
- PV-08: performance regression checked.
- PV-09: trade-off documented.
- PV-10: noise threshold applied.
- PV-11: rollback available.
- PV-12: result beats threshold.

## Domain checks

- DC-01: `baseline captured` must be represented in contract, examples and evidence.
- DC-02: `primary metric defined` must be represented in contract, examples and evidence.
- DC-03: `profiling identifies bottleneck` must be represented in contract, examples and evidence.
- DC-04: `single hypothesis selected` must be represented in contract, examples and evidence.
- DC-05: `change is minimal` must be represented in contract, examples and evidence.
- DC-06: `before/after measured` must be represented in contract, examples and evidence.
- DC-07: `functional regression checked` must be represented in contract, examples and evidence.
- DC-08: `performance regression checked` must be represented in contract, examples and evidence.
- DC-09: `trade-off documented` must be represented in contract, examples and evidence.
- DC-10: `noise threshold applied` must be represented in contract, examples and evidence.
- DC-11: `rollback available` must be represented in contract, examples and evidence.
- DC-12: `result beats threshold` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `baseline_profile` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Optimization improves latency but breaks memory budget; expected failed unless trade-off is explicitly accepted.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`baseline_metric`, `profiling_trace`, `bottleneck_hypothesis`, `perf_budget`, `before_after_measurement`, `regression_guard`, `throughput_latency`, `tradeoff_record`, `baseline_profile`, `metric_definition`, `optimization_patch`, `before_after_report`, `profile_trace`, `tradeoff_note`, `latency_delta`, `throughput_delta`, `memory_delta`, `regression_count`, `measured`, `optimization`

## Domain term coverage

This premium validation explicitly checks: `baseline_metric`, `profiling_trace`, `bottleneck_hypothesis`, `perf_budget`, `before_after_measurement`, `regression_guard`, `throughput_latency`, `tradeoff_record`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- PF-01: no optimization without performance_baseline
- PF-02: profiling_report identifies bottleneck
- PF-03: bottleneck_hypothesis maps to change
- PF-04: before_after_measurement shows improvement
- PF-05: perf_budget is not violated
- PF-06: regression_guard passes functional checks

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from technical_debt_cleanup: performance loop requires measurement improvement; debt loop requires maintainability improvement.
