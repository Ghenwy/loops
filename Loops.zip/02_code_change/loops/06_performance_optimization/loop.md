# Performance Optimization — Premium Loop

## Identity

- Loop ID: `F02.L06`
- Family: `F02 — Code Change`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Measured optimization using baseline, profiling, controlled change and before/after evidence.

## Why this loop matters

Turns performance work from folklore into measurement.

## Premium artifacts

- `baseline_profile`
- `metric_definition`
- `bottleneck_hypothesis`
- `optimization_patch`
- `before_after_report`
- `regression_guard`

## OODA execution

### Observe

- Capture `baseline_profile` and `metric_definition`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `baseline captured` and `primary metric defined`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `latency_delta` and `throughput_delta`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- baseline captured.
- primary metric defined.
- profiling identifies bottleneck.
- single hypothesis selected.
- change is minimal.
- before/after measured.
- functional regression checked.
- performance regression checked.
- trade-off documented.
- noise threshold applied.
- rollback available.
- result beats threshold.

## Evidence contract

- `baseline_profile`
- `metric_definition`
- `profile_trace`
- `optimization_patch`
- `before_after_report`
- `regression_guard`
- `tradeoff_note`

## Edge case

Optimization improves latency but breaks memory budget; expected failed unless trade-off is explicitly accepted.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `performance_baseline`
- `profiling_report`
- `bottleneck_hypothesis`
- `before_after_measurement`
- `perf_budget`
- `regression_guard`

### Quality gates
- PF-01: no optimization without performance_baseline
- PF-02: profiling_report identifies bottleneck
- PF-03: bottleneck_hypothesis maps to change
- PF-04: before_after_measurement shows improvement
- PF-05: perf_budget is not violated
- PF-06: regression_guard passes functional checks

### Merge boundary
Keep separate from technical_debt_cleanup: performance loop requires measurement improvement; debt loop requires maintainability improvement.
