# Performance Optimization

## ID

F02.L06

## Score

Tier `S` / score `100`.

## Purpose

Measured optimization using baseline, profiling, controlled change and before/after evidence.

## Use when

- latency, throughput or resource use is measurable
- baseline can be captured

## Avoid when

- performance complaint with no metric

## Domain markers

`baseline_metric`, `profiling_trace`, `bottleneck_hypothesis`, `perf_budget`, `before_after_measurement`, `regression_guard`

## Required gates

- baseline captured
- primary metric defined
- profiling identifies bottleneck
- single hypothesis selected

## Evidence

- `baseline_profile`
- `metric_definition`
- `profile_trace`
- `optimization_patch`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
