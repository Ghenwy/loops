# Examples — F02.L06 Performance Optimization

## Happy path

```yaml
task: "Run performance_optimization with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - baseline_profile
  - metric_definition
  - profile_trace
expected_checks:
  - baseline captured
  - primary metric defined
```

## Blocked path

```yaml
task: "Run performance_optimization with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run performance_optimization with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Optimization improves latency but breaks memory budget; expected failed unless trade-off is explicitly accepted."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails baseline captured."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

