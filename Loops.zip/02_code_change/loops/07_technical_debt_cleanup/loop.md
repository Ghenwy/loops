# Technical Debt Cleanup — Premium Loop

## Identity

- Loop ID: `F02.L07`
- Family: `F02 — Code Change`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Removing debt with measurable maintenance value and no hidden behavior changes.

## Why this loop matters

Turns cleanup from tidying desk drawers into debt reduction.

## Premium artifacts

- `debt_score`
- `impact_risk_matrix`
- `cleanup_plan`
- `before_after_complexity`
- `behavior_preservation_check`
- `cosmetic_change_filter`

## OODA execution

### Observe

- Capture `debt_score` and `impact_risk_matrix`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `debt item classified` and `impact scored`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `complexity_delta` and `duplication_delta`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- debt item classified.
- impact scored.
- risk scored.
- cosmetic-only change rejected.
- behavior preservation checked.
- tests selected.
- before/after metric captured.
- dead code verified.
- duplication reduction measured.
- rollback ready.
- docs updated if needed.
- cleanup rationale recorded.

## Evidence contract

- `debt_score`
- `impact_risk_matrix`
- `cleanup_diff`
- `before_after_complexity`
- `test_report`
- `behavior_preservation_check`

## Edge case

Rename-only cleanup touches many files without measurable benefit; expected rejected as cosmetic churn.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `debt_scorecard`
- `impact_risk_matrix`
- `anti_cosmetic_rule`
- `before_after_complexity`
- `behavior_preservation_check`

### Quality gates
- TD-01: debt_scorecard ranks work by impact
- TD-02: anti_cosmetic_rule rejects style-only churn
- TD-03: before_after_complexity shows maintainability delta
- TD-04: behavior_preservation_check passes
- TD-05: impact_risk_matrix justifies scope

### Merge boundary
Keep separate from incremental_refactor: debt cleanup selects valuable cleanup; refactor loop executes bounded transformation.
