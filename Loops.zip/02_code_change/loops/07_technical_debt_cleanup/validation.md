# Validation — F02.L07 technical_debt_cleanup

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F02.L07`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: debt item classified.
- PV-02: impact scored.
- PV-03: risk scored.
- PV-04: cosmetic-only change rejected.
- PV-05: behavior preservation checked.
- PV-06: tests selected.
- PV-07: before/after metric captured.
- PV-08: dead code verified.
- PV-09: duplication reduction measured.
- PV-10: rollback ready.
- PV-11: docs updated if needed.
- PV-12: cleanup rationale recorded.

## Domain checks

- DC-01: `debt item classified` must be represented in contract, examples and evidence.
- DC-02: `impact scored` must be represented in contract, examples and evidence.
- DC-03: `risk scored` must be represented in contract, examples and evidence.
- DC-04: `cosmetic-only change rejected` must be represented in contract, examples and evidence.
- DC-05: `behavior preservation checked` must be represented in contract, examples and evidence.
- DC-06: `tests selected` must be represented in contract, examples and evidence.
- DC-07: `before/after metric captured` must be represented in contract, examples and evidence.
- DC-08: `dead code verified` must be represented in contract, examples and evidence.
- DC-09: `duplication reduction measured` must be represented in contract, examples and evidence.
- DC-10: `rollback ready` must be represented in contract, examples and evidence.
- DC-11: `docs updated if needed` must be represented in contract, examples and evidence.
- DC-12: `cleanup rationale recorded` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `debt_score` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Rename-only cleanup touches many files without measurable benefit; expected rejected as cosmetic churn.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`debt_score`, `impact_risk_matrix`, `anti_cosmetic_rule`, `maintainability_delta`, `dead_code`, `duplication_hotspot`, `behavior_delta_guard`, `cleanup_batch`, `cleanup_plan`, `before_after_complexity`, `behavior_preservation_check`, `cosmetic_change_filter`, `cleanup_diff`, `test_report`, `complexity_delta`, `duplication_delta`, `dead_code_removed`, `behavior_changes`, `removing`, `measurable`

## Domain term coverage

This premium validation explicitly checks: `debt_score`, `impact_risk_matrix`, `anti_cosmetic_rule`, `maintainability_delta`, `dead_code`, `duplication_hotspot`, `behavior_delta_guard`, `cleanup_batch`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- TD-01: debt_scorecard ranks work by impact
- TD-02: anti_cosmetic_rule rejects style-only churn
- TD-03: before_after_complexity shows maintainability delta
- TD-04: behavior_preservation_check passes
- TD-05: impact_risk_matrix justifies scope

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from incremental_refactor: debt cleanup selects valuable cleanup; refactor loop executes bounded transformation.
