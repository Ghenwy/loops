# Technical Debt Cleanup

## ID

F02.L07

## Score

Tier `S` / score `99`.

## Purpose

Removing debt with measurable maintenance value and no hidden behavior changes.

## Use when

- debt affects maintainability
- cleanup can be bounded
- behavior should not change

## Avoid when

- style-only churn with no benefit

## Domain markers

`debt_score`, `impact_risk_matrix`, `anti_cosmetic_rule`, `maintainability_delta`, `dead_code`, `duplication_hotspot`

## Required gates

- debt item classified
- impact scored
- risk scored
- cosmetic-only change rejected

## Evidence

- `debt_score`
- `impact_risk_matrix`
- `cleanup_diff`
- `before_after_complexity`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
