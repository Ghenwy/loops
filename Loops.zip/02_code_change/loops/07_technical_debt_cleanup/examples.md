# Examples — F02.L07 Technical Debt Cleanup

## Happy path

```yaml
task: "Run technical_debt_cleanup with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - debt_score
  - impact_risk_matrix
  - cleanup_diff
expected_checks:
  - debt item classified
  - impact scored
```

## Blocked path

```yaml
task: "Run technical_debt_cleanup with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run technical_debt_cleanup with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Rename-only cleanup touches many files without measurable benefit; expected rejected as cosmetic churn."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails debt item classified."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

