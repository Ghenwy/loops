# Evidence — F02.L07 technical_debt_cleanup

## Required evidence

- `debt_score`: required for premium closure.
- `impact_risk_matrix`: required for premium closure.
- `cleanup_diff`: required for premium closure.
- `before_after_complexity`: required for premium closure.
- `test_report`: required for premium closure.
- `behavior_preservation_check`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `debt_score` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `impact_risk_matrix` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `cleanup_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `before_after_complexity` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `test_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `behavior_preservation_check` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-technical_debt_cleanup-premium
loop_id: F02.L07
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  debt_score: present
  impact_risk_matrix: present
  cleanup_diff: present
  before_after_complexity: present
  test_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F02.L07
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `debt_scorecard`: required for target A maturity.
- `impact_risk_matrix`: required for target A maturity.
- `anti_cosmetic_decision`: required for target A maturity.
- `before_after_complexity`: required for target A maturity.
- `behavior_preservation_check`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from incremental_refactor: debt cleanup selects valuable cleanup; refactor loop executes bounded transformation.
