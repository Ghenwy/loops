# Progressive Testing No Regression

## ID

F02.L05

## Score

Tier `S` / score `100`.

## Purpose

progressive testing ladder with baseline, risk tier, regression evidence and escalation rules.

## Use when

- code or behavior changed
- risk varies by scope
- baseline exists or can be created

## Avoid when

- no executable validation path

## Domain markers

`test_ladder`, `baseline`, `risk_level`, `unit`, `smoke`, `integration`

## Required gates

- baseline exists
- risk level assigned
- affected scope mapped
- test ladder selected

## Evidence

- `baseline_result`
- `risk_assessment`
- `test_ladder`
- `test_outputs`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
