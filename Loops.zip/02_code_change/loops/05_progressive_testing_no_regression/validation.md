# Validation — F02.L05 progressive_testing_no_regression

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F02.L05`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: baseline is mandatory.
- DC-02: test tier follows risk.
- DC-03: regression failure blocks closure.
- DC-04: skipped test levels are justified.
- DC-05: artifact `test_baseline` is present.
- DC-06: artifact `risk_test_matrix` is present.
- DC-07: artifact `test_ladder_decision` is present.
- DC-08: artifact `regression_report` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: test_levels_run, failures, duration_seconds, regression_count.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: A low-risk doc change touches generated code; testing escalates beyond smoke.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.


## Rollback validation

- Rollback is required when state changes fail validation.
- The rollback plan, restore validation and post-rollback evidence must be present.
- Completion is rejected if rollback is impossible or undocumented.

## Domain term audit anchors

`test_ladder`, `baseline`, `risk_level`, `unit`, `smoke`, `integration`, `contract`, `e2e`, `regression`, `affected_scope`, `test_baseline`, `risk_test_matrix`, `test_ladder_decision`, `regression_report`, `failed_test_map`, `coverage_delta`

## Domain term coverage

This premium validation explicitly checks: `test_ladder`, `baseline`, `risk_level`, `unit`, `smoke`, `integration`, `contract`, `e2e`.
