# Evidence — F02.L05 progressive_testing_no_regression

## Required evidence

- `baseline_result`: required for normal closure.
- `risk_assessment`: required for normal closure.
- `test_ladder`: required for normal closure.
- `test_outputs`: required for normal closure.
- `regression_map`: required for normal closure.
- `stop_reason`: required for normal closure.
- `test_baseline`: required for normal closure.
- `risk_test_matrix`: required for normal closure.
- `test_ladder_decision`: required for normal closure.
- `regression_report`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `test_baseline` | progressive_testing_no_regression closure | yes |
| `risk_test_matrix` | progressive_testing_no_regression closure | yes |
| `test_ladder_decision` | progressive_testing_no_regression closure | yes |
| `regression_report` | progressive_testing_no_regression closure | yes |
| `failed_test_map` | progressive_testing_no_regression closure | yes |
| `coverage_delta` | progressive_testing_no_regression closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f02-l05-ok
loop_id: F02.L05
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  test_baseline: present
  risk_test_matrix: present
  test_ladder_decision: present
  regression_report: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f02-l05-bad
loop_id: F02.L05
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.


## Rollback validation

- Rollback is required when state changes fail validation.
- The rollback plan, restore validation and post-rollback evidence must be present.
- Completion is rejected if rollback is impossible or undocumented.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.
