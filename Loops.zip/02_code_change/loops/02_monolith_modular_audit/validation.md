# Validation — F02.L02 monolith_modular_audit

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F02.L02`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: responsibilities mapped.
- PV-02: module boundaries explicit.
- PV-03: coupling measured.
- PV-04: cohesion measured.
- PV-05: duplication compared.
- PV-06: behavior equivalence tested.
- PV-07: public contract preserved.
- PV-08: navigation cost not worse.
- PV-09: complexity not shifted elsewhere.
- PV-10: rollback path known.
- PV-11: trade-off documented.
- PV-12: reviewer signs off.

## Domain checks

- DC-01: `responsibilities mapped` must be represented in contract, examples and evidence.
- DC-02: `module boundaries explicit` must be represented in contract, examples and evidence.
- DC-03: `coupling measured` must be represented in contract, examples and evidence.
- DC-04: `cohesion measured` must be represented in contract, examples and evidence.
- DC-05: `duplication compared` must be represented in contract, examples and evidence.
- DC-06: `behavior equivalence tested` must be represented in contract, examples and evidence.
- DC-07: `public contract preserved` must be represented in contract, examples and evidence.
- DC-08: `navigation cost not worse` must be represented in contract, examples and evidence.
- DC-09: `complexity not shifted elsewhere` must be represented in contract, examples and evidence.
- DC-10: `rollback path known` must be represented in contract, examples and evidence.
- DC-11: `trade-off documented` must be represented in contract, examples and evidence.
- DC-12: `reviewer signs off` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `responsibility_map` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Modular version splits files but increases cross-module imports; expected failed unless justified by testability gain.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`coupling_metric`, `cohesion_metric`, `responsibility_map`, `equivalence_test`, `module_boundary`, `navigation_cost`, `duplication_score`, `contract_parity`, `coupling_matrix`, `cohesion_score`, `equivalence_tests`, `navigation_cost_report`, `module_boundary_report`, `cohesion_report`, `equivalence_test_report`, `module_boundary_diff`, `tradeoff_record`, `coupling_delta`, `cohesion_delta`, `duplication_delta`

## Domain term coverage

This premium validation explicitly checks: `coupling_metric`, `cohesion_metric`, `responsibility_map`, `equivalence_test`, `module_boundary`, `navigation_cost`, `duplication_score`, `contract_parity`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- MM-01: responsibility_map shows single-purpose modules
- MM-02: coupling_score does not worsen
- MM-03: cohesion_score improves or is justified
- MM-04: equivalence_test_matrix passes
- MM-05: navigation_cost_report does not increase accidental complexity

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from incremental_refactor: this loop audits structural split quality; refactor loop performs bounded changes.
