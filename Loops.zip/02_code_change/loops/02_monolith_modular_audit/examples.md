# Examples — F02.L02 Monolith Modular Audit

## Happy path

```yaml
task: "Run monolith_modular_audit with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - responsibility_map
  - coupling_matrix
  - cohesion_report
expected_checks:
  - responsibilities mapped
  - module boundaries explicit
```

## Blocked path

```yaml
task: "Run monolith_modular_audit with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run monolith_modular_audit with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Modular version splits files but increases cross-module imports; expected failed unless justified by testability gain."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails responsibilities mapped."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

