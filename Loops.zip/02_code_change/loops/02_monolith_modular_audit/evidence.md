# Evidence — F02.L02 monolith_modular_audit

## Required evidence

- `responsibility_map`: required for premium closure.
- `coupling_matrix`: required for premium closure.
- `cohesion_report`: required for premium closure.
- `equivalence_test_report`: required for premium closure.
- `module_boundary_diff`: required for premium closure.
- `tradeoff_record`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `responsibility_map` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `coupling_matrix` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `cohesion_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `equivalence_test_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `module_boundary_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `tradeoff_record` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-monolith_modular_audit-premium
loop_id: F02.L02
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  responsibility_map: present
  coupling_matrix: present
  cohesion_report: present
  equivalence_test_report: present
  module_boundary_diff: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F02.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `responsibility_map`: required for target A maturity.
- `coupling_score`: required for target A maturity.
- `cohesion_score`: required for target A maturity.
- `equivalence_test_matrix`: required for target A maturity.
- `navigation_cost_report`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from incremental_refactor: this loop audits structural split quality; refactor loop performs bounded changes.
