# Monolith Modular Audit — Premium Loop

## Identity

- Loop ID: `F02.L02`
- Family: `F02 — Code Change`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Evaluating whether modularization improves clarity, coupling and behavioral equivalence.

## Why this loop matters

Prevents architecture cosplay: more folders, same mess.

## Premium artifacts

- `responsibility_map`
- `coupling_matrix`
- `cohesion_score`
- `equivalence_tests`
- `navigation_cost_report`
- `module_boundary_report`

## OODA execution

### Observe

- Capture `responsibility_map` and `coupling_matrix`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `responsibilities mapped` and `module boundaries explicit`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `coupling_delta` and `cohesion_delta`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- responsibilities mapped.
- module boundaries explicit.
- coupling measured.
- cohesion measured.
- duplication compared.
- behavior equivalence tested.
- public contract preserved.
- navigation cost not worse.
- complexity not shifted elsewhere.
- rollback path known.
- trade-off documented.
- reviewer signs off.

## Evidence contract

- `responsibility_map`
- `coupling_matrix`
- `cohesion_report`
- `equivalence_test_report`
- `module_boundary_diff`
- `tradeoff_record`

## Edge case

Modular version splits files but increases cross-module imports; expected failed unless justified by testability gain.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `responsibility_map`
- `coupling_score`
- `cohesion_score`
- `equivalence_test_matrix`
- `navigation_cost_report`

### Quality gates
- MM-01: responsibility_map shows single-purpose modules
- MM-02: coupling_score does not worsen
- MM-03: cohesion_score improves or is justified
- MM-04: equivalence_test_matrix passes
- MM-05: navigation_cost_report does not increase accidental complexity

### Merge boundary
Keep separate from incremental_refactor: this loop audits structural split quality; refactor loop performs bounded changes.
