# Monolith Modular Audit

## ID

F02.L02

## Score

Tier `S` / score `99`.

## Purpose

Evaluating whether modularization improves clarity, coupling and behavioral equivalence.

## Use when

- monolith is being split
- modular version exists
- architecture change must be justified

## Avoid when

- no comparable versions
- only cosmetic file movement

## Domain markers

`coupling_metric`, `cohesion_metric`, `responsibility_map`, `equivalence_test`, `module_boundary`, `navigation_cost`

## Required gates

- responsibilities mapped
- module boundaries explicit
- coupling measured
- cohesion measured

## Evidence

- `responsibility_map`
- `coupling_matrix`
- `cohesion_report`
- `equivalence_test_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
