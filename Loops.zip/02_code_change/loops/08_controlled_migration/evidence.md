# Evidence — F02.L08 controlled_migration

## Required evidence

- `source_target_mapping`: required for premium closure.
- `batch_plan`: required for premium closure.
- `compatibility_matrix`: required for premium closure.
- `dual_run_report`: required for premium closure.
- `equivalence_report`: required for premium closure.
- `unit_rollback_plan`: required for premium closure.
- `cutover_report`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `source_target_mapping` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `batch_plan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `compatibility_matrix` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `dual_run_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `equivalence_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `unit_rollback_plan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `cutover_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-controlled_migration-premium
loop_id: F02.L08
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  source_target_mapping: present
  batch_plan: present
  compatibility_matrix: present
  dual_run_report: present
  equivalence_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F02.L08
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `source_target_mapping`: required for target A maturity.
- `batch_strategy`: required for target A maturity.
- `compatibility_matrix`: required for target A maturity.
- `equivalence_validation`: required for target A maturity.
- `unit_rollback_plan`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from rollback_recovery: migration loop controls forward movement; rollback loop restores after failure.
