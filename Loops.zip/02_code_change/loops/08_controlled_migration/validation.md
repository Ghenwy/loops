# Validation — F02.L08 controlled_migration

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F02.L08`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: source/target mapping complete.
- PV-02: batch size bounded.
- PV-03: compatibility checked.
- PV-04: dual-run used when needed.
- PV-05: equivalence validated.
- PV-06: unit rollback defined.
- PV-07: unmapped item blocked.
- PV-08: schema/version noted.
- PV-09: consumer impact checked.
- PV-10: docs updated.
- PV-11: migration evidence stored.
- PV-12: cutover criteria explicit.

## Domain checks

- DC-01: `source/target mapping complete` must be represented in contract, examples and evidence.
- DC-02: `batch size bounded` must be represented in contract, examples and evidence.
- DC-03: `compatibility checked` must be represented in contract, examples and evidence.
- DC-04: `dual-run used when needed` must be represented in contract, examples and evidence.
- DC-05: `equivalence validated` must be represented in contract, examples and evidence.
- DC-06: `unit rollback defined` must be represented in contract, examples and evidence.
- DC-07: `unmapped item blocked` must be represented in contract, examples and evidence.
- DC-08: `schema/version noted` must be represented in contract, examples and evidence.
- DC-09: `consumer impact checked` must be represented in contract, examples and evidence.
- DC-10: `docs updated` must be represented in contract, examples and evidence.
- DC-11: `migration evidence stored` must be represented in contract, examples and evidence.
- DC-12: `cutover criteria explicit` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `source_target_mapping` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: One migrated item lacks source mapping; expected blocked until mapping is added or item excluded.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`source_target_mapping`, `migration_batch`, `compatibility_gate`, `equivalence_validation`, `dual_run`, `rollback_unit`, `cutover_plan`, `migration_gap`, `batch_plan`, `compatibility_matrix`, `dual_run_report`, `equivalence_report`, `unit_rollback_plan`, `cutover_report`, `units_migrated`, `equivalence_pass_rate`, `rollback_ready_units`, `unmapped_items`, `migrating`, `formats`

## Domain term coverage

This premium validation explicitly checks: `source_target_mapping`, `migration_batch`, `compatibility_gate`, `equivalence_validation`, `dual_run`, `rollback_unit`, `cutover_plan`, `migration_gap`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- MG-01: every migrated item has source_target_mapping
- MG-02: batch_strategy limits blast radius
- MG-03: compatibility_matrix covers consumers
- MG-04: equivalence_validation passes per batch
- MG-05: unit_rollback_plan exists before promotion

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from rollback_recovery: migration loop controls forward movement; rollback loop restores after failure.
