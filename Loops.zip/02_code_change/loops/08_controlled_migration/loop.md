# Controlled Migration — Premium Loop

## Identity

- Loop ID: `F02.L08`
- Family: `F02 — Code Change`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Migrating code, docs, agents or formats by mapped units with equivalence and rollback.

## Why this loop matters

Makes migration boring, which is the highest compliment a migration can receive.

## Premium artifacts

- `source_target_mapping`
- `batch_plan`
- `compatibility_matrix`
- `dual_run_report`
- `equivalence_report`
- `unit_rollback_plan`

## OODA execution

### Observe

- Capture `source_target_mapping` and `batch_plan`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `source/target mapping complete` and `batch size bounded`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `units_migrated` and `equivalence_pass_rate`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- source/target mapping complete.
- batch size bounded.
- compatibility checked.
- dual-run used when needed.
- equivalence validated.
- unit rollback defined.
- unmapped item blocked.
- schema/version noted.
- consumer impact checked.
- docs updated.
- migration evidence stored.
- cutover criteria explicit.

## Evidence contract

- `source_target_mapping`
- `batch_plan`
- `compatibility_matrix`
- `dual_run_report`
- `equivalence_report`
- `unit_rollback_plan`
- `cutover_report`

## Edge case

One migrated item lacks source mapping; expected blocked until mapping is added or item excluded.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `source_target_mapping`
- `batch_strategy`
- `compatibility_matrix`
- `equivalence_validation`
- `unit_rollback_plan`

### Quality gates
- MG-01: every migrated item has source_target_mapping
- MG-02: batch_strategy limits blast radius
- MG-03: compatibility_matrix covers consumers
- MG-04: equivalence_validation passes per batch
- MG-05: unit_rollback_plan exists before promotion

### Merge boundary
Keep separate from rollback_recovery: migration loop controls forward movement; rollback loop restores after failure.
