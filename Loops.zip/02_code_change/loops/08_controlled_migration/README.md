# Controlled Migration

## ID

F02.L08

## Score

Tier `S` / score `99`.

## Purpose

Migrating code, docs, agents or formats by mapped units with equivalence and rollback.

## Use when

- source and target systems differ
- compatibility matters
- migration can be batched

## Avoid when

- one-off copy with no equivalence requirement

## Domain markers

`source_target_mapping`, `migration_batch`, `compatibility_gate`, `equivalence_validation`, `dual_run`, `rollback_unit`

## Required gates

- source/target mapping complete
- batch size bounded
- compatibility checked
- dual-run used when needed

## Evidence

- `source_target_mapping`
- `batch_plan`
- `compatibility_matrix`
- `dual_run_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
