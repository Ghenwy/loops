# Examples — F02.L08 Controlled Migration

## Happy path

```yaml
task: "Run controlled_migration with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - source_target_mapping
  - batch_plan
  - compatibility_matrix
expected_checks:
  - source/target mapping complete
  - batch size bounded
```

## Blocked path

```yaml
task: "Run controlled_migration with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run controlled_migration with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "One migrated item lacks source mapping; expected blocked until mapping is added or item excluded."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails source/target mapping complete."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

