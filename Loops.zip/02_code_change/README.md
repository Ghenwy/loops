# Code Change

## Purpose

Code Change contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F02.L01 | `incremental_refactor` | S | 99 |
| F02.L02 | `monolith_modular_audit` | S | 99 |
| F02.L03 | `controlled_debugging` | S | 99 |
| F02.L04 | `root_cause_analysis` | C | 76 |
| F02.L05 | `progressive_testing_no_regression` | S | 100 |
| F02.L06 | `performance_optimization` | S | 100 |
| F02.L07 | `technical_debt_cleanup` | S | 99 |
| F02.L08 | `controlled_migration` | S | 99 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
