# Code Change Index

- F02.L01 `incremental_refactor` — S/99
- F02.L02 `monolith_modular_audit` — S/99
- F02.L03 `controlled_debugging` — S/99
- F02.L04 `root_cause_analysis` — C/76
- F02.L05 `progressive_testing_no_regression` — S/100
- F02.L06 `performance_optimization` — S/100
- F02.L07 `technical_debt_cleanup` — S/99
- F02.L08 `controlled_migration` — S/99
