# Observability & Release

## Purpose

Observability & Release contains loops for this family domain. Agents use this README to choose a loop before loading its contract.

## Execution policy

1. Select the closest loop by trigger.
2. Read the loop README and `loop.contract.yaml`.
3. Execute bounded OODA.
4. Validate with fixtures.
5. Write evidence before closure.

## Loops

| ID | Loop | Tier | Score |
|---|---|---:|---:|
| F08.L01 | `quality_review_gate` | S | 98 |
| F08.L02 | `agent_observability` | S | 98 |
| F08.L03 | `prompt_instruction_drift` | S | 99 |
| F08.L04 | `agent_release_readiness` | S | 100 |

## Family gates

- Do not close without evidence.
- Use rollback or sandbox when state can be mutated.
- Mark evidence, inference and unknown separately.
- Escalate only for high risk, missing authority or contradictory evidence.

## DoD

A family task is done when selected loop, status, evidence, validation result and residual risk are explicit.
