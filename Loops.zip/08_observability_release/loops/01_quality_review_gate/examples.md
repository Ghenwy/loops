# Examples — F08.L01 quality_review_gate

## Happy path

```yaml
task: "Run quality_review_gate on bounded input."
expected_status: completed
expected_output: "validated result with evidence bundle"
expected_evidence: ['quality_report', 'issue_matrix', 'domain_rubric', 'DoD_matrix']
```

## Blocked path

```yaml
task: "Run quality_review_gate with missing critical context or permission."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_output: "blocked with explicit next required input"
expected_evidence: [blocker_reason, next_required_input]
```

## Failed path

```yaml
task: "Run quality_review_gate with invalid output or failed gate."
expected_status: failed
expected_reason: "validation_failed"
expected_output: "failed with failed_check and validation report"
expected_evidence: [failed_check, validation_report]
```

## Edge case

```yaml
task: "A deliverable is polished but has one critical security issue; quality gate blocks it."
expected_status: completed
expected_output: "edge case handled without hidden assumption"
expected_evidence: ['quality_report', 'issue_matrix', 'domain_rubric', 'DoD_matrix', 'rework_checklist']
expected_checks: [edge_case_result, validation_report, evidence_bundle]
```

## Expected checks

- expected_status must match fixture.
- expected_evidence must exist in final bundle.
- expected_output must be backed by validation.
