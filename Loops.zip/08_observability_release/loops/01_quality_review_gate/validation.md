# Validation — F08.L01 quality_review_gate

## Automated validation scope

Claims without evidence are rejected. This loop must pass structural, semantic, domain, negative and fixture checks.

## Structural checks

- Contract YAML parses and contains loop_id `F08.L01`.
- README is <= 60 LOC.
- Required fixtures exist, including `edge_case_task.yaml`.
- Stop conditions include completed, blocked and failed.

## Domain checks

- DC-01: critical issue auto-fails.
- DC-02: major issue requires resolution.
- DC-03: minor issue needs justification.
- DC-04: domain rubric is selected.
- DC-05: artifact `quality_rubric` is present.
- DC-06: artifact `severity_matrix` is present.
- DC-07: artifact `domain_gate_matrix` is present.
- DC-08: artifact `rejection_log` is present.

## Premium validation gates

- PVG-01: Edge case fixture is executed and produces expected_status.
- PVG-02: Premium evidence matrix is complete before completion.
- PVG-03: Negative case cannot pass as completed.
- PVG-04: Domain metrics are recorded: critical_count, major_count, minor_count, quality_score.

## Negative checks

- Reject if validation depends only on model confidence.
- Reject if blocked/failed path has no explicit reason.
- Reject if final report references evidence that does not exist.
- Reject if any critical domain gate is unresolved.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: A deliverable is polished but has one critical security issue; quality gate blocks it.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All DC and PVG checks represented in contract/evidence/examples.
- Score meets configured target.

## Domain term audit anchors

`quality_rubric`, `critical`, `major`, `minor`, `info`, `automatic_fail`, `domain_gate`, `DoD_matrix`, `quality_report`, `severity_matrix`, `domain_gate_matrix`, `rejection_log`, `dod_result`

## Domain term coverage

This premium validation explicitly checks: `quality_rubric`, `critical`, `major`, `minor`, `info`, `automatic_fail`, `domain_gate`, `DoD_matrix`.
