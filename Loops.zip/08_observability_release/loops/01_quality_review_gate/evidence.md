# Evidence — F08.L01 quality_review_gate

## Required evidence

- `quality_report`: required for normal closure.
- `issue_matrix`: required for normal closure.
- `domain_rubric`: required for normal closure.
- `DoD_matrix`: required for normal closure.
- `rework_checklist`: required for normal closure.
- `acceptance_decision`: required for normal closure.
- `quality_rubric`: required for normal closure.
- `severity_matrix`: required for normal closure.
- `domain_gate_matrix`: required for normal closure.
- `rejection_log`: required for normal closure.

## Premium evidence matrix

| Evidence | Required for | Reject if missing |
|---|---|---|
| `quality_rubric` | quality_review_gate closure | yes |
| `severity_matrix` | quality_review_gate closure | yes |
| `domain_gate_matrix` | quality_review_gate closure | yes |
| `rejection_log` | quality_review_gate closure | yes |
| `quality_report` | quality_review_gate closure | yes |
| `dod_result` | quality_review_gate closure | yes |

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Valid evidence example

```yaml
evidence_id: ev-f08-l01-ok
loop_id: F08.L01
iteration: 1
selected_action: premium_domain_gate
validation_status: ok
domain_evidence:
  quality_rubric: present
  severity_matrix: present
  domain_gate_matrix: present
  rejection_log: present
notes:
  evidence: [fixture-backed item]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-f08-l01-bad
loop_id: F08.L01
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion.
