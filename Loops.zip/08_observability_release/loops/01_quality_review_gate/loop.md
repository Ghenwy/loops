# Loop — F08.L01 Quality Review Gate

## Operating intent

quality review gate with domain rubric, severity, rejection rules and quality report.

## OODA runtime

### Observe

- Load task input, current state, prior evidence and fixture expectations.
- Inspect these artifacts: quality_rubric, severity_matrix, domain_gate_matrix, rejection_log.
- Mark missing inputs, stale evidence and unsafe assumptions before acting.

### Orient

- Apply domain gates before choosing an action.
- Required gates: critical issue auto-fails, major issue requires resolution, minor issue needs justification, domain rubric is selected.
- Split notes into `[evidence]`, `[inference]` and `[unknown]`.

### Decide

- Select one atomic action that improves validation, evidence or safety.
- Block if the first critical gate cannot be checked.
- Escalate only when risk or contradiction is explicit.

### Act

- Update the smallest artifact set needed: quality_rubric, severity_matrix, domain_gate_matrix.
- Capture command/tool/model inputs and outputs.
- Persist provisional evidence before validation.

### Validate

- Run structural, semantic, domain, negative and fixture checks.
- Execute happy, blocked, failed and edge fixtures.
- Reject completion when evidence is absent or the edge case is unresolved.

## Premium validation gates

- PVG-01: critical issue auto-fails.
- PVG-02: major issue requires resolution.
- PVG-03: minor issue needs justification.
- PVG-04: domain rubric is selected.

## Failure handling

- `blocked`: missing permission, missing source, critical ambiguity or unsafe policy.
- `failed`: validation failure, negative case accepted, evidence missing or rollback failure.
- `completed`: all premium gates pass and the final evidence bundle is complete.

## Edge case

A deliverable is polished but has one critical security issue; quality gate blocks it.

## Final output

Return status, iterations, validation result, evidence IDs, unresolved risks and next action.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.

- Premium runtime note: preserve bounded iteration, explicit evidence and rejected closure when domain gates fail.
