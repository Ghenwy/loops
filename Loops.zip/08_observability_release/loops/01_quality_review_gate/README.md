# Quality Review Gate

## ID

F08.L01

## Score

Tier `S` / score `98`.

## Purpose

quality review gate with domain rubric, severity, rejection rules and quality report.

## Use when

- deliverable must be accepted/rejected
- quality must be auditable

## Avoid when

- no acceptance criteria can be defined

## Domain markers

`quality_rubric`, `critical`, `major`, `minor`, `info`, `automatic_fail`

## Required gates

- domain rubric selected
- severity assigned
- critical auto-fail active
- major policy applied

## Evidence

- `quality_report`
- `issue_matrix`
- `domain_rubric`
- `DoD_matrix`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
