# Examples — F08.L02 Agent Observability

## Happy path

```yaml
task: "Run agent_observability with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - trace_schema
  - tool_call_log
  - token_usage_report
expected_checks:
  - trace schema present
  - each step has timestamp
```

## Blocked path

```yaml
task: "Run agent_observability with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run agent_observability with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Agent completes but trace lacks tool call IDs; expected failed observability gate."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

