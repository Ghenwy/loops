# Evidence — F08.L02 agent_observability

## Required evidence

- `trace_schema`: required for premium closure.
- `tool_call_log`: required for premium closure.
- `token_usage_report`: required for premium closure.
- `latency_report`: required for premium closure.
- `cost_report`: required for premium closure.
- `retry_log`: required for premium closure.
- `error_taxonomy`: required for premium closure.
- `trace_export`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `trace_schema` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `tool_call_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `token_usage_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `latency_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `cost_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `retry_log` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `error_taxonomy` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-agent_observability-premium
loop_id: F08.L02
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  trace_schema: present
  tool_call_log: present
  token_usage_report: present
  latency_report: present
  cost_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F08.L02
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.
