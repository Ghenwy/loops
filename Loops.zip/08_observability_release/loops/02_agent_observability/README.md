# Agent Observability

## ID

F08.L02

## Score

Tier `S` / score `98`.

## Purpose

Tracing agent execution through steps, tools, tokens, latency, cost, retries and errors.

## Use when

- agent behavior must be explainable
- cost/latency matters
- failures need diagnosis

## Avoid when

- single static artifact with no execution trace

## Domain markers

`trace_schema`, `token_usage`, `tool_call_log`, `latency_budget`, `cost_budget`, `retry_log`

## Required gates

- trace schema present
- each step has timestamp
- tool calls logged
- model/backend logged

## Evidence

- `trace_schema`
- `tool_call_log`
- `token_usage_report`
- `latency_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
