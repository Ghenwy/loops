# Agent Observability — Premium Loop

## Identity

- Loop ID: `F08.L02`
- Family: `F08 — Observability & Release`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Tracing agent execution through steps, tools, tokens, latency, cost, retries and errors.

## Why this loop matters

Without traces, agent quality is faith-based engineering.

## Premium artifacts

- `trace_schema`
- `tool_call_log`
- `token_usage_report`
- `latency_report`
- `cost_report`
- `retry_log`
- `error_taxonomy`

## OODA execution

### Observe

- Capture `trace_schema` and `tool_call_log`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `trace schema present` and `each step has timestamp`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `total_latency_ms` and `tool_call_count`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- trace schema present.
- each step has timestamp.
- tool calls logged.
- model/backend logged.
- token usage recorded.
- latency recorded.
- cost estimated when possible.
- errors classified.
- retries bounded.
- decision/result linked.
- trace IDs propagated.
- report exported.

## Evidence contract

- `trace_schema`
- `tool_call_log`
- `token_usage_report`
- `latency_report`
- `cost_report`
- `retry_log`
- `error_taxonomy`
- `trace_export`

## Edge case

Agent completes but trace lacks tool call IDs; expected failed observability gate.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target S

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `S` with score >= 96.

### Required artifacts
- `trace_schema`
- `tool_call_log`
- `token_cost_report`
- `latency_budget`
- `retry_error_taxonomy`
- `span_correlation_id`

### Quality gates
- OB-01: every step has span_correlation_id
- OB-02: tool_call_log records tool, args summary and result summary
- OB-03: token_cost_report is present when model calls occur
- OB-04: latency_budget flags slow steps
- OB-05: retry_error_taxonomy distinguishes retryable/fatal
- OB-06: final trace links to evidence IDs

### Merge boundary
Keep separate from quality_review_gate: observability measures execution telemetry; quality gate judges deliverable acceptance.
