# Validation — F08.L02 agent_observability

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F08.L02`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: trace schema present.
- PV-02: each step has timestamp.
- PV-03: tool calls logged.
- PV-04: model/backend logged.
- PV-05: token usage recorded.
- PV-06: latency recorded.
- PV-07: cost estimated when possible.
- PV-08: errors classified.
- PV-09: retries bounded.
- PV-10: decision/result linked.
- PV-11: trace IDs propagated.
- PV-12: report exported.

## Domain checks

- DC-01: `trace schema present` must be represented in contract, examples and evidence.
- DC-02: `each step has timestamp` must be represented in contract, examples and evidence.
- DC-03: `tool calls logged` must be represented in contract, examples and evidence.
- DC-04: `model/backend logged` must be represented in contract, examples and evidence.
- DC-05: `token usage recorded` must be represented in contract, examples and evidence.
- DC-06: `latency recorded` must be represented in contract, examples and evidence.
- DC-07: `cost estimated when possible` must be represented in contract, examples and evidence.
- DC-08: `errors classified` must be represented in contract, examples and evidence.
- DC-09: `retries bounded` must be represented in contract, examples and evidence.
- DC-10: `decision/result linked` must be represented in contract, examples and evidence.
- DC-11: `trace IDs propagated` must be represented in contract, examples and evidence.
- DC-12: `report exported` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `trace_schema` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Agent completes but trace lacks tool call IDs; expected failed observability gate.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`trace_schema`, `token_usage`, `tool_call_log`, `latency_budget`, `cost_budget`, `retry_log`, `error_taxonomy`, `decision_trace`, `token_usage_report`, `latency_report`, `cost_report`, `trace_export`, `total_latency_ms`, `tool_call_count`, `token_total`, `retry_count`, `tracing`, `execution`, `through`, `latency`

## Domain term coverage

This premium validation explicitly checks: `trace_schema`, `token_usage`, `tool_call_log`, `latency_budget`, `cost_budget`, `retry_log`, `error_taxonomy`, `decision_trace`.
