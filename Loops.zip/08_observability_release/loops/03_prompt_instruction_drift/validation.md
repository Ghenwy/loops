# Validation — F08.L03 prompt_instruction_drift

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F08.L03`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: instruction inventory complete.
- PV-02: contradictions detected.
- PV-03: dead rules identified.
- PV-04: semantic diff generated.
- PV-05: behavior fixtures preserved.
- PV-06: new rule has owner.
- PV-07: priority order explicit.
- PV-08: obsolete rule removed or deprecated.
- PV-09: regression behavior checked.
- PV-10: rollback patch available.
- PV-11: prompt length budget respected.
- PV-12: unknown assumptions marked.

## Domain checks

- DC-01: `instruction inventory complete` must be represented in contract, examples and evidence.
- DC-02: `contradictions detected` must be represented in contract, examples and evidence.
- DC-03: `dead rules identified` must be represented in contract, examples and evidence.
- DC-04: `semantic diff generated` must be represented in contract, examples and evidence.
- DC-05: `behavior fixtures preserved` must be represented in contract, examples and evidence.
- DC-06: `new rule has owner` must be represented in contract, examples and evidence.
- DC-07: `priority order explicit` must be represented in contract, examples and evidence.
- DC-08: `obsolete rule removed or deprecated` must be represented in contract, examples and evidence.
- DC-09: `regression behavior checked` must be represented in contract, examples and evidence.
- DC-10: `rollback patch available` must be represented in contract, examples and evidence.
- DC-11: `prompt length budget respected` must be represented in contract, examples and evidence.
- DC-12: `unknown assumptions marked` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `instruction_inventory` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Two instructions conflict on autonomy vs approval; expected blocked until priority is resolved by evidence or owner decision.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`instruction_snapshot`, `contradiction_scan`, `dead_rule`, `semantic_diff`, `behavior_regression`, `prompt_budget`, `rollback_instruction`, `drift_report`, `instruction_inventory`, `contradiction_report`, `dead_rule_report`, `behavior_fixture_suite`, `rollback_patch`, `behavior_fixture_results`, `final_instruction_diff`, `contradictions_open`, `dead_rules_removed`, `behavior_regressions`, `tokens_saved`, `detecting`

## Domain term coverage

This premium validation explicitly checks: `instruction_snapshot`, `contradiction_scan`, `dead_rule`, `semantic_diff`, `behavior_regression`, `prompt_budget`, `rollback_instruction`, `drift_report`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.

## Advanced validation gates

These gates are required for the v0.3 maturity target and are fixture-auditable.
- ID-01: contradiction_scan returns zero unresolved conflicts
- ID-02: dead_rule_detector marks obsolete rules
- ID-03: behavior_regression_suite passes core cases
- ID-04: rollback_instruction_snapshot exists
- ID-05: diff separates policy change from wording cleanup

## Merge boundary validation
- Reject merge with adjacent loops unless this boundary is invalidated: Keep separate from agent_release_readiness: drift loop maintains instructions continuously; release loop gates publication.
