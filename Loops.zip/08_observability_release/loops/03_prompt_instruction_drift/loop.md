# Prompt Instruction Drift — Premium Loop

## Identity

- Loop ID: `F08.L03`
- Family: `F08 — Observability & Release`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Detecting and correcting contradiction, bloat and stale behavioral rules in agent instructions.

## Why this loop matters

Keeps agents from becoming rule lasagna: many layers, no structural integrity.

## Premium artifacts

- `instruction_inventory`
- `semantic_diff`
- `contradiction_report`
- `dead_rule_report`
- `behavior_fixture_suite`
- `rollback_patch`

## OODA execution

### Observe

- Capture `instruction_inventory` and `semantic_diff`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `instruction inventory complete` and `contradictions detected`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `contradictions_open` and `dead_rules_removed`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- instruction inventory complete.
- contradictions detected.
- dead rules identified.
- semantic diff generated.
- behavior fixtures preserved.
- new rule has owner.
- priority order explicit.
- obsolete rule removed or deprecated.
- regression behavior checked.
- rollback patch available.
- prompt length budget respected.
- unknown assumptions marked.

## Evidence contract

- `instruction_inventory`
- `semantic_diff`
- `contradiction_report`
- `dead_rule_report`
- `behavior_fixture_results`
- `rollback_patch`
- `final_instruction_diff`

## Edge case

Two instructions conflict on autonomy vs approval; expected blocked until priority is resolved by evidence or owner decision.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target A

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `A` with score >= 92.

### Required artifacts
- `instruction_diff_schema`
- `contradiction_scan`
- `dead_rule_detector`
- `behavior_regression_suite`
- `rollback_instruction_snapshot`

### Quality gates
- ID-01: contradiction_scan returns zero unresolved conflicts
- ID-02: dead_rule_detector marks obsolete rules
- ID-03: behavior_regression_suite passes core cases
- ID-04: rollback_instruction_snapshot exists
- ID-05: diff separates policy change from wording cleanup

### Merge boundary
Keep separate from agent_release_readiness: drift loop maintains instructions continuously; release loop gates publication.
