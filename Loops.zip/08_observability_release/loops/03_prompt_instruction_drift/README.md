# Prompt Instruction Drift

## ID

F08.L03

## Score

Tier `S` / score `99`.

## Purpose

Detecting and correcting contradiction, bloat and stale behavioral rules in agent instructions.

## Use when

- agent instructions changed
- rules became long or conflicting

## Avoid when

- no stable behavior expectation exists

## Domain markers

`instruction_snapshot`, `contradiction_scan`, `dead_rule`, `semantic_diff`, `behavior_regression`, `prompt_budget`

## Required gates

- instruction inventory complete
- contradictions detected
- dead rules identified
- semantic diff generated

## Evidence

- `instruction_inventory`
- `semantic_diff`
- `contradiction_report`
- `dead_rule_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
