# Evidence — F08.L03 prompt_instruction_drift

## Required evidence

- `instruction_inventory`: required for premium closure.
- `semantic_diff`: required for premium closure.
- `contradiction_report`: required for premium closure.
- `dead_rule_report`: required for premium closure.
- `behavior_fixture_results`: required for premium closure.
- `rollback_patch`: required for premium closure.
- `final_instruction_diff`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `instruction_inventory` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `semantic_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `contradiction_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `dead_rule_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `behavior_fixture_results` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `rollback_patch` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `final_instruction_diff` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-prompt_instruction_drift-premium
loop_id: F08.L03
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  instruction_inventory: present
  semantic_diff: present
  contradiction_report: present
  dead_rule_report: present
  behavior_fixture_results: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F08.L03
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.

## Advanced evidence matrix

The final evidence bundle must include domain evidence, validation_status and rejection reasons when applicable.
- `instruction_diff`: required for target A maturity.
- `contradiction_scan_report`: required for target A maturity.
- `dead_rule_report`: required for target A maturity.
- `behavior_regression_result`: required for target A maturity.
- `rollback_instruction_snapshot`: required for target A maturity.

## Merge boundary evidence
- `merge_boundary`: Keep separate from agent_release_readiness: drift loop maintains instructions continuously; release loop gates publication.
