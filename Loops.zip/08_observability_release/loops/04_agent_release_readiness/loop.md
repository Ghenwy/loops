# Agent Release Readiness — Premium Loop

## Identity

- Loop ID: `F08.L04`
- Family: `F08 — Observability & Release`
- Target: `S / 96+`
- Upgrade: `v0.3 targeted hardening`

## Purpose

Release gating for agents, skills, workflows and tools before shared use.

## Why this loop matters

Prevents prototype-grade agents from being published as production-ready assets.

## Premium artifacts

- `release_manifest`
- `owner_matrix`
- `known_limitations`
- `rollback_plan`
- `smoke_report`
- `security_gate`
- `observability_gate`

## OODA execution

### Observe

- Capture `release_manifest` and `owner_matrix`.
- Identify missing context, unsupported assumptions and existing blockers.
- Preserve baseline evidence before changing state.
- Mark evidence, inference and unknown separately.

### Orient

- Classify risk using `release manifest present` and `owner and version assigned`.
- Map artifacts to required checks and expected fixtures.
- Identify which failure mode should block, fail or trigger rollback.
- Select metrics `release_gate_pass_rate` and `open_blockers`.

### Decide

- Choose the smallest reversible action that can close one failed gate.
- Escalate only when evidence, permission or ownership is missing.
- Reject broad rewrites that are not tied to a validation failure.
- Define the expected evidence bundle before acting.

### Act

- Execute the action within the loop scope.
- Update the relevant artifact, fixture or validation record.
- Capture raw output plus normalized evidence.
- Avoid hidden side effects outside the declared scope.

### Validate

- Run premium validation gates.
- Execute happy, blocked, failed and edge fixtures.
- Confirm evidence bundle completeness.
- Export score, residual risks and next action.

## Premium validation gates

- release manifest present.
- owner and version assigned.
- known limitations declared.
- smoke tests passed.
- security review passed.
- observability hooks present.
- rollback plan validated.
- docs match behavior.
- change log updated.
- support boundary clear.
- failed gates block release.
- release report exported.

## Evidence contract

- `release_manifest`
- `owner_version_record`
- `known_limitations`
- `smoke_report`
- `security_gate_report`
- `observability_trace`
- `rollback_plan`
- `release_report`

## Edge case

Release candidate passes smoke tests but lacks rollback owner; expected blocked until owner/version/rollback are explicit.

## Closure rule

The loop closes only when contract, fixtures, validation, evidence and score all pass. Model confidence is not evidence.

## v0.3 maturity upgrade — target S

This loop was selected from the consolidated fast-upgrade/gamechanger set. Target: `S` with score >= 96.

### Required artifacts
- `release_readiness_matrix`
- `owner_version_gate`
- `known_limitations_register`
- `rollback_release_plan`
- `smoke_test_manifest`
- `release_report_schema`

### Quality gates
- RR-01: owner and version are mandatory
- RR-02: known_limitations are explicit and non-empty
- RR-03: smoke_test_manifest passed
- RR-04: rollback_release_plan exists before publish
- RR-05: release_report links evidence IDs
- RR-06: beta/release/reject decision is severity-based

### Merge boundary
Keep separate from quality_review_gate: release_readiness packages final ownership/version/recovery; quality_review scores artifact quality.
