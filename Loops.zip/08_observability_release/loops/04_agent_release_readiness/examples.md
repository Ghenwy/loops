# Examples — F08.L04 Agent Release Readiness

## Happy path

```yaml
task: "Run agent_release_readiness with all required artifacts present."
expected_status: completed
expected_output: "premium loop result with validated evidence bundle"
expected_evidence:
  - release_manifest
  - owner_version_record
  - known_limitations
expected_checks:
  - release manifest present
  - owner and version assigned
```

## Blocked path

```yaml
task: "Run agent_release_readiness with missing owner, permission or required source."
expected_status: blocked
expected_reason: "missing_required_context_or_permission"
expected_evidence:
  - blocker_reason
  - next_required_input
```

## Failed path

```yaml
task: "Run agent_release_readiness with invalid output or failed premium gate."
expected_status: failed
expected_reason: "validation_failed"
expected_evidence:
  - failed_check
  - validation_report
```

## Edge case

```yaml
task: "Release candidate passes smoke tests but lacks rollback owner; expected blocked until owner/version/rollback are explicit."
expected_status: blocked_or_failed
expected_output: "edge case is not silently accepted"
expected_evidence:
  - edge_case_reason
  - premium_gate_result
```

## Rollback path

```yaml
task: "Action mutates state and then fails release manifest present."
expected_status: failed_or_recovered
expected_evidence:
  - rollback_plan
  - restore_validation_result
```

