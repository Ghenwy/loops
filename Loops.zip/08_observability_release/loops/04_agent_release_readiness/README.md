# Agent Release Readiness

## ID

F08.L04

## Score

Tier `S` / score `100`.

## Purpose

Release gating for agents, skills, workflows and tools before shared use.

## Use when

- publishing or sharing agent/tool
- beta/prod readiness matters

## Avoid when

- private rough experiment not intended for reuse

## Domain markers

`release_candidate`, `owner_version`, `known_limitations`, `smoke_test`, `safety_gate`, `observability_gate`

## Required gates

- release manifest present
- owner and version assigned
- known limitations declared
- smoke tests passed

## Evidence

- `release_manifest`
- `owner_version_record`
- `known_limitations`
- `smoke_report`

## Fixtures

- golden_task.yaml
- blocked_task.yaml
- failed_task.yaml
- edge_case_task.yaml
- rollback_task.yaml

## Next

Read `loop.contract.yaml`, execute fixtures and close only with evidence.
