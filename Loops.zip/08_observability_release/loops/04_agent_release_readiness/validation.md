# Validation — F08.L04 agent_release_readiness

## Automated validation scope

Checks must be auditable from contracts, fixtures, reports or evidence. Claims without evidence are rejected.

## Structural checks

- Contract YAML parses and contains loop_id `F08.L04`.
- README is <= 60 LOC.
- Required fixtures exist: golden, blocked, failed and edge case.
- Stop conditions include completed, blocked and failed.

## Premium validation gates

- PV-01: release manifest present.
- PV-02: owner and version assigned.
- PV-03: known limitations declared.
- PV-04: smoke tests passed.
- PV-05: security review passed.
- PV-06: observability hooks present.
- PV-07: rollback plan validated.
- PV-08: docs match behavior.
- PV-09: change log updated.
- PV-10: support boundary clear.
- PV-11: failed gates block release.
- PV-12: release report exported.

## Domain checks

- DC-01: `release manifest present` must be represented in contract, examples and evidence.
- DC-02: `owner and version assigned` must be represented in contract, examples and evidence.
- DC-03: `known limitations declared` must be represented in contract, examples and evidence.
- DC-04: `smoke tests passed` must be represented in contract, examples and evidence.
- DC-05: `security review passed` must be represented in contract, examples and evidence.
- DC-06: `observability hooks present` must be represented in contract, examples and evidence.
- DC-07: `rollback plan validated` must be represented in contract, examples and evidence.
- DC-08: `docs match behavior` must be represented in contract, examples and evidence.
- DC-09: `change log updated` must be represented in contract, examples and evidence.
- DC-10: `support boundary clear` must be represented in contract, examples and evidence.
- DC-11: `failed gates block release` must be represented in contract, examples and evidence.
- DC-12: `release report exported` must be represented in contract, examples and evidence.

## Negative checks

- Reject if closure depends only on model confidence.
- Reject if `release_manifest` is missing.
- Reject if edge case does not produce the expected decision.
- Reject if unsupported inference is presented as evidence.
- Reject if critical risk remains without explicit owner.

## Fixture checks

- `golden_task.yaml` must finish as `completed`.
- `blocked_task.yaml` must finish as `blocked`.
- `failed_task.yaml` must finish as `failed`.
- `edge_case_task.yaml` must exercise: Release candidate passes smoke tests but lacks rollback owner; expected blocked until owner/version/rollback are explicit.

## Pass criteria

- 0 structural failures.
- 0 YAML failures.
- All premium validation gates represented.
- Required evidence bundle complete.
- Score target `S / 96+` reached.

## Domain term audit anchors

`release_candidate`, `owner_version`, `known_limitations`, `smoke_test`, `safety_gate`, `observability_gate`, `rollback_plan`, `release_report`, `release_manifest`, `owner_matrix`, `smoke_report`, `security_gate`, `owner_version_record`, `security_gate_report`, `observability_trace`, `release_gate_pass_rate`, `open_blockers`, `rollback_ready`, `docs_behavior_match`, `release`

## Domain term coverage

This premium validation explicitly checks: `release_candidate`, `owner_version`, `known_limitations`, `smoke_test`, `safety_gate`, `observability_gate`, `rollback_plan`, `release_report`.

## Rollback validation

- Rollback strategy must be declared before mutation.
- Restore validation must prove the previous state or safe recovered state.
- Rollback evidence must include action, result and residual risk.
