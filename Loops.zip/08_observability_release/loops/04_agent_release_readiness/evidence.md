# Evidence — F08.L04 agent_release_readiness

## Required evidence

- `release_manifest`: required for premium closure.
- `owner_version_record`: required for premium closure.
- `known_limitations`: required for premium closure.
- `smoke_report`: required for premium closure.
- `security_gate_report`: required for premium closure.
- `observability_trace`: required for premium closure.
- `rollback_plan`: required for premium closure.
- `release_report`: required for premium closure.

## Required common fields

- `evidence_id`
- `loop_id`
- `iteration`
- `timestamp`
- `selected_action`
- `validation_status`
- `source_or_tool`
- `evidence/inference/unknown` notes

## Premium evidence matrix

| Evidence | Valid source | Reject when |
|---|---|---|
| `release_manifest` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `owner_version_record` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `known_limitations` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `smoke_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `security_gate_report` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `observability_trace` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |
| `rollback_plan` | fixture, report, diff, trace or checked artifact | missing, stale or unsupported |

## Valid evidence example

```yaml
evidence_id: ev-agent_release_readiness-premium
loop_id: F08.L04
iteration: 1
selected_action: premium_gate_validation
validation_status: ok
domain_evidence:
  release_manifest: present
  owner_version_record: present
  known_limitations: present
  smoke_report: present
  security_gate_report: present
notes:
  evidence: [source-backed artifact]
  inference: []
  unknown: []
```

## Rejected evidence example

```yaml
evidence_id: ev-bad
loop_id: F08.L04
validation_status: ok
domain_evidence: {}
notes:
  inference: [looks correct because the model says so]
```

Reject reason: missing domain evidence and unsupported inference.

## Final evidence bundle

The final report must reference all evidence IDs used to justify completion and list unresolved risks.

## Rollback evidence

If rollback is required, include `rollback_report`, `restore_validation`, `rollback_point` and final rollback status.
